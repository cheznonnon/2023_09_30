// Nonnon XAudio DLL
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//
//	[ WM_CREATE and WM_CLOSE ]
//
//	n_xaudio2_init()
//	n_xaudio2_exit()




#ifndef _H_NONNON_WIN32_GAME_XAUDIO2
#define _H_NONNON_WIN32_GAME_XAUDIO2




typedef struct {

	void *xaudio;
	void *master;
	void *srcvox;

} n_xaudio2_dll;


typedef struct {

	HMODULE hmod;
	FARPROC init;
	FARPROC exit;
	FARPROC loop;
	FARPROC stop;

	n_xaudio2_dll p;

} n_xaudio2;


static n_xaudio2 n_xaudio2_instance;




#define n_xaudio2_zero( p ) n_memory_zero( p, sizeof( n_xaudio2 ) )

void
n_xaudio2_exit( n_xaudio2 *p )
{

	if ( n_xaudio2_instance.exit ) { n_xaudio2_instance.exit( &p->p ); }

	FreeLibrary( n_xaudio2_instance.hmod );

	n_xaudio2_zero( &n_xaudio2_instance );


	return;
}

void
n_xaudio2_init( n_xaudio2 *p, n_wav *wav )
{

	n_xaudio2_zero( &n_xaudio2_instance );


	n_xaudio2_instance.hmod = LoadLibrary( n_posix_literal( "Nonnon XAudio DLL.dll" ) );
	n_xaudio2_instance.init = GetProcAddress( n_xaudio2_instance.hmod, "n_xaudio2_init" );
	n_xaudio2_instance.exit = GetProcAddress( n_xaudio2_instance.hmod, "n_xaudio2_exit" );


	n_posix_bool error = n_posix_false;

	if ( n_xaudio2_instance.hmod == NULL ) { error = n_posix_true; }
	if ( n_xaudio2_instance.init == NULL ) { error = n_posix_true; }

	if ( error )
	{
n_posix_debug_literal( " n_xaudio2_init() " );
		n_xaudio2_exit( p );
	} else {
		n_xaudio2_instance.init( &p->p, &wav->fmt );
	}


	return;
}

void
n_xaudio2_loop( n_xaudio2 *p )
{

	if ( n_xaudio2_instance.loop ) { n_xaudio2_instance.loop( &p->p ); }

	return;
}

void
n_xaudio2_stop( n_xaudio2 *p )
{

	if ( n_xaudio2_instance.stop ) { n_xaudio2_instance.stop( &p->p ); }

	return;
}

void
n_xaudio2_pause( n_xaudio2 *p )
{
	return;
}

void
n_xaudio2_resume( n_xaudio2 *p )
{
	return;
}


#endif // _H_NONNON_WIN32_GAME_XAUDIO2

