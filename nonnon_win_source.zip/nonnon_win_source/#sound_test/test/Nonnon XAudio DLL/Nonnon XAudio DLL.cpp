// Nonnon XAudio DLL
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html



#pragma comment( lib, "xaudio2.lib" )




#include <xaudio2.h>




typedef struct {

	IXAudio2               *xaudio;
	IXAudio2MasteringVoice *master;
	IXAudio2SourceVoice    *srcvox;

} n_xaudio2;


#define n_xaudio2_zero( p ) ZeroMemory( p, sizeof( n_xaudio2 ) )

void
n_xaudio2_exit( n_xaudio2 *p )
{

	//if ( p->srcvox != NULL ) { p->srcvox->Release(); }
	//if ( p->master != NULL ) { p->master->Release(); }
	if ( p->xaudio != NULL ) { p->xaudio->Release(); }

	CoUninitialize();

	n_xaudio2_zero( p );

	return;
}

BOOL
n_xaudio2_init( n_xaudio2 *p, WAVEFORMATEX *wav )
{

	n_xaudio2_zero( p );

	CoInitializeEx( NULL, COINIT_MULTITHREADED );


	HRESULT hr = XAudio2Create( &p->xaudio, 0, XAUDIO2_DEFAULT_PROCESSOR );
	if ( FAILED( hr ) )
	{
MessageBoxA( NULL, " XAudio2Create ", "", 0 );

		n_xaudio2_exit( p );

		return TRUE;
	}

//n_posix_debug_literal( "%d %d", wav->wFormatTag, wav->cbSize );

	hr = p->xaudio->CreateMasteringVoice( &p->master, 2, 44100, 0, NULL, NULL, AudioCategory_GameEffects );
	if ( FAILED( hr ) )
	{
MessageBoxA( NULL, " CreateMasteringVoice ", "", 0 );

		n_xaudio2_exit( p );

		return TRUE;
	}


	hr = p->xaudio->CreateSourceVoice
	(
		&p->srcvox,
		wav,
		0,
		XAUDIO2_DEFAULT_FREQ_RATIO,
		NULL,
		NULL,
		NULL
	);
	if ( ( FAILED( hr ) )||( p->srcvox == NULL ) )
	{
MessageBoxA( NULL, " CreateSourceVoice ", "", 0 );

		n_xaudio2_exit( p );

		return TRUE;
	}


	return FAILED( hr );
}

void
n_xaudio2_loop( n_xaudio2 *p )
{

	if ( p->srcvox != NULL )
	{
		p->srcvox->Start( 0, 0 );
	}

	return;
}

void
n_xaudio2_stop( n_xaudio2 *p )
{

	if ( p->srcvox != NULL )
	{
		p->srcvox->Stop( 0 );
	}

	return;
}


