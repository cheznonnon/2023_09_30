// Nonnon Sound Test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifdef _MSC_VER


// [x] : uncompilable

#pragma comment(lib,"xaudio2.lib")
#include <xaudio2.h>


#else // #ifdef _MSC_VER


#ifndef __XAUDIO2_INCLUDED__


#define XAUDIO2_DEFAULT_FREQ_RATIO 2.0f


typedef struct XAUDIO2_BUFFER {

	UINT32      Flags;
	UINT32      AudioBytes;
	const BYTE *pAudioData;
	UINT32      PlayBegin;
	UINT32      PlayLength;
	UINT32      LoopBegin;
	UINT32      LoopLength;
	UINT32      LoopCount;
	void       *pContext;

} XAUDIO2_BUFFER;

#define XAUDIO2_DEVICE_DETAILS      int
#define XAUDIO2_PROCESSOR           int
#define IXAudio2EngineCallback      int
#define IXAudio2VoiceCallback       int
#define IXAudio2SubmixVoice         int
#define XAUDIO2_VOICE_SENDS         int
#define XAUDIO2_EFFECT_CHAIN        int
#define XAUDIO2_PERFORMANCE_DATA    int
#define XAUDIO2_DEBUG_CONFIGURATION int
#define AUDIO_STREAM_CATEGORY       void*


EXTERN_C const IID IID_IUnknown;
#define INTERFACE IXAudio2SourceVoice
DECLARE_INTERFACE_( IXAudio2SourceVoice, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS                 ) PURE;
	STDMETHOD_( ULONG, Release )( THIS                 ) PURE;

	STDMETHOD ( Start               )( THIS_ UINT32, UINT32 ) PURE;
	STDMETHOD ( Stop                )( THIS_ UINT32         ) PURE; // [!] : stub
	STDMETHOD ( SubmitSourceBuffer  )( THIS_ XAUDIO2_BUFFER*, void* ) PURE;
	STDMETHOD ( FlushSourceBuffers  )( THIS                 ) PURE; // [!] : stub
	STDMETHOD ( Discontinuity       )( THIS                 ) PURE; // [!] : stub
	STDMETHOD ( ExitLoop            )( THIS                 ) PURE; // [!] : stub
	STDMETHOD ( GetState            )( THIS                 ) PURE; // [!] : stub
	STDMETHOD ( SetFrequencyRatio   )( THIS                 ) PURE; // [!] : stub
	STDMETHOD ( GetFrequencyRatio   )( THIS                 ) PURE; // [!] : stub
	STDMETHOD ( SetSourceSampleRate )( THIS                 ) PURE; // [!] : stub
};
#undef INTERFACE


EXTERN_C const IID IID_IUnknown;
#define INTERFACE IXAudio2MasteringVoice
DECLARE_INTERFACE_( IXAudio2MasteringVoice, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS                 ) PURE;
	STDMETHOD_( ULONG, Release )( THIS                 ) PURE;
};
#undef INTERFACE


EXTERN_C const IID IID_IUnknown;
#define INTERFACE IXAudio2
DECLARE_INTERFACE_( IXAudio2, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS                 ) PURE;
	STDMETHOD_( ULONG, Release )( THIS                 ) PURE;

	STDMETHOD ( GetDeviceCount       )( THIS_ UINT32* ) PURE;
	STDMETHOD ( GetDeviceDetails     )( THIS_ UINT32, XAUDIO2_DEVICE_DETAILS* ) PURE;
	STDMETHOD ( Initialize           )( THIS_ UINT32, XAUDIO2_PROCESSOR ) PURE;
	STDMETHOD ( RegisterForCallbacks )( THIS_ IXAudio2EngineCallback* ) PURE;
	STDMETHOD_( void, UnregisterForCallbacks ) (IXAudio2EngineCallback* ) PURE;
	STDMETHOD ( CreateSourceVoice    )( THIS_ IXAudio2SourceVoice**, WAVEFORMATEX*, UINT32, float, IXAudio2VoiceCallback*, XAUDIO2_VOICE_SENDS*, XAUDIO2_EFFECT_CHAIN* ) PURE;
	STDMETHOD ( CreateSubmixVoice    )( THIS_ IXAudio2SubmixVoice*, UINT32, UINT32, UINT32, UINT32, XAUDIO2_VOICE_SENDS*, XAUDIO2_EFFECT_CHAIN* ) PURE;
	STDMETHOD ( CreateMasteringVoice )( THIS_ IXAudio2MasteringVoice**, UINT32, UINT32, UINT32, LPCWSTR, XAUDIO2_EFFECT_CHAIN*, AUDIO_STREAM_CATEGORY ) PURE;
	STDMETHOD ( StartEngine          )( THIS ) PURE;
	STDMETHOD_( void, StopEngine     )( THIS ) PURE;
	STDMETHOD ( CommitChanges        )( THIS_ UINT32 ) PURE;
	STDMETHOD_( void, GetPerformanceData    )( THIS_ XAUDIO2_PERFORMANCE_DATA* ) PURE;
	STDMETHOD_( void, SetDebugConfiguration )(THIS_ XAUDIO2_DEBUG_CONFIGURATION*, void* ) PURE;
};
#undef INTERFACE


#endif // #ifndef __XAUDIO2_INCLUDED__


#endif // #ifdef _MSC_VER




typedef struct {

	HMODULE                 hmod;  
	IXAudio2               *xaudio;
	IXAudio2MasteringVoice *master;
	IXAudio2SourceVoice    *srcvox;

} n_xaudio2;


#define n_xaudio2_zero( p ) n_memory_zero( p, sizeof( n_xaudio2 ) )

void
n_xaudio2_exit( n_xaudio2 *p )
{

	if ( p->srcvox != NULL ) { p->srcvox->lpVtbl->Release( p->srcvox ); }
	if ( p->master != NULL ) { p->master->lpVtbl->Release( p->master ); }
	if ( p->xaudio != NULL ) { p->xaudio->lpVtbl->Release( p->xaudio ); }

	if ( p->hmod != NULL ) { FreeLibrary( p->hmod ); }

	CoUninitialize();

	return;
}

n_posix_bool
n_xaudio2_init( n_xaudio2 *p, n_wav *wav )
{

	CoInitializeEx( NULL, COINIT_MULTITHREADED );


	p->hmod = LoadLibrary( n_posix_literal( "XAudio2_8.dll" ) );
	//p->hmod = LoadLibrary( n_posix_literal( "Windows.Media.Audio.dll" ) ); // [!] : not found
	if ( p->hmod == NULL )
	{
n_posix_debug_literal( " LoadLibrary() " );

		return n_posix_true;
	}

	FARPROC func = GetProcAddress( p->hmod, "XAudio2Create" );
	if ( func == NULL )
	{
n_posix_debug_literal( " GetProcAddress() " );

		n_xaudio2_exit( p );

		return n_posix_true;
	}


	HRESULT hr = func( &p->xaudio, 0, 0x00000001 );
	if ( FAILED( hr ) )
	{
n_posix_debug_literal( " XAudio2Create " );

		n_xaudio2_exit( p );

		return n_posix_true;
	}

//n_posix_debug_literal( "%d %d", wav->fmt.wFormatTag, wav->fmt.cbSize );

	hr = p->xaudio->lpVtbl->CreateMasteringVoice( p->xaudio, &p->master, 2, 44100, 0, NULL, NULL, NULL );
	if ( FAILED( hr ) )
	{
n_posix_debug_literal( " CreateMasteringVoice : %x ", hr );

		n_xaudio2_exit( p );

		return n_posix_true;
	}


	hr = p->xaudio->lpVtbl->CreateSourceVoice
	(
		p->xaudio,
		&p->srcvox,
		&wav->fmt,
		0,
		XAUDIO2_DEFAULT_FREQ_RATIO,
		NULL,
		NULL,
		NULL
	);
	if ( FAILED( hr ) )
	{
n_posix_debug_literal( " CreateSourceVoice : %x ", hr );

		n_xaudio2_exit( p );

		return n_posix_true;
	}

	if ( p->srcvox == NULL )
	{
n_posix_debug_literal( " CreateSourceVoice : NULL " );

		n_xaudio2_exit( p );

		return n_posix_true;
	}


	XAUDIO2_BUFFER buf = { 0, wav->wh.dwBufferLength, wav->wh.lpData, 0,0, 0,0,0, NULL };

	hr = p->srcvox->lpVtbl->SubmitSourceBuffer
	(
		p->srcvox,
		&buf,
		NULL
	);

	if ( FAILED( hr ) )
	{
n_posix_debug_literal( " SubmitSourceBuffer : %x ", hr );
	}


	return FAILED( hr );
}

void
n_xaudio2_loop( n_xaudio2 *p )
{

	if ( p->srcvox != NULL )
	{
		p->srcvox->lpVtbl->Start( p->srcvox, 0, 0 );
	}

	return;
}

void
n_xaudio2_stop( n_xaudio2 *p )
{

	if ( p->srcvox != NULL )
	{
		p->srcvox->lpVtbl->Stop( p->srcvox, 0 );
	}

	return;
}

void
n_xaudio2_pause( n_xaudio2 *p )
{
	return;
}

void
n_xaudio2_resume( n_xaudio2 *p )
{
	return;
}


