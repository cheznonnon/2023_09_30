// Nonnon Sound Test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"
#include "../nonnon/game/sound.c"

#include "./test/wasapi.c"
#include "./test/xaudio2.c"




static int mode = 5;




static n_mci         n_soundtest_mci;
static n_vfw         n_soundtest_vfw;
static n_wav         n_soundtest_wav;
static n_waveout     n_soundtest_waveout;
static n_directsound n_soundtest_directsound;
static n_wasapi      n_soundtest_wasapi;
static n_xaudio2     n_soundtest_xaudio2;




// nonnon game layer

void
n_game_init( void )
{

	// System

	n_game_title_literal( "Nonon Sound Test" );
	game.sx    = 256;
	game.sy    = 256;
	game.fps   = 30;
	game.color = n_bmp_white;


	// [!] : zero-clear

	n_wav_zero        ( &n_soundtest_wav         );

	n_mci_zero        ( &n_soundtest_mci         );
	n_vfw_zero        ( &n_soundtest_vfw         );
	n_waveout_zero    ( &n_soundtest_waveout     );
	n_directsound_zero( &n_soundtest_directsound );
	n_wasapi_zero     ( &n_soundtest_wasapi      );


	// Start

	n_posix_char *cmdline = n_win_commandline_new();


	n_string_path_folder_change( cmdline );


	if ( mode == 0 )
	{
		n_game_title_literal( "MCI" );

		n_mci_init( &n_soundtest_mci, cmdline );
	} else
	if ( mode == 1 )
	{
		n_game_title_literal( "VFW" );

		n_vfw_load( &n_soundtest_vfw, game.hwnd, cmdline );
	} else
	if ( mode == 2 )
	{
		n_game_title_literal( "waveOut" );

		n_wav_load( &n_soundtest_wav, cmdline );
		n_waveout_init( &n_soundtest_waveout, &n_soundtest_wav );
	} else
	if ( mode == 3 )
	{
		n_game_title_literal( "DirectSound" );

		n_wav_load( &n_soundtest_wav, cmdline );
		n_directsound_init( &n_soundtest_directsound, game.hwnd, &n_soundtest_wav );
	} else
	if ( mode == 4 )
	{
		n_game_title_literal( "WASAPI" );

		n_wav_load( &n_soundtest_wav, cmdline );
		n_wasapi_init( &n_soundtest_wasapi, &n_soundtest_wav );
	} else
	if ( mode == 5 )
	{
		n_game_title_literal( "XAudio2" );

		n_wav_load( &n_soundtest_wav, cmdline );
		n_xaudio2_init( &n_soundtest_xaudio2, &n_soundtest_wav );
	}// else


	n_string_path_free( cmdline );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_SPACE ) )
	{
		n_game_title_literal( "Play" );

		if ( mode == 0 )
		{
			n_mci_loop( &n_soundtest_mci );
		} else
		if ( mode == 1 )
		{
			n_vfw_play( &n_soundtest_vfw );
		} else
		if ( mode == 2 )
		{
			n_waveout_loop( &n_soundtest_waveout );
		} else
		if ( mode == 3 )
		{
			n_directsound_loop( &n_soundtest_directsound );
		} else
		if ( mode == 4 )
		{
			n_wasapi_loop( &n_soundtest_wasapi );
		} else
		if ( mode == 5 )
		{
			n_xaudio2_loop( &n_soundtest_xaudio2 );
		}// else
	} else
	if ( n_win_is_input( '1' ) )
	{
		n_game_title_literal( "Paused" );

		if ( mode == 0 )
		{
			n_mci_pause( &n_soundtest_mci );
		} else
		if ( mode == 1 )
		{
			n_vfw_pause( &n_soundtest_vfw );
		} else
		if ( mode == 2 )
		{
			n_waveout_pause( &n_soundtest_waveout );
		} else
		if ( mode == 3 )
		{
			n_directsound_pause( &n_soundtest_directsound );
		} else
		if ( mode == 4 )
		{
			n_wasapi_pause( &n_soundtest_wasapi );
		} else
		if ( mode == 5 )
		{
			n_xaudio2_pause( &n_soundtest_xaudio2 );
		}// else
	} else
	if ( n_win_is_input( '2' ) )
	{
		n_game_title_literal( "Resumed" );

		if ( mode == 0 )
		{
			n_mci_resume( &n_soundtest_mci );
		} else
		if ( mode == 1 )
		{
			n_vfw_resume( &n_soundtest_vfw );
		} else
		if ( mode == 2 )
		{
			n_waveout_resume( &n_soundtest_waveout );
		} else
		if ( mode == 3 )
		{
			n_directsound_resume( &n_soundtest_directsound );
		} else
		if ( mode == 4 )
		{
			n_wasapi_resume( &n_soundtest_wasapi );
		} else
		if ( mode == 5 )
		{
			n_xaudio2_resume( &n_soundtest_xaudio2 );
		}// else
	} else
	if ( n_win_is_input( '3' ) )
	{
		n_game_title_literal( "Stopped" );

		if ( mode == 0 )
		{
			n_mci_stop( &n_soundtest_mci );
		} else
		if ( mode == 1 )
		{
			n_vfw_stop( &n_soundtest_vfw );
		} else
		if ( mode == 2 )
		{
			n_waveout_stop( &n_soundtest_waveout );
		} else
		if ( mode == 3 )
		{
			n_directsound_stop( &n_soundtest_directsound );
		} else
		if ( mode == 4 )
		{
			n_wasapi_stop( &n_soundtest_wasapi );
		} else
		if ( mode == 5 )
		{
			n_xaudio2_stop( &n_soundtest_xaudio2 );
		}// else
	}


	return;
}

void
n_game_exit( void )
{

	n_mci_exit        ( &n_soundtest_mci         );
	n_vfw_free        ( &n_soundtest_vfw         );
	n_waveout_exit    ( &n_soundtest_waveout     );
	n_directsound_exit( &n_soundtest_directsound );
	n_wasapi_exit     ( &n_soundtest_wasapi      );
	n_xaudio2_exit    ( &n_soundtest_xaudio2     );

	n_wav_free        ( &n_soundtest_wav         );


	return;
}

