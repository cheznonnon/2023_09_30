// Marie
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




static UINT n_marie_systray_blink_id = 0;


static NOTIFYICONDATA n_marie_systray_nid;
static int            n_marie_systray_icon_supported[] = { 16, 0 };




void
n_marie_systray_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const u32 interval = 100;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		n_win_systray_icon_change
		(
			&n_marie_systray_nid,
			n_marie_exepath,
			N_APPS_ICON_OFFSET_MARIE + 5,
			n_marie_systray_icon_supported
		);

	break;


	case WM_SIZE :

		if ( wparam == SIZE_MINIMIZED )
		{

			ShowWindow( hwnd, SW_HIDE );

			if ( n_marie_systray_blink_id == 0 ) { n_marie_systray_blink_id = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, n_marie_systray_blink_id, interval );

			n_win_systray_init_literal
			(
				&n_marie_systray_nid,
				hwnd,
				n_marie_timer_id_tray,
				"MARIE_5_X",
				N_MARIE_APPNAME,
				n_true
			);

		}

	break;


	case N_WIN_SYSTRAY_MESSAGE :

		if ( wparam != n_marie_systray_nid.uID ) { break; }


		if ( lparam == WM_LBUTTONDOWN )
		{

			// [!] : for other indicators

			n_posix_sleep( 500 );


			// [!] : for window animation is ON

			ShowWindow( hwnd, SW_MINIMIZE );


			ShowWindow( hwnd, SW_NORMAL );

			SetForegroundWindow( hwnd );


			n_win_systray_exit( &n_marie_systray_nid );

		} else
		if ( lparam == WM_RBUTTONUP )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_TIMER :
	{

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != n_marie_systray_blink_id ) { break; }


		if ( IsWindowVisible( hwnd ) ) { break; }


		static u32 i = 0;

//n_win_hwndprintf_literal( hwnd, "%s", n_marie_exepath );
		if ( ( i == 0 )||( i == 2 ) )
		{
			n_win_systray_icon_change( &n_marie_systray_nid, n_marie_exepath, N_APPS_ICON_OFFSET_MARIE + 6, n_marie_systray_icon_supported );
		} else
		if ( i == 1 )
		{
			n_win_systray_icon_change( &n_marie_systray_nid, n_marie_exepath, N_APPS_ICON_OFFSET_MARIE + 7, n_marie_systray_icon_supported );
		} else
		if ( i == 3 )
		{
			n_win_systray_icon_change( &n_marie_systray_nid, n_marie_exepath, N_APPS_ICON_OFFSET_MARIE + 5, n_marie_systray_icon_supported );
		}


		i++;
		if ( i >= interval ) { i = 0; }

	}
	break;


	} // switch


	return;
}

