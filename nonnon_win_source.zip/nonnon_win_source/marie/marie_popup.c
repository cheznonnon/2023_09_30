// Nonnon Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_popup.c"

#include "../nonnon/project/macro.c"




// rc.h

#define H_BTN_L  n_marie_button[ 0 ]
#define H_BTN_M  n_marie_button[ 1 ]
#define H_BTN_R  n_marie_button[ 2 ]
#define BTN_MAX                  3



static n_win_button n_marie_button[ BTN_MAX ];




void
n_marie_popup_resize( HWND hwnd )
{

	const n_bool redraw = n_false;


	n_type_gfx ico,m;
	n_type_gfx csx,csy;


	n_win_stdsize( hwnd, NULL, &ico, &m );

	ico = ico + ( m * 2 );
	csx = ico * BTN_MAX;
	csy = ico;


	n_win_move_simple( H_BTN_L.hwnd, 0*ico,0, ico,ico, redraw );
	n_win_move_simple( H_BTN_M.hwnd, 1*ico,0, ico,ico, redraw );
	n_win_move_simple( H_BTN_R.hwnd, 2*ico,0, ico,ico, redraw );


	{

		n_win w;
		int   nwinset = N_WIN_SET_NEEDPOS | N_WIN_SET_INNERPOS;

		POINT p;


		GetCursorPos( &p );
		w.posx = p.x - ( csx / 2 );
		w.posy = p.y - ( csy / 2 );
		n_win_set( hwnd, &w, csx,csy, nwinset );

	}

	if ( n_win_fluent_ui_onoff )
	{
		n_win_fluent_ui_roundrect_region( hwnd, csx,csy, n_win_fluent_ui_round_param( hwnd ) );
	}


	return;
}

LRESULT CALLBACK
n_marie_popup_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		n_win_button_on_settingchange( &H_BTN_L );
		n_win_button_on_settingchange( &H_BTN_M );
		n_win_button_on_settingchange( &H_BTN_R );

		H_BTN_L.maclike_onoff = n_posix_false;
		H_BTN_M.maclike_onoff = n_posix_false;
		H_BTN_R.maclike_onoff = n_posix_false;

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_button_zero( &H_BTN_L );
		n_win_button_zero( &H_BTN_M );
		n_win_button_zero( &H_BTN_R );


		// Window

		n_win_init_literal( hwnd, "", "", "" );

		n_win_button_init( &H_BTN_L, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_M, hwnd, N_STRING_EMPTY, PBS_NORMAL );
		n_win_button_init( &H_BTN_R, hwnd, N_STRING_EMPTY, PBS_NORMAL );

		H_BTN_L.maclike_onoff = n_posix_false;
		H_BTN_M.maclike_onoff = n_posix_false;
		H_BTN_R.maclike_onoff = n_posix_false;


		// Style

		n_win_style_new( hwnd, WS_POPUP );

		n_bool onoff  = ( n_marie_fit_onoff == n_false );
		int    offset = N_APPS_ICON_OFFSET_MARIE + 3;
		onoff = n_win_button_checklike( &H_BTN_M, offset, offset, onoff );

		H_BTN_L.hicon = n_win_icon_init( n_marie_exepath, N_APPS_ICON_OFFSET_MARIE + 2, N_WIN_ICON_INIT_OPTION_RESOURCE );
		H_BTN_M.hicon = n_win_icon_init( n_marie_exepath, N_APPS_ICON_OFFSET_MARIE + 3, N_WIN_ICON_INIT_OPTION_RESOURCE );
		H_BTN_R.hicon = n_win_icon_init( n_marie_exepath, N_APPS_ICON_OFFSET_MARIE + 4, N_WIN_ICON_INIT_OPTION_RESOURCE );


		// Size

		n_marie_popup_resize( hwnd );


		// Display

		// [!] : "Async" is needed

		ShowWindowAsync( hwnd, SW_NORMAL );

	break;


	case WM_COMMAND :
	{

		extern void n_marie_effect( HWND, int );


		const HWND hwnd_parent = GetParent( hwnd );


		n_win_position( hwnd_parent, &n_marie_point.x, &n_marie_point.y );

		n_marie_point.x = n_marie_point.x + ( n_marie_n_win.wsx / 2 );
		n_marie_point.y = n_marie_point.y + ( n_marie_n_win.wsy / 2 );


		if ( (HWND) lparam == H_BTN_L.hwnd )
		{

			n_marie_degree -= 90;
			n_marie_effect( hwnd_parent, N_WIN_SET_NEEDPOS );

		} else
		if ( (HWND) lparam == H_BTN_M.hwnd )
		{

			if ( n_marie_fit_onoff ) { n_marie_fit_onoff = n_false; } else { n_marie_fit_onoff = n_true; }
			n_marie_effect( hwnd_parent, N_WIN_SET_CENTERING );

			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		} else
		if ( (HWND) lparam == H_BTN_R.hwnd )
		{

			n_marie_degree += 90;
			n_marie_effect( hwnd_parent, N_WIN_SET_NEEDPOS );

		}

	}
	break;

	case WM_ACTIVATE :
	{

		n_bool is_acrive;
		if ( wparam == WA_INACTIVE )
		{
			is_acrive = n_false;
		} else {
			is_acrive = n_true;
		}

		n_win_message_send( GetParent( hwnd ), WM_NCACTIVATE, is_acrive, 0 );

	}
	break;

	case WM_KILLFOCUS :

		if ( n_false == IsChild( hwnd, GetFocus() ) )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );


		n_win_button_exit( &H_BTN_L );
		n_win_button_exit( &H_BTN_M );
		n_win_button_exit( &H_BTN_R );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_L );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_M );
	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BTN_R );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}


#undef H_BTN_L
#undef H_BTN_M
#undef H_BTN_R
#undef BTN_MAX

