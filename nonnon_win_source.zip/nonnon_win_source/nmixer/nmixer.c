// nmixer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

//#define N_MEMORY_DEBUG

#include "../nonnon/game/timegettime.c"

#endif // #ifndef NONNON_APPS




#include "../nonnon/win32/gdi.c"

#include "../nonnon/win32/registry.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_popup.c"
#include "../nonnon/win32/win_scrollbar.c"
#include "../nonnon/win32/win_simplemenu.c"
#include "../nonnon/win32/win_slider.c"
#include "../nonnon/win32/win_systray.c"
#include "../nonnon/win32/mixer.c"


#include "../nonnon/project/macro.c"




static u32 n_nmixer_color_cache = 0;

void
n_nmixer_color( HWND hwnd )
{

/*
	// [!] : this will be a color of wallpaper

	HDC hdc = GetWindowDC( hwnd );
	int m   = GetSystemMetrics( SM_CXSIZEFRAME );

	n_nmixer_color_cache = n_bmp_colorref2argb( GetPixel( hdc, m,m ) );

	ReleaseDC( hwnd, hdc );
*/

	n_nmixer_color_cache = n_win_dwm_windowcolor_arranged();


	return;
}

u32
n_nmixer_color_contour( u32 color_base )
{

	// [x] : not the best

	return n_bmp_white;


	u32 ahsl = n_bmp_argb2ahsl( color_base );


	u32 color_ret;
	if ( 128 < n_bmp_l( ahsl ) )
	{
		color_ret = n_bmp_black;
	} else {
		color_ret = n_bmp_white;
	}


	return color_ret;
}

static int n_nmixer_systray_icon_change_percent = 0;

void
n_nmixer_systray_callback( n_bmp *b, n_bmp *m )
{

	u32 black = n_bmp_rgb( 10,10,10 );
	u32 white = n_bmp_white;

	u32 clr_f;
	u32 clr_t;

	if ( n_win_style_is_classic() )
	{
		clr_f = n_gdi_systemcolor_ui( COLOR_BTNFACE );
		clr_t = n_bmp_blend_pixel( clr_f, black, (n_type_real) n_nmixer_systray_icon_change_percent * 0.01 );
	} else {
		clr_f = n_bmp_alpha_replace_pixel( n_nmixer_color_cache, 255 );
		clr_t = n_bmp_blend_pixel( black, clr_f, (n_type_real) n_nmixer_systray_icon_change_percent * 0.01 );
	}

	u32 contr = n_nmixer_color_contour( clr_t );
	n_bmp_flush_replacer( b, white, contr );

	n_bmp_flush_replacer( b, black, clr_t );


	return;
}




// [!] : Instance

#ifndef NONNON_APPS

#define N_APPS_ICON_OFFSET_NMIXER ( 0 )

#endif // #ifndef NONNON_APPS


#define N_NMIXER_APPNAME n_posix_literal( "nmixer" )
#define N_NMIXER_STICKY  n_posix_literal( "-sticky" )


#define N_NMIXER_TIMER_MSEC   GetDoubleClickTime()
#define N_NMIXER_EVENT_LAUNCH WM_LBUTTONUP


#define H_LBL    nmixer.hgui[ 0 ]
#define GUI_MAX               1




typedef struct {

	HWND              hwnd;
	HWND              hgui[ GUI_MAX ];

	n_win_slider      slider;
	n_bmp_fade        slider_fade;
	UINT              slider_timer_id;

	NOTIFYICONDATA    nid;
	n_posix_char     *icon_name;
	int               icon_index;
	n_bool            sticky;

	UINT              timer_id_main;
	UINT              timer_id_tray;
	UINT              timer_id_lnch;

	n_type_gfx        csx,csy;
	n_win_simplemenu  menu;
	WNDPROC           pfunc_label;
	n_bool            init_onoff;
	int               taskbar;
	n_bool            border_onoff;

} n_nmixer;


static n_nmixer nmixer;




static int n_nmixer_icon_supported[] = { 16, 24, 32, 0 };




#include "./IAudioEndpointVolumeCallback.c"
#include "./n_mixer_classic_callback.c"


n_bool
n_mixer_callback( n_bool is_init )
{

	// [!] : integrated function

	n_bool ret;


	if ( n_sysinfo_version_vista_or_later() )
	{
		ret = n_IAudioEndpointVolumeCallback_onoff( n_true );
	} else {
		ret = n_mixer_classic_callback_onoff( n_true );
	}


	return ret;
}




#define n_nmixer_zero( p ) n_memory_zero( p, sizeof( n_nmixer ) )

void
n_nmixer_init( void )
{

	n_nmixer_zero( &nmixer );

	nmixer.icon_name  = n_win_exepath_new();
	nmixer.icon_index = N_APPS_ICON_OFFSET_NMIXER + 1;


	return;
}

// internal
void
n_nmixer_automove( HWND hwnd )
{

	if ( nmixer.sticky )
	{

		nmixer.taskbar = n_win_popup_automove( hwnd, nmixer.csx, nmixer.csy );

	} else {

		nmixer.taskbar = 0;


		n_type_gfx desktop_sx, desktop_sy;
		n_win_desktop_size( &desktop_sx, &desktop_sy );


		n_type_gfx x,y; n_win_cursor_position( &x, &y );

		x = n_posix_minmax( 0, desktop_sx - nmixer.csx, x );
		y = n_posix_minmax( 0, desktop_sy - nmixer.csy, y );


		SetWindowPos( hwnd, NULL, x, y, 0,0, SWP_NOSIZE );

	}


	return;
}

// internal
void
n_nmixer_border_size( n_type_gfx *sx, n_type_gfx *sy )
{
//n_posix_debug_literal(  "%d ", GetSystemMetrics( SM_CXSIZEFRAME ) );

	if ( sx != NULL ) { (*sx) = GetSystemMetrics( SM_CXSIZEFRAME ); }
	if ( sy != NULL ) { (*sy) = GetSystemMetrics( SM_CYSIZEFRAME ); }

#ifdef _WIN64

	if ( sx != NULL ) { (*sx) *= 2; }
	if ( sy != NULL ) { (*sy) *= 2; }

#endif // #ifdef _WIN64


	return;
}

// internal
void
n_nmixer_resize( HWND hwnd )
{

	n_type_gfx ctl; n_win_stdsize( hwnd, &ctl, NULL, NULL );


	n_type_gfx border_sx = 0;
	n_type_gfx border_sy = 0;

	if ( nmixer.border_onoff )
	{
		n_nmixer_border_size( &border_sx, &border_sy );
	}


	n_type_gfx csx = ( ctl * 2 ) + ( border_sx * 2 );
	n_type_gfx csy = ( ctl * 7 ) + ( border_sy * 2 );
	n_type_gfx scr = GetSystemMetrics( SM_CXVSCROLL );
	n_type_gfx lbl = ctl;


	n_win_set( hwnd, NULL, csx, csy, N_WIN_SET_DEFAULT );


	n_type_gfx x,y,sx,sy;


	sx = scr * 2;
	sy = csy - lbl - ( border_sy * 2 );
	x  = ( csx - sx ) / 2;
	y  = border_sy;

	x += ( scr % 2 );

	n_win_move_simple( nmixer.slider.hwnd, x,y,sx,sy, n_true );

	n_win_rect_set( &nmixer.slider.rect_all, x,y,sx,sy );


	n_bmp_new_fast( &nmixer.slider.bmp_canvas, sx,sy );

	n_type_gfx bar_sx = (n_type_gfx) ( (n_type_real) sx * 0.25 );
	n_type_gfx bar_sy = (n_type_gfx) ( (n_type_real) sy * 0.80 );

	n_bmp_new_fast( &nmixer.slider.bmp_shaft, bar_sx, bar_sy );


	sx = csx - ( border_sx * 2 );
	sy = lbl;
	x  = border_sx;
	y  = csy - sy - border_sy;

	n_win_move_simple( H_LBL, x,y,sx,sy, n_true );


	// [!] : for n_nmixer_automove()

	nmixer.csx = csx;
	nmixer.csy = csy;


	return;
}

// internal
void
n_nmixer_keydown( HWND hwnd, int *vol_scroll, int vk )
{

	if ( ( vk == VK_UP   )||( vk == VK_LEFT  ) )
	{
		(*vol_scroll)++;
	} else
	if ( ( vk == VK_DOWN )||( vk == VK_RIGHT ) )
	{
		(*vol_scroll)--;
	} else
	if ( vk == VK_NEXT )
	{
		(*vol_scroll) -= 10;
	} else
	if ( vk == VK_PRIOR )
	{
		(*vol_scroll) += 10;
	} else
	if ( vk == VK_HOME )
	{
		(*vol_scroll) = 100;
	} else
	if ( vk == VK_END )
	{
		(*vol_scroll) =   0;
	} else {
		return;
	}


	n_win_message_send( hwnd, WM_COMMAND, (*vol_scroll), nmixer.slider.hwnd );


	return;
}

// internal
void
n_nmixer_option( void )
{

	n_posix_char *cmdline = n_win_commandline_new();


#ifdef NONNON_APPS

	// [Needed] : for Nonnon Apps

	n_string_commandline_option( N_APPS_OPTION_NMIXER, cmdline );

#endif // #ifdef NONNON_APPS


	if ( n_string_is_empty( cmdline ) )
	{
		nmixer.sticky = n_false;
	} else {
		nmixer.sticky = n_true;
	}


	n_string_path_free( cmdline );


	return;
}

n_posix_char*
n_nmixer_startup_commandline( void )
{

	n_posix_char *exe = n_win_exepath_new();

#ifdef NONNON_APPS

	n_posix_char *ret = n_string_path_cat( exe, N_STRING_SPACE, N_APPS_OPTION_NMIXER, N_STRING_SPACE, N_NMIXER_STICKY, NULL );
	n_string_free( exe );

#else  // #ifndef NONNON_APPS

	n_posix_char *ret = exe;

#endif // #ifndef NONNON_APPS


	return ret;
}

void
n_nmixer_draw_slider( HWND hgui, HDC hdc, RECT *rect )
{
//return;
//n_win_box( hgui, hdc, r, RGB(0,200,255) );


	n_posix_char str[ 100 ]; n_win_text_get( H_LBL, str, 100 - 1 );

	nmixer.slider.value = n_posix_atoi( str );

	n_win_slider_draw( &nmixer.slider, hdc, rect );


	return;
}

void
n_nmixer_draw_label( HWND hgui, HDC hdc, RECT *r )
{

	n_type_gfx   ctl;        n_win_stdsize( hgui, &ctl, NULL, NULL );
	n_posix_char str[ 100 ]; n_win_text_get( hgui, str, 100 - 1 );
	n_type_real  blend = (n_type_real) n_posix_atoi( str ) * 0.01;

	n_type_gfx sx,sy; n_win_rect_expand_size( r, NULL, NULL, &sx, &sy );

	n_gdi gdi; n_gdi_zero( &gdi );
	gdi.sx                 = n_posix_max_n_type_gfx( 1, sx );
	gdi.sy                 = n_posix_max_n_type_gfx( 1, sy );
	gdi.base_color_bg      = n_win_darkmode_systemcolor_colorref2argb( COLOR_BTNFACE );
	if ( n_project_dwm_is_on() ) { gdi.base_color_bg = n_bmp_black_invisible; }

	gdi.text               = str;
	gdi.text_font          = n_project_stdfont();//n_posix_literal( "Arial" );//
	gdi.text_size          = (n_type_gfx) ( (n_type_real) gdi.sx * 0.3 );
	gdi.text_color_main    = n_bmp_white;
	gdi.text_color_contour = n_bmp_blend_pixel( n_bmp_rgb( 1,1,1 ), n_nmixer_color_cache, blend );
	gdi.text_style         = N_GDI_TEXT_BOLD | N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	gdi.text_fxsize1       = 0;
	gdi.text_fxsize2       = 2;


	n_bmp bmp; n_bmp_zero( &bmp );

	n_gdi_bmp( &gdi, &bmp );
	n_gdi_bitmap_draw_main( hgui, hdc, &bmp, 0,0,sx,sy, 0,0 );

	n_bmp_free( &bmp );


	return;
}

// internal
void
n_nmixer_draw_slider_as_bg( HWND hwnd, HDC hdc )
{

	n_type_gfx ctl; n_win_stdsize( hwnd, &ctl, NULL, NULL );


	n_type_gfx border_sx = 0;
	n_type_gfx border_sy = 0;

	if ( nmixer.border_onoff )
	{
		n_nmixer_border_size( &border_sx, &border_sy );
	}


	n_type_gfx csx = ( ctl * 2 ) + ( border_sx * 2 );
	n_type_gfx csy = ( ctl * 7 ) + ( border_sy * 2 );
	n_type_gfx scr = GetSystemMetrics( SM_CXVSCROLL );
	n_type_gfx lbl = ctl;


	n_type_gfx x,y,sx,sy;


	sx = scr * 2;
	sy = csy - lbl - ( border_sy * 2 );
	x  = ( csx - sx ) / 2;
	y  = border_sy;

	x += ( scr % 2 );

	RECT r = { x,y,x+sx,y+sy };
	n_nmixer_draw_slider( nmixer.slider.hwnd, hdc, &r );


	return;
}

void
n_nmixer_slider_move( HWND hwnd )
{

	n_win_slider_move( &nmixer.slider );


	int vol = nmixer.slider.value;
	n_mixer_set( &vol );

	n_win_hwndprintf_literal( H_LBL, " %3d %% ", vol );

	n_nmixer_systray_icon_change_percent = vol;
	n_win_systray_icon_change( &nmixer.nid, nmixer.icon_name, nmixer.icon_index, n_nmixer_icon_supported );


	return;
}

n_bool
n_nmixer_animation_onoff( void )
{

	n_bool onoff = n_false;

	SystemParametersInfo( SPI_GETMENUANIMATION, 0, &onoff, 0 );

	return onoff;
}

void
n_nmixer_animatewindow( HWND hwnd, n_bool show_onoff )
{

	int sw;

	if ( show_onoff )
	{
		sw = SW_NORMAL;
	} else {
		sw = SW_HIDE;
	}

	if (
		( n_false == n_nmixer_animation_onoff() )
		||
		( n_sysinfo_version_95() )
		||
		( ( n_sysinfo_version_98() )&&( sw == SW_HIDE ) )
		||
		( ( n_sysinfo_version_me() )&&( sw == SW_HIDE ) )
	)
	{

		ShowWindowAsync( hwnd, sw );

		return;
	}


	int aw;

	if ( show_onoff )
	{
		aw = n_AW_SLIDE;

		if ( nmixer.sticky )
		{
			if ( nmixer.taskbar == ABE_TOP )
			{
				aw |= n_AW_VER_POSITIVE;
			} else
			if ( nmixer.taskbar == ABE_BOTTOM )
			{
				aw |= n_AW_VER_NEGATIVE;
			} else
			if ( nmixer.taskbar == ABE_LEFT )
			{
				aw |= n_AW_HOR_POSITIVE;
			} else
			if ( nmixer.taskbar == ABE_RIGHT )
			{
				aw |= n_AW_HOR_NEGATIVE;
			}
		} else {
			aw |= n_AW_VER_POSITIVE;
		}
	} else {
		aw = n_AW_BLEND | n_AW_HIDE;
	}


	if ( n_win_dwm_aeroglass_is_on() )
	{

		ShowWindowAsync( hwnd, sw );

	} else {

		n_bool ret = n_win_animatewindow( hwnd, 0, aw );
		if ( ret ) { ShowWindowAsync( hwnd, sw ); }

		n_win_refresh( H_LBL, n_false );

	}


	return;
}

void
n_nmixer_autostyle( HWND hwnd )
{

	// [x] : for AnimateWindow()

	if (
//(0)&&
		( n_nmixer_animation_onoff() )
		&&
		( n_sysinfo_version_8_or_later() )
		&&
		( n_false == n_sysinfo_version_10_or_later() )
	)
	{
		nmixer.border_onoff = n_true;

		n_win_style_new( hwnd, WS_POPUP );
		n_win_exstyle_new( hwnd, WS_EX_TOOLWINDOW );

		n_win_style_dropshadow_onoff( hwnd, n_true );
	} else {
		n_win_popup_autostyle( hwnd, NULL,NULL );
	}


	return;
}

LRESULT CALLBACK
#ifdef _WIN64
n_nmixer_subclass_label( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_nmixer_subclass_label( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

	switch( msg ) {


	case WM_PRINTCLIENT :
	{

		HDC  hdc = (HDC) wparam;
		RECT rect; GetClientRect( hwnd, &rect );

		n_nmixer_draw_label( hwnd, hdc, &rect );

	}
	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc(                     hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc ( nmixer.pfunc_label, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

LRESULT CALLBACK
n_nmixer_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static int vol = 0;

	static n_bool onoff = n_false;

	static UINT timer_id = 0;

	static UINT msg_explorer_crashed = WM_NULL;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam == nmixer.slider_timer_id )
		{

			n_bmp_fade_engine( &nmixer.slider_fade, n_posix_true );
			nmixer.slider.hover_percent = nmixer.slider_fade.percent;

			if ( nmixer.slider_fade.color_fg == n_bmp_black )
			{
				nmixer.slider.hover_percent = 100 - nmixer.slider.hover_percent;
			}

			n_win_refresh( nmixer.slider.hwnd, n_posix_false );

			if ( nmixer.slider_fade.stop ) { n_win_timer_exit( hwnd, nmixer.slider_timer_id ); }

		} else
		if ( wparam == nmixer.timer_id_lnch )
		{

			n_win_timer_exit( hwnd, nmixer.timer_id_lnch );


			n_mixer_get( &vol );


			nmixer.init_onoff = n_true;
			n_win_message_send( hwnd, WM_COMMAND, vol, nmixer.slider.hwnd );


			n_nmixer_automove( hwnd );

			n_nmixer_animatewindow( hwnd, n_true );

			SetForegroundWindow( hwnd );

		} else
		if ( wparam == nmixer.timer_id_main )
		{

			n_win_timer_exit( hwnd, nmixer.timer_id_main );


			onoff = n_false;

		} else 
		if ( wparam == timer_id )
		{

			n_win_timer_exit( hwnd, timer_id );


			n_project_darkmode();

			n_win_init_background( hwnd );
			n_win_refresh( hwnd, n_true );

			n_nmixer_color( GetActiveWindow() );

			n_win_systray_icon_change( &nmixer.nid, nmixer.icon_name, nmixer.icon_index, n_nmixer_icon_supported );

			n_nmixer_autostyle( hwnd );

			n_win_stdfont_init( nmixer.hgui, GUI_MAX );
			n_nmixer_resize( hwnd );

			if ( n_project_dwm_is_on() ) { n_win_dwm_transparent_on( hwnd ); }

			n_win_slider_on_settingchange( &nmixer.slider, n_project_dwm_is_on(), n_nmixer_color_cache );

		}

	break;


	case WM_NCHITTEST :

		ShowWindow( hwnd, SW_NORMAL );

		{
			int code = (int) DefWindowProc( hwnd, msg, wparam, lparam );

			if ( code == HTBOTTOM      ) { return 0; } else
			if ( code == HTBOTTOMLEFT  ) { return 0; } else
			if ( code == HTBOTTOMRIGHT ) { return 0; } else
			if ( code == HTLEFT        ) { return 0; } else
			if ( code == HTRIGHT       ) { return 0; } else
			if ( code == HTTOP         ) { return 0; } else
			if ( code == HTTOPLEFT     ) { return 0; } else
			if ( code == HTTOPRIGHT    ) { return 0; }

		}

	break;


	case WM_CREATE :


		// Global

		n_project_darkmode();

		n_win_exedir2curdir();

		n_nmixer_init();

		n_game_timegettime_init();

		n_win_ime_disable( hwnd );

		msg_explorer_crashed = RegisterWindowMessage( n_posix_literal( "TaskbarCreated" ) );

		n_win_systray_icon_load_callback = n_nmixer_systray_callback;

		nmixer.timer_id_tray = N_PROJECT_SYSTRAY_ID_NMIXER;

		n_nmixer_color( GetActiveWindow() );


		// Window and Style

		nmixer.hwnd = hwnd;

		n_win_init( hwnd, N_NMIXER_APPNAME, N_STRING_EMPTY, N_STRING_EMPTY );

		n_nmixer_autostyle( hwnd );
//n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		if ( n_project_dwm_is_on() ) { n_win_dwm_transparent_on( hwnd ); }

		n_win_gui_literal( hwnd, CANVAS, "", &H_LBL );

		n_win_slider_init( &nmixer.slider, hwnd, 100 );
		n_win_slider_on_settingchange( &nmixer.slider, n_project_dwm_is_on(), n_nmixer_color_cache );
		n_bmp_fade_init( &nmixer.slider_fade, n_bmp_black );

		if ( nmixer.slider_timer_id == 0 ) { nmixer.slider_timer_id = n_win_timer_id_get(); }


		n_win_simplemenu_init( &nmixer.menu );

		n_win_simplemenu_set( &nmixer.menu, 0, NULL, n_posix_literal( "[ ]Register"   ), NULL );
		n_win_simplemenu_set( &nmixer.menu, 1, NULL, n_posix_literal( "[ ]Unregister" ), NULL );
		n_win_simplemenu_set( &nmixer.menu, 2, NULL, n_posix_literal( "[-]"           ), NULL );
		n_win_simplemenu_set( &nmixer.menu, 3, NULL, n_posix_literal( "[ ]Exit"       ), NULL );


#ifdef _WIN64
		SetWindowSubclass( H_LBL, n_nmixer_subclass_label, 0, 0 );
#else  // #ifdef _WIN64
		nmixer.pfunc_label = n_win_gui_subclass_set( H_LBL, n_nmixer_subclass_label );
#endif // #ifdef _WIN64


		// [Needed] : before n_nmixer_resize()

		n_win_topmost( hwnd, n_true );


		// Size

		ShowWindow( hwnd, SW_HIDE );

		n_win_stdfont_init( nmixer.hgui, GUI_MAX );
		n_nmixer_resize( hwnd );


		// Init

		n_nmixer_option();

		if ( nmixer.sticky )
		{

			n_mixer_callback( n_true );

			n_win_systray_init( &nmixer.nid, hwnd, nmixer.timer_id_tray, nmixer.icon_name, N_NMIXER_APPNAME, n_true );

			n_mixer_get( &vol );
			n_nmixer_systray_icon_change_percent = vol;
			n_win_systray_icon_change( &nmixer.nid, nmixer.icon_name, nmixer.icon_index, n_nmixer_icon_supported );

			// [!] : magic : prevent blinking

			SetFocus( GetParent( hwnd ) );

		} else {

			n_win_message_send( hwnd, N_WIN_SYSTRAY_MESSAGE, nmixer.timer_id_tray, N_NMIXER_EVENT_LAUNCH );

		}

	break;


	case WM_PRINTCLIENT :
	{
//break;
		HDC hdc = (HDC) wparam;

		if ( nmixer.border_onoff == n_false )
		{
			n_nmixer_draw_slider_as_bg( hwnd, hdc );
			break;
		}

		RECT r; GetClientRect( hwnd, &r );

		u32 color_fg = n_nmixer_color_cache;
		u32 color_bg = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE );
		u32 color__i = n_bmp_blend_pixel( color_fg, n_bmp_black, 0.15 );
		u32 color__o = n_bmp_blend_pixel( color_fg, n_bmp_black, 0.20 );

		n_win_box( hwnd, hdc, &r, n_bmp_colorref2argb( color__o ) );

		n_win_rect_resize( &r, -1, -1 ); 
		n_win_box( hwnd, hdc, &r, n_bmp_colorref2argb( color_fg ) );

		n_type_gfx border_sx, border_sy; n_nmixer_border_size( &border_sx, &border_sy );
		n_win_rect_resize( &r, -border_sx + 2, -border_sy + 2 ); 
		n_win_box( hwnd, hdc, &r, n_bmp_colorref2argb( color__i ) );

		n_win_rect_resize( &r, -1, -1 ); 
		n_win_box( hwnd, hdc, &r, n_bmp_colorref2argb( color_bg ) );


		n_nmixer_draw_slider_as_bg( hwnd, hdc );

	}
	break;

	case WM_ERASEBKGND :

		if ( n_project_dwm_is_on() )
		{
			return n_true;
		}

	break;

	case WM_PAINT :

		if ( n_project_dwm_is_on() )
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint( hwnd, &ps );

			n_win_box( hwnd, hdc, &ps.rcPaint, 0 );

			EndPaint( hwnd, &ps );
		}

	break;

	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( nmixer.slider.hwnd == di->hwndItem )
		{
			n_nmixer_draw_slider( di->hwndItem, NULL, &di->rcItem );
		} else
		if ( H_LBL == di->hwndItem )
		{
			n_nmixer_draw_label ( di->hwndItem, NULL, &di->rcItem );
		}

	}
	break;


	case WM_KILLFOCUS :
//n_posix_debug_literal( " WM_KILLFOCUS " );

		if ( nmixer.timer_id_main == 0 ) { nmixer.timer_id_main = n_win_timer_id_get(); }
		n_win_timer_init( hwnd, nmixer.timer_id_main, N_NMIXER_TIMER_MSEC );

		if ( nmixer.sticky )
		{
			n_nmixer_animatewindow( hwnd, n_false );
		} else {
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case N_WIN_SYSTRAY_MESSAGE :

		if ( wparam != nmixer.timer_id_tray ) { break; }


		// [Patch] : when using keyboard (tab key to focus)
		//
		//	[ how to debug ]
		//
		//	1 : click desktop
		//	2 : press tab key (start button gets focus)
		//	3 : press tab key ( task switch gets focus)
		//	4 : press tab key ( system tray gets focus)
/*
		if ( n_win_is_input( VK_RETURN ) )
		{
			lparam = N_NMIXER_EVENT_LAUNCH;
		}
*/

		if ( lparam == WM_LBUTTONDBLCLK )
		{

			onoff = n_true;
			n_nmixer_animatewindow( hwnd, n_false );

			n_win_timer_exit( hwnd, nmixer.timer_id_lnch );

			if ( n_false == n_sysinfo_version_vista_or_later() )
			{

				n_win_exec_literal( "sndvol32.exe", SW_NORMAL );

			} else {

				// [!] : n_win_cursor_position()
				//
				//	don't work under high DPI setting when DPI-aware is n_false
				//	see nonnon/project/manifest.xml

				n_type_gfx x = 0;
				n_type_gfx y = 0;
//n_win_cursor_position( &x, &y );

				int taskbar; n_win_taskbarpos( &taskbar, NULL );
				n_type_gfx desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );

				if ( taskbar == ABE_TOP )
				{
					x = desktop_sx;
					y = 0;
				} else
				if ( taskbar == ABE_BOTTOM )
				{
					x = desktop_sx;
					y = desktop_sy;
				} else
				if ( taskbar == ABE_RIGHT )
				{
					x = desktop_sx;
					y = desktop_sy;
				} else
				if ( taskbar == ABE_LEFT )
				{
					x = 0;
					y = desktop_sy;
				}


				u32 pos = x + ( y * 65536 );

				n_posix_char exe[ 100 ];
				n_posix_sprintf_literal( exe, "sndvol.exe -r %lu", pos );
				n_win_exec( exe, SW_NORMAL );

				n_nmixer_animatewindow( hwnd, n_false );

			}

		} else
		if ( lparam == N_NMIXER_EVENT_LAUNCH )
		{

			if ( onoff )
			{
//n_posix_debug_literal( " N_WIN_SYSTRAY_MESSAGE " );

				onoff = n_false;

			} else {

				onoff = n_true;

				if ( nmixer.timer_id_lnch == 0 ) { nmixer.timer_id_lnch = n_win_timer_id_get(); }
				n_win_timer_init( hwnd, nmixer.timer_id_lnch, GetDoubleClickTime() / 2 );

			}

		} else
		if ( lparam == WM_RBUTTONUP )
		{
			if ( n_win_is_input( VK_CONTROL ) )
			{
				// [Needed] : to disappear a popup menu
				SetForegroundWindow( hwnd );
				n_win_simplemenu_show( &nmixer.menu, hwnd );
			} else {
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}
		}// else

	break;

	case WM_KEYDOWN :

		// [x] : focus on taskbar will be lost
		//
		//	system notification icons also lose focus
		//	currently I don't know how to fix

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_KILLFOCUS, 0,0 );
		} else {
			n_nmixer_keydown( hwnd, &vol, (int) wparam );
		}

	break;


	case WM_MOUSEWHEEL :
	{
		int delta = vol - n_win_scrollbar_wheeldelta( wparam, 0, n_false );

		n_win_message_send( hwnd, WM_COMMAND, delta, nmixer.slider.hwnd );
	}
	break;


	case WM_LBUTTONDOWN :
	{

		if ( n_win_is_hovered( nmixer.slider.hwnd ) )
		{

			{
				nmixer.slider.dnd_onoff = n_posix_true;

				SetCapture( hwnd );
			}

			n_nmixer_slider_move( hwnd );
		}

	}
	break;

	case WM_MOUSEMOVE :
	{

		if ( nmixer.slider.dnd_onoff )
		{
			n_nmixer_slider_move( hwnd );
		}

		n_type_gfx x,y,sx,sy; n_win_rect_expand_size( &nmixer.slider.rect_thumb, &x, &y, &sx, &sy );
		if ( n_win_is_hovered_offset( nmixer.slider.hwnd, x,y,sx,sy ) )
		{
//n_posix_debug_literal( "" );
			if ( nmixer.slider_fade.color_fg == n_bmp_black )
			{
				n_bmp_fade_go( &nmixer.slider_fade, n_bmp_white );
				n_win_timer_init( hwnd, nmixer.slider_timer_id, 33 );
			}
		} else {
			if ( nmixer.slider_fade.color_fg == n_bmp_white )
			{
				n_bmp_fade_go( &nmixer.slider_fade, n_bmp_black );
				n_win_timer_init( hwnd, nmixer.slider_timer_id, 33 );
			}
		}

	}
	break;

	case WM_LBUTTONUP :
	{

		if ( nmixer.slider.dnd_onoff )
		{
			n_nmixer_slider_move( hwnd );

			ReleaseCapture();

			nmixer.slider.dnd_onoff = n_posix_false;
		}

	}
	break;




	case WM_COMMAND :

		if ( (HWND) lparam == nmixer.slider.hwnd )
		{

			if ( nmixer.init_onoff == n_false ) { break; }

			vol = n_posix_minmax( 0, 100, (int) wparam );

			n_mixer_set( &vol );

			n_win_hwndprintf_literal( H_LBL, " %3d %% ", vol );

			n_win_refresh( nmixer.slider.hwnd, n_posix_false );

			n_nmixer_systray_icon_change_percent = vol;
			n_win_systray_icon_change( &nmixer.nid, nmixer.icon_name, nmixer.icon_index, n_nmixer_icon_supported );

		} else
		if ( (HWND) lparam == nmixer.menu.hwnd )
		{
			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{
				//
			} else
			if ( wparam == 0 )
			{

				// [x] : Win95 : not supported
				//ShellExecute( hwnd, NULL, n_posix_literal( "shell:startup" ), NULL, NULL, SW_SHOWNORMAL );

				n_posix_char *rval = n_nmixer_startup_commandline();

				n_project_startup_register( N_NMIXER_APPNAME, rval );

				n_string_free( rval );

			} else
			if ( wparam == 1 )
			{

				n_project_startup_unregister( N_NMIXER_APPNAME );

			} else
			if ( wparam == 2 )
			{

				// [!] : Separator

			} else
			if ( wparam == 3 )
			{

				n_win_message_send( hwnd, WM_CLOSE, 0,0 );

			}// else
		}

	break;


	case WM_CLOSE :

		n_nmixer_animatewindow( hwnd, n_false );


		n_mixer_callback( n_false );


		n_win_timer_exit( hwnd, nmixer.timer_id_main );

		n_win_systray_exit( &nmixer.nid );

		n_win_simplemenu_exit( &nmixer.menu );

		n_win_stdfont_exit( nmixer.hgui, GUI_MAX );


		n_win_slider_exit( &nmixer.slider );


#ifdef _WIN64
		RemoveWindowSubclass( H_LBL, n_nmixer_subclass_label, 0 );
#else  // #ifdef _WIN64
		n_win_gui_subclass_set( H_LBL, nmixer.pfunc_label );
#endif // #ifdef _WIN64

		n_string_path_free( nmixer.icon_name );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	if ( msg == msg_explorer_crashed )
	{
		n_win_systray_exit( &nmixer.nid );
		n_win_systray_init( &nmixer.nid, hwnd, nmixer.timer_id_tray, nmixer.icon_name, N_NMIXER_APPNAME, n_true );
	}


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret != 0 ) { return ret; }
	}


	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, &nmixer.menu );


	n_mixer_classic_callback_wndproc( hwnd, msg, wparam, lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_nmixer_wndproc );
}

#endif // #ifndef NONNON_APPS


#undef H_LBL
#undef GUI_MAX

