// Nonnon Game Test
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"
#include "../nonnon/game/chara.c"
#include "../nonnon/game/map.c"
#include "../nonnon/game/progressbar.c"
#include "../nonnon/game/transition.c"


#include "../nonnon/win32/win_richdialog.c"


#include "../nonnon/project/macro.c"


#include "./gametest_anim.c"
#include "./gametest_gradient.c"
#include "./gametest_map.c"
#include "./gametest_progressbar.c"
#include "./gametest_transition.c"




static n_gametest_anim        anim;
static n_gametest_progressbar bar;
static n_gametest_gradient    grade;
static n_gametest_map         map;
static n_gametest_transition  trans;




// nonnon game layer

void
n_game_init( void )
{

	// system

	n_game_title_literal( "Press F1-F5" );

	n_game_window_resizable();


	n_memory_zero( &anim,  sizeof( n_gametest_anim        ) );
	n_memory_zero( &bar,   sizeof( n_gametest_progressbar ) );
	n_memory_zero( &grade, sizeof( n_gametest_gradient    ) );
	n_memory_zero( &map,   sizeof( n_gametest_map         ) );
	n_memory_zero( &trans, sizeof( n_gametest_transition  ) );


	return;
}

void
n_game_loop( void )
{

	static int mode = 0;


	if ( n_win_is_input( VK_F1 ) )
	{
		mode = 1; n_gametest_anim_init( &anim );
	} else
	if ( n_win_is_input( VK_F2 ) )
	{
		mode = 2; n_gametest_progressbar_init( &bar );
	} else
	if ( n_win_is_input( VK_F3 ) )
	{
		mode = 3; n_gametest_gradient_init( &grade );
	} else
	if ( n_win_is_input( VK_F4 ) )
	{
		mode = 4; n_gametest_map_init( &map );
	} else
	if ( n_win_is_input( VK_F5 ) )
	{
		mode = 5; n_gametest_transition_init( &trans );
	} else
	if ( n_win_is_input( VK_F10 ) )
	{

		n_win_richdialog_init( &n_win_richdialog_instance, 2, n_posix_literal( "Nonnon" ) );

		n_gdi *gdi = n_win_richdialog_instance.gdi;

		gdi[ 0 ].icon        = n_string_carboncopy( n_posix_literal( "./gametest.exe"   ) );
		gdi[ 0 ].text        = n_string_carboncopy( n_posix_literal( "Nonnon Game Test" ) );
		gdi[ 0 ].text_style  = gdi[ 0 ].text_style | N_GDI_TEXT_BOLD;

		gdi[ 1 ].text        = n_string_carboncopy( n_posix_literal( "Copyright (c) nonnon All Rights Reserved." ) );

		n_win_richdialog_go( &n_win_richdialog_instance, game.hwnd );

	} else
	if ( n_win_is_input( VK_RETURN ) )
	{

		n_bmp_save_literal( &game.bmp, "./result.bmp" );

	}


	if ( mode == 1 )
	{
		n_gametest_anim_loop( &anim );
	} else
	if ( mode == 2 )
	{
		n_gametest_progressbar_loop( &bar );
	} else
	if ( mode == 3 )
	{
		n_gametest_gradient_loop( &grade );
	} else
	if ( mode == 4 )
	{
		n_gametest_map_loop( &map );
	} else
	if ( mode == 5 )
	{
		n_gametest_transition_loop( &trans );
	}


	return;
}

void
n_game_exit( void )
{

	n_gametest_anim_exit( &anim );
	n_gametest_progressbar_exit( &bar );
	n_gametest_gradient_exit( &grade );
	n_gametest_map_exit( &map );
	n_gametest_transition_exit( &trans );


	return;
}

