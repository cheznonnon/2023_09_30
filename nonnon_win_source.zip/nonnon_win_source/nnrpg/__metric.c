// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "../nonnon/game/game.c"

#include "../nonnon/win32/gdi.c"
#include "../nonnon/project/macro.c"




typedef struct {


	// Zoom

	n_type_gfx zoom;
	n_type_gfx scale;
	n_type_gfx csx, csy;
	n_type_gfx frame_size;


	// Unit

	n_type_gfx unit_bmp;
	n_type_gfx unit_pad;


	// Color

	u32 color_trans;

	u32 color_window_1;
	u32 color_window_2;


	// Position and Size

	n_type_gfx command_x, command_y, command_sx, command_sy;
	n_type_gfx mainwin_x, mainwin_y, mainwin_sx, mainwin_sy;
	n_type_gfx chara_0_x, chara_0_y;
	n_type_gfx chara_1_x, chara_1_y;
	n_type_gfx chara_2_x, chara_2_y;


	// Font

	n_posix_char *font;
	n_type_gfx    textsize;


	// Target Canvas

	n_bmp *bg;
	n_bmp *canvas;


} n_nnrpg_metric_struct;


static n_nnrpg_metric_struct n_nnrpg_metric;




void
n_nnrpg_metric_make( n_bmp *bmp_bg, n_bmp *bmp_canvas )
{

	// Zoom : 1/2/4 only supported

	n_type_gfx desktop_sx; n_win_desktop_size( &desktop_sx, NULL );

	n_nnrpg_metric.zoom = n_posix_max( 1, desktop_sx / 640 );

	{

		n_posix_char *cmdline = n_win_commandline_new();

		n_string_commandline_option_literal( "-nnrpg", cmdline );

		if ( n_posix_atoi( cmdline ) )
		{
			n_nnrpg_metric.zoom = n_posix_max( 1, n_posix_atoi( cmdline ) );
		}

		n_string_free( cmdline );

	}

	if ( n_nnrpg_metric.zoom > 2 ) { n_nnrpg_metric.zoom = n_nnrpg_metric.zoom / 2 * 2; }

	n_nnrpg_metric.csx = 320 * n_nnrpg_metric.zoom;
	n_nnrpg_metric.csy = 240 * n_nnrpg_metric.zoom;

	n_nnrpg_metric.scale = n_nnrpg_metric.zoom / 2;


	// Color

	n_nnrpg_metric.color_trans    = n_bmp_white_invisible;

	n_nnrpg_metric.color_window_1 = n_bmp_argb( 128,  0,100,150 );
	n_nnrpg_metric.color_window_2 = n_bmp_argb( 128,  0,  0, 50 );


	// Position and Size

	n_type_gfx unit_sx = ( n_nnrpg_metric.csx / 4 );
	n_type_gfx unit_sy = ( n_nnrpg_metric.csy / 3 );
	n_type_gfx main_sy = n_nnrpg_metric.csy - unit_sy;


	n_nnrpg_metric.font       = n_project_stdfont();//n_posix_literal( "Arial" );//

	if ( n_nnrpg_metric.zoom == 4 )
	{
		n_nnrpg_metric.textsize   = 15 * n_nnrpg_metric.zoom;
	} else {
		n_nnrpg_metric.textsize   = 16 * n_nnrpg_metric.zoom;
	}

	if ( n_string_is_same_literal( "Arial", n_nnrpg_metric.font ) )
	{
		n_nnrpg_metric.textsize = (n_type_gfx) ( (n_type_real) n_nnrpg_metric.textsize * 0.8 );
	}

	n_nnrpg_metric.frame_size = n_nnrpg_metric.textsize / 3;


	n_nnrpg_metric.command_x  = 0;
	n_nnrpg_metric.command_y  = unit_sy * 2;
	n_nnrpg_metric.command_sx = unit_sx * 1;
	n_nnrpg_metric.command_sy = unit_sy * 1;
	n_nnrpg_metric.mainwin_x  = n_nnrpg_metric.command_sx;
	n_nnrpg_metric.mainwin_y  = n_nnrpg_metric.command_y;
	n_nnrpg_metric.mainwin_sx = unit_sx * 3;
	n_nnrpg_metric.mainwin_sy = unit_sy * 1;


	n_nnrpg_metric.unit_bmp   = 64 * n_nnrpg_metric.zoom;
	n_nnrpg_metric.unit_pad   =  4 * n_nnrpg_metric.zoom;

	n_nnrpg_metric.chara_0_x  = ( unit_sx * 3 ) + n_game_centering( unit_sx * 1, n_nnrpg_metric.unit_bmp / 2 );
	n_nnrpg_metric.chara_1_x  = ( unit_sx * 3 ) + n_game_centering( unit_sx * 1, n_nnrpg_metric.unit_bmp / 2 );
	n_nnrpg_metric.chara_2_x  = ( unit_sx * 0 ) + n_game_centering( unit_sx * 3, n_nnrpg_metric.unit_bmp / 1 );

	n_nnrpg_metric.chara_0_y  = ( main_sy / 2 ) - n_nnrpg_metric.unit_bmp;
	n_nnrpg_metric.chara_1_y  = ( main_sy / 2 );
	n_nnrpg_metric.chara_2_y  = n_game_centering( main_sy / 1, n_nnrpg_metric.unit_bmp );


	// Target Canvas

	n_nnrpg_metric.bg     = bmp_bg;
	n_nnrpg_metric.canvas = bmp_canvas;


	return;
}

