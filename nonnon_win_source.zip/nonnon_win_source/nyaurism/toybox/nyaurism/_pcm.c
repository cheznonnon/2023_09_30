// Nonnon Wave
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <complex.h>
#include <time.h>
#include <limits.h>


#include "../../../nonnon/neutral/type.c"




#define N_PCM_STEREO ( 2 )
#define N_PCM_STEP   sizeof( s16 )

#define N_PCM_2PI    ( 2.0 * M_PI )


#define n_pcm_maxcount( byte ) ( byte / N_PCM_STEP / N_PCM_STEREO )




void __stdcall
n_pcm_blend( s16 *ptr, int i, double l, double r, double ratio_l, double ratio_r )
{

	const int p = i * N_PCM_STEREO;


	l *= ratio_l;
	r *= ratio_r;

	l += (double) ptr[ p + 0 ] * ( 1.0 - ratio_l );
	r += (double) ptr[ p + 1 ] * ( 1.0 - ratio_r );


	ptr[ p + 0 ] = (s16) l;
	ptr[ p + 1 ] = (s16) r;


	return;
}

void __stdcall
n_pcm_get( s16 *ptr, int i, double *l, double *r )
{

	const int p = i * N_PCM_STEREO;


	if ( l != NULL ) { (*l) = (double) ptr[ p + 0 ]; }
	if ( r != NULL ) { (*r) = (double) ptr[ p + 1 ]; }


	return;
}

void __stdcall
n_pcm_set( s16 *ptr, int i, double l, double r )
{

	const int p = i * N_PCM_STEREO;


	ptr[ p + 0 ] = (s16) l;
	ptr[ p + 1 ] = (s16) r;


	return;
}

void __stdcall
n_pcm_normalize( int byte, s16 *ptr, double hz, double depth_l, double depth_r )
{

	const int count = n_pcm_maxcount( byte );


	double hi_l, hi_r;
	double l,r;
	int    i;


	// Phase 1 : get peak value

	i = hi_l = hi_r =0;
	while( 1 )
	{

		n_pcm_get( ptr, i, &l, &r );

		l = fabs( l );
		r = fabs( r );

		if ( hi_l < l ) { hi_l = l; }
		if ( hi_r < r ) { hi_r = r; }


		i++;
		if ( i >= count ) { break; }
	}


	// Phase 2 : apply by ratio

	double a_l = (double) SHRT_MAX * depth_l;
	double a_r = (double) SHRT_MAX * depth_r;


	i = 0;
	while( 1 )
	{

		n_pcm_get( ptr, i, &l, &r );

		if ( hi_l != 0 ) { l = a_l * ( l / hi_l ); }
		if ( hi_r != 0 ) { r = a_r * ( r / hi_r ); }

		n_pcm_set( ptr, i, l, r );


		i++;
		if ( i >= count ) { break; }
	}


	return;
}

