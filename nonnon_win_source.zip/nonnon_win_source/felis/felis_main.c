// Felis
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




n_bool
n_felis_msgloop_shared_process( HWND hwnd, MSG *msg, UINT msg_mousewheel, int version )
{

	static n_bool is_rbutton = n_false;

	if ( msg->message == WM_DROPFILES )
	{

		// [!] : for Windows95 without IE4

		msg->hwnd = hwnd;

	} else
	if (
		( msg->message >= WM_KEYFIRST )
		&&
		( msg->message <= WM_KEYLAST  )
	)
	{

		// [!] : keyboard input event redirector

		n_win_message_send( hwnd, msg->message, msg->wParam, msg->lParam );

		// [!] : to stop single line edit controls beep

		if (
			( msg->message == WM_KEYDOWN )
			&&
			(
				( ( n_win_is_input( VK_CONTROL ) )&&( msg->wParam == 'L' ) )
				||
				( ( n_win_is_input( VK_CONTROL ) )&&( msg->wParam == 'O' ) )
			)
		)
		{
			return n_posix_true;
		}

	} else
	if ( msg->message == WM_RBUTTONDOWN )
	{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " 1 " );

		is_rbutton = n_true;

		GetCursorPos( &n_felis_mousegesture_pt_prv );


		// [Needed] : a cursor will misbehave when in-page anchor

		if ( 9 <= version )
		{
			return n_posix_true;
		}

	} else
	if ( msg->message == WM_MOUSEMOVE )
	{

		if ( is_rbutton )
		{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " 2 " );

			if ( n_win_cursor_is_draggable( hwnd, n_felis_mousegesture_pt_prv ) )
			{
				n_felis_mousegesture_onoff = n_true;
			} else {
				n_felis_mousegesture_onoff = n_false;
			}
		}

	} else
	if ( ( is_rbutton )&&( msg->message == WM_RBUTTONUP ) )
	{

		is_rbutton = n_false;

		if ( n_felis_mousegesture_onoff )
		{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " 3 " );

			n_felis_mousegesture_onoff = n_false;

			n_type_gfx threshold_sx = 0;
			n_type_gfx threshold_sy = 0;
			n_win_mouse_threshold( hwnd, &threshold_sx, &threshold_sy );

			GetCursorPos( &n_felis_mousegesture_pt_cur );

			n_bool is_done = n_false;

			int delta = n_felis_mousegesture_pt_prv.x - n_felis_mousegesture_pt_cur.x;
			if ( delta > threshold_sx )
			{
				is_done = n_true;
				n_WebBrowser_back( n_felis_wb );
			} else
			if ( delta < -threshold_sx )
			{
				is_done = n_true;
				n_WebBrowser_next( n_felis_wb );
			}

			if ( is_done )
			{

				// [Patch] : a context menu will be suppressed when use "continue"

				if ( 9 <= version )
				{
					n_win_message_send( msg->hwnd, WM_RBUTTONDBLCLK, msg->wParam, msg->lParam );
				} else {
					n_win_message_send( msg->hwnd, WM_RBUTTONDOWN,   msg->wParam, msg->lParam );
				}

				return n_posix_true;
			}

		} else {
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " 4 " );

			if ( 9 <= version )
			{
				n_win_message_send( msg->hwnd, WM_RBUTTONDBLCLK, msg->wParam, msg->lParam );
			} else {
				n_win_message_send( msg->hwnd, WM_RBUTTONDOWN,   msg->wParam, msg->lParam );
			}

		}

	}
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), "%d", msg->message );


	n_win_mousewheel_redirector( msg_mousewheel, msg );

/*
	// [x] : stop while wheeling

	if ( n_felis_progress_start )
	{
		//RECT rect; GetClientRect( H_URL, &rect );
		//n_felis_addressbar_draw( H_URL, &rect );

		n_felis_addressbar_proc( hwnd, WM_TIMER, n_felis_progress_timer_id, 0, H_URL );
	}
*/

	n_win_mbutton2centering_proc( msg->hwnd, msg->message, msg->wParam, msg->lParam );


	TranslateMessage( msg );
	DispatchMessage ( msg );


	return n_posix_false;
}

MSG
n_felis_msgloop( HWND hwnd )
{

	int version = n_WebBrowser_version();


	UINT msg_mousewheel = RegisterWindowMessage( n_posix_literal( "MSWHEEL_ROLLMSG" ) );
//if ( msg_mousewheel == WM_NULL ) { n_posix_debug_literal( " WM_NULL " ); }


	MSG msg; ZeroMemory( &msg, sizeof( MSG ) );
	while( 1 <= GetMessage( &msg, NULL, 0, 0 ) )
	{

		if ( n_felis_msgloop_shared_process( hwnd, &msg, msg_mousewheel, version ) )
		{
			continue;
		}

	}


	return msg;
}

WPARAM
n_felis_main( const n_posix_char *mutex, void *wndproc )
{

	HANDLE hmutex = NULL;

	if ( mutex != NULL )
	{
		hmutex = n_win_mutex_init( hmutex, mutex );
		if ( hmutex == NULL ) { return 0; }
	}


	// [!] : WinXP or later : ghost window feature is buggy
	//
	//	XP    : a parent folder or an EXE file will be locked
	//	Vista : removable drive cannot be unplugged
	//	7     : an old EXE file cache is used and keep on crashing

	n_win_ghostwindow_disable();


	n_win_dpi_autoscale_disable();


	HWND hwnd = NULL; n_win_gui( NULL, N_WIN_GUI_WINDOW, wndproc, &hwnd );


	WPARAM wparam = n_felis_msgloop( hwnd ).wParam;


	if ( mutex != NULL )
	{
		hmutex = n_win_mutex_exit( hmutex );
	}


	n_memory_debug_refcount();


	return wparam;
}


