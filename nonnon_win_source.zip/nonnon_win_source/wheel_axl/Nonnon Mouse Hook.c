// Nonnon Wheel Axl
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : Win9x
//
//	WH_MOUSE_LL is not available
//	WH_MOUSE can run but Explorer will crash then system is halt


// [x] : Win10
//
//	SendInput() and mouse_event() beep and don't work accurately
//
//	you cannot unhook when you use mouse_event()
//	even TaskManager cannot unhook
//	system restart is needed


// [x] : mouse driver's bug
//
//	wheeling is unstable when a new input has blank time
//	this logic cannot fix such bug




#include "../nonnon/win32/win.c"




static HHOOK n_mousehook_hhook = NULL;
static HWND  n_mousehook_debug = NULL;
//static int   n_mousehook_shwnd = SW_NORMAL;
static int   n_mousehook_shwnd = SW_HIDE;




#define n_mousehook_is_d( n ) ( n < 0 )
#define n_mousehook_is_u( n ) ( n > 0 )

#define N_MOUSEHOOK_CALL_NEXT_NONE ( 0 )
#define N_MOUSEHOOK_CALL_NEXT_CALL ( 1 )
#define N_MOUSEHOOK_CALL_NEXT_DONE ( 2 )

#define N_MOUSEHOOK_HISTORY_MAX         ( 8 )
#define N_MOUSEHOOK_HISTORY_THRESHOLD   ( 6 )
#define N_MOUSEHOOK_HISTORY_THRESHOLD_2 ( 4 )

void
n_mousehook_history_init( int *history, int value )
{

	int i = 0;
	n_posix_loop
	{

		history[ i ] = value;

		i++;
		if ( i >= N_MOUSEHOOK_HISTORY_MAX ) { break; }
	}


	return;
}

void
n_mousehook_history_set( int *history, int value )
{

	int i = N_MOUSEHOOK_HISTORY_MAX - 1;
	n_posix_loop
	{

		if ( i <= 0 ) { break; }

		history[ i ] = history[ i - 1 ];

		i--;

	}

	history[ 0 ] = value;


	return;
}

LRESULT CALLBACK
n_mousehook_LowLevelMouseProc( int nCode, WPARAM wParam, LPARAM lParam )
{
//n_win_hwndprintf_literal( n_mousehook_debug, " %d ", nCode );
//n_win_debug_count( n_mousehook_debug );


	if ( nCode != HC_ACTION )
	{
		return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
	}


	if ( wParam == WM_MOUSEWHEEL )
	{
//n_posix_debug_literal( "" );
//n_win_debug_count( n_mousehook_debug );


		// [!] : shared

		// [x] : don't rely on p->time

		MSLLHOOKSTRUCT *p = (void*) lParam;

		static int axl = 0;
		static int history[ N_MOUSEHOOK_HISTORY_MAX ] = { 0 };

		u32 time_cur = n_posix_tickcount();
		int delta    = GET_WHEEL_DELTA_WPARAM( p->mouseData );
//n_win_hwndprintf_literal( n_mousehook_debug, " %d ", delta );


		// [!] : Win8.1 : 0 or -1 is set
		// [!] : Win10  : 0 or  1 is set

//n_win_hwndprintf_literal( n_mousehook_debug, "%d", p->flags );


		// [!] : prevent recursive call

		static int call_next = N_MOUSEHOOK_CALL_NEXT_NONE;

		if ( call_next == N_MOUSEHOOK_CALL_NEXT_CALL )
		{
			call_next = N_MOUSEHOOK_CALL_NEXT_DONE;
			return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
		} else
		if ( call_next == N_MOUSEHOOK_CALL_NEXT_DONE )
		{
			call_next = N_MOUSEHOOK_CALL_NEXT_NONE;
		}


		// [!] : timeout

		int threshold = N_MOUSEHOOK_HISTORY_THRESHOLD;

		static u32 time_prv = 0;
		if ( time_prv == 0 ) { time_prv = time_cur; }

		if ( ( time_cur - time_prv ) > 500 )
		{
			axl = 0;

			n_mousehook_history_init( history, 0 );
			n_mousehook_history_set ( history, delta );

			threshold = N_MOUSEHOOK_HISTORY_THRESHOLD_2;

			time_prv = time_cur;

			//call_next = N_MOUSEHOOK_CALL_NEXT_CALL;
			//mouse_event( MOUSEEVENTF_WHEEL, 0,0, delta, 0 );

			//return n_posix_true;
		}

		time_prv = time_cur;


		// [!] : jitter prevention

		static n_posix_bool history_init = n_posix_false;

		if ( history_init == n_posix_false )
		{
			history_init = n_posix_true;
			n_mousehook_history_init( history,     0 );
		} else {
			n_mousehook_history_set ( history, delta );
		}

		int u = 0;
		int d = 0;
		int z = 0;
		int i = 0;
		n_posix_loop
		{

			if ( n_mousehook_is_u( history[ i ] ) )
			{
				u++;
			} else
			if ( n_mousehook_is_d( history[ i ] ) )
			{
				d++;
			} else
			if ( history[ i ] == 0 )
			{
				z++;
			}

			i++;
			if ( i >= N_MOUSEHOOK_HISTORY_MAX ) { break; }
		}

		if ( u >= threshold )
		{
			delta =  WHEEL_DELTA;
		} else
		if ( d >= threshold )
		{
			delta = -WHEEL_DELTA;
		} else
		if ( z >= threshold )
		{
			return n_posix_true;
		}

//n_win_hwndprintf_literal( n_mousehook_debug, " %d ", delta );


		// [!] : calc engine

		const int step_maximum = WHEEL_DELTA * 4;

		if ( axl == 0 ) { axl = 1; } else { axl += axl; }
		axl = n_posix_min( axl, step_maximum );

//n_win_hwndprintf_literal( n_mousehook_debug, " %d ", axl );


		if ( n_mousehook_is_d( delta ) ) { delta -= axl; } else
		if ( n_mousehook_is_u( delta ) ) { delta += axl; }


		// [!] : input engine

		if ( delta )
		{
			call_next = N_MOUSEHOOK_CALL_NEXT_CALL;
			mouse_event( MOUSEEVENTF_WHEEL, 0,0, delta, 0 ); 
		}

/*
		// [x] : Win95 : error dialog will appear

		// [!] : the same as mouse_event()

		INPUT input; ZeroMemory( &input, sizeof( INPUT ) );

		input.type         = INPUT_MOUSE;
		input.mi.mouseData = delta;
		input.mi.dwFlags   = MOUSEEVENTF_WHEEL;

		SendInput( 1, &input, sizeof( INPUT ) );
*/

/*
		// [x] : not working : SetScrollPos() is the same

		SCROLLINFO si = { sizeof( SCROLLINFO ), SIF_ALL, 0,0, 0,0, 0 };

		GetScrollInfo( hwnd, SB_VERT, &si               );
		si.nPos += delta * 10;
		SetScrollInfo( hwnd, SB_VERT, &si, n_posix_true );
*/

		return n_posix_true;
	}


	return CallNextHookEx( n_mousehook_hhook, nCode, wParam, lParam );
}

void WINAPI
n_mousehook_init( HINSTANCE hinst, HWND hwnd_debug )
{

	n_win_exedir2curdir();

	n_mousehook_hhook = SetWindowsHookEx( WH_MOUSE_LL, n_mousehook_LowLevelMouseProc, hinst, 0 );
	n_mousehook_debug = hwnd_debug;

	// [x] : Win9x : ANSI Version :     DLL : ERROR_MOD_NOT_FOUND (126) will be returned
	// [x] : Win9x : ANSI Version : not DLL : zero will be returned but n_mousehook_hhook is NULL

if ( n_mousehook_hhook == NULL ) { n_posix_debug_literal( "%d", GetLastError() ); }

	return;
}

void WINAPI
n_mousehook_exit( void )
{

	UnhookWindowsHookEx( n_mousehook_hhook );

	return;
}


