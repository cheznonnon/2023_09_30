// Nonnon Attrib GUI
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef NONNON_APPS

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef NONNON_APPS




//#define N_MEMORY_DEBUG




#include "../nonnon/win32/explorer.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_checkbox.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/macro.c"




// rc.h

#define H_READONLY             n_attrib_hgui[  0 ]
#define H_HIDDEN               n_attrib_hgui[  1 ]

#define H_SYSTEM               n_attrib_hgui[  2 ]
#define H_DIRECTORY            n_attrib_hgui[  3 ]

#define H_ARCHIVE              n_attrib_hgui[  4 ]
#define H_DEVICE               n_attrib_hgui[  5 ]

#define H_NORMAL               n_attrib_hgui[  6 ]
#define H_TEMPORARY            n_attrib_hgui[  7 ]

#define H_SPARSE_FILE          n_attrib_hgui[  8 ]
#define H_REPARSE_POINT        n_attrib_hgui[  9 ]

#define H_COMPRESSED           n_attrib_hgui[ 10 ]
#define H_OFFLINE              n_attrib_hgui[ 11 ]

#define H_NOT_CONTENT_INDEXED  n_attrib_hgui[ 12 ]

#define GUI_MAX                               13


#define H_BUTTON               n_attrib_button



typedef struct {

	n_type_gfx    x,y;
	n_posix_char *name;
	DWORD         attrib;
	n_bool        onoff;

} n_attrib;




static n_attrib n_attrib_table[ GUI_MAX ] = {

	{ 0, 1, n_posix_literal("Read Only"          ), FILE_ATTRIBUTE_READONLY,            n_true  },
	{ 1, 1, n_posix_literal("Hidden"             ), FILE_ATTRIBUTE_HIDDEN,              n_true  },
	{ 0, 2, n_posix_literal("System"             ), FILE_ATTRIBUTE_SYSTEM,              n_true  },
	{ 1, 2, n_posix_literal("Directory"          ), FILE_ATTRIBUTE_DIRECTORY,           n_false },
	{ 0, 3, n_posix_literal("Archive"            ), FILE_ATTRIBUTE_ARCHIVE,             n_true  },
	{ 1, 3, n_posix_literal("Device"             ), FILE_ATTRIBUTE_DEVICE,              n_false },
	{ 0, 4, n_posix_literal("Normal"             ), FILE_ATTRIBUTE_NORMAL,              n_true  },
	{ 1, 4, n_posix_literal("Temporary"          ), FILE_ATTRIBUTE_TEMPORARY,           n_true  },
	{ 0, 5, n_posix_literal("Sparse File"        ), FILE_ATTRIBUTE_SPARSE_FILE,         n_false },
	{ 1, 5, n_posix_literal("Reparse Point"      ), FILE_ATTRIBUTE_REPARSE_POINT,       n_false },
	{ 0, 6, n_posix_literal("Compressed"         ), FILE_ATTRIBUTE_COMPRESSED,          n_false },
	{ 1, 6, n_posix_literal("Offline"            ), FILE_ATTRIBUTE_OFFLINE,             n_true  },
	{ 0, 7, n_posix_literal("Not Content Indexed"), FILE_ATTRIBUTE_NOT_CONTENT_INDEXED, n_false },

};




static n_win_txtbox n_attrib_fname;
static n_win_button n_attrib_button;

static n_win_check  n_attrib_hgui[ GUI_MAX ];




// internal
void
n_attrib_gui( HWND hwnd )
{

	int i = 0;
	n_posix_loop
	{

		n_attrib *a = &n_attrib_table[ i ];

		int state;
		if ( a->onoff ) { state = CBS_UNCHECKEDNORMAL; } else { state = CBS_UNCHECKEDDISABLED; }
		n_win_check_init( &n_attrib_hgui[ i ], hwnd, a->name, state );

		n_win_check_onoff( &n_attrib_hgui[ i ], a->onoff );


		i++;
		if ( i >= GUI_MAX ) { break; }
	}



	return;
}

// internal
void
n_attrib_newfile( n_posix_char *name )
{

	DWORD attrib;

	if ( n_posix_stat_is_exist( name ) )
	{

		n_win_txtbox_line_set( &n_attrib_fname, 0, name );
		n_win_txtbox_select_tail_set( &n_attrib_fname );

		attrib = GetFileAttributes( name );

	} else {

		n_win_txtbox_line_set( &n_attrib_fname, 0, n_project_string_drophere );

		attrib = 0;

	}

//n_posix_debug_literal( "%s : %d", name, attrib );


	int i = 0;
	n_posix_loop
	{

		n_attrib *a = &n_attrib_table[ i ];

		if ( attrib & a->attrib )
		{
			n_win_check_check  ( &n_attrib_hgui[ i ] );
		} else {
			n_win_check_uncheck( &n_attrib_hgui[ i ] );
		}


		i++;
		if ( i >= GUI_MAX ) { break; }
	}


	return;
}

// internal
void
n_attrib_set( n_posix_char *name )
{

	if ( n_false == n_posix_stat_is_exist( name ) ) { return; }


	DWORD attrib = 0;


	int i = 0;
	n_posix_loop
	{

		n_attrib *a = &n_attrib_table[ i ];

		if ( n_win_check_is_checked( &n_attrib_hgui[ i ] ) ) { attrib |= a->attrib; }


		i++;
		if ( i >= GUI_MAX ) { break; }
	}


	SetFileAttributes( name, attrib );

	n_explorer_refresh( n_true );


	// [!] : refresh : some changes may not be applied

	n_attrib_newfile( name );


	return;
}

void
n_attrib_resize( HWND hwnd, int nwset )
{

	const n_bool redraw = n_false;


	n_type_gfx ctl,m;
	n_win_stdsize( hwnd, &ctl, NULL, &m );


	n_type_gfx csy = ( ctl * 9 );
	n_type_gfx csx = (n_type_gfx) ( (n_type_real) csy * sqrt( 2 ) );

	n_win_set( hwnd, NULL, csx + m, csy + m, nwset );


	n_win_txtbox_move( &n_attrib_fname , 0,       0, csx-1,ctl, redraw );
	n_win_button_move( &n_attrib_button, 0, csy-ctl, csx  ,ctl, redraw );


	int i = 0;
	n_posix_loop
	{

		n_attrib *a = &n_attrib_table[ i ];

		n_type_gfx  x = ( csx / 2 ) * a->x;
		n_type_gfx  y = ctl * a->y;
		n_type_gfx sx = ( csx / 2 );
		n_type_gfx sy = ctl;

		if ( a->attrib == FILE_ATTRIBUTE_NOT_CONTENT_INDEXED ) { sx = csx; }

		n_win_move( n_attrib_hgui[ i ].hwnd, x,y,sx,sy, redraw );


		i++;
		if ( i >= GUI_MAX ) { break; }
	}



	return;
}

void
n_attrib_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_txtbox_on_settingchange( &n_attrib_fname );

		{

			int i = 0;
			n_posix_loop
			{

				n_win_check_on_settingchange( &n_attrib_hgui[ i ] );

				i++;
				if ( i >= GUI_MAX ) { break; }
			}

		}

		n_win_button_on_settingchange( &H_BUTTON );


		n_attrib_resize( hwnd, N_WIN_SET_DEFAULT );

	break;


	} // switch


}

LRESULT CALLBACK
n_attrib_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char *cmdline = NULL;


	n_attrib_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_project_darkmode();
		//n_win_darkmode_onoff = n_true;

		n_win_ime_disable( hwnd );

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET


		// Window

		n_win_init_literal( hwnd, "Nonnon Attrib GUI", "N_ATTRIB_0_MAIN", "" );


		{
			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_ONELINE;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET;
			//option |= N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE;

			n_win_txtbox_zero( &n_attrib_fname );
			n_win_txtbox_init( &n_attrib_fname, hwnd, style, option );
		}

		n_win_button_zero( &H_BUTTON );
		n_win_button_init( &H_BUTTON, hwnd, n_project_string_go, PBS_NORMAL );

		n_win_txtbox_line_set( &n_attrib_fname, 0, n_project_string_drophere );

		n_attrib_gui( hwnd );


		// Style

		n_win_style_new( hwnd, N_WS_FIXEDWINDOW );
		n_win_sysmenu_disable( hwnd, 0,0,1, 0,1, 0, 0 );

		n_attrib_fname.txt.readonly = n_true;
		n_win_txtbox_grayed( &n_attrib_fname, n_true );

		n_win_stdfont_init( &n_attrib_fname.hwnd, 1 );


		// Size

		n_attrib_resize( hwnd, N_WIN_SET_CENTERING );


		// Init

		// [Needed] : this position is important
		//
		//	checkboxes aren't checked when drop to ".exe"


		cmdline = n_win_commandline_new();


#ifdef NONNON_APPS

		// [Needed] : for Nonnon Apps

		n_string_path_commandline_option( N_APPS_OPTION_N_ATTRIB, cmdline, n_false );
		n_string_doublequote_del( cmdline, cmdline );
//n_posix_debug_literal( "%s", cmdline );

#endif // #ifdef NONNON_APPS


		n_attrib_newfile( cmdline );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;

	case WM_DROPFILES :

		n_string_path_free( cmdline );

		cmdline = n_win_dropfiles_multiple_new( hwnd, wparam );

		n_attrib_newfile( cmdline );

	break;

	case WM_COMMAND :

		if ( (HWND) lparam == H_BUTTON.hwnd )
		{
			n_attrib_set( cmdline );
		}

	break;


	case WM_LBUTTONDOWN :

		SetFocus( hwnd );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_string_path_free( cmdline );

		n_win_stdfont_exit( &n_attrib_fname.hwnd, 1 );

		n_win_button_exit( &H_BUTTON );

		n_win_txtbox_exit( &n_attrib_fname );

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY:

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &n_attrib_fname );
		if ( ret ) { return ret; }
	}


	n_win_button_proc( hwnd, msg, wparam, lparam, &H_BUTTON );


	{
		int i = 0;
		n_posix_loop
		{

			n_win_check_proc( hwnd, msg, wparam, lparam, &n_attrib_hgui[ i ] );

			i++;
			if ( i >= GUI_MAX ) { break; }
		}
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef NONNON_APPS

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_attrib_wndproc );
}

#endif // #ifndef NONNON_APPS


#undef H_READONLY
#undef H_HIDDEN

#undef H_SYSTEM
#undef H_DIRECTORY

#undef H_ARCHIVE
#undef H_DEVICE

#undef H_NORMAL
#undef H_TEMPORARY

#undef H_SPARSE_FILE
#undef H_REPARSE_POINT

#undef H_COMPRESSED
#undef H_OFFLINE

#undef H_NOT_CONTENT_INDEXED

#undef GUI_MAX

#undef H_BUTTON

