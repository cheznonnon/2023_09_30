// Nonnon DirectX : DirectInput
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#define UNICODE




#include "../../../nonnon/win32/win.c"

#include "../../../nonnon/project/macro.c"




#include "./DirectInput.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_game_input_DirectInput input;

	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		n_game_input_DirectInput_zero( &input );
		n_game_input_DirectInput_init( &input, hwnd );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_LBUTTONDOWN :

		n_win_hwndprintf_literal
		(
			hwnd,
			"%d %d %d %d",
			n_game_input_DirectInput_loop( &input, VK_UP    ),
			n_game_input_DirectInput_loop( &input, VK_DOWN  ),
			n_game_input_DirectInput_loop( &input, VK_LEFT  ),
			n_game_input_DirectInput_loop( &input, VK_RIGHT )
		);

	break;

	case WM_RBUTTONDOWN :

		n_game_input_DirectInput_vibrate( &input, 60000 );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_game_input_DirectInput_exit( &input );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

