// Nonnon DirectX : DirectInput
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




const GUID GUID_XAxis         = { 0xA36D02E0,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_YAxis         = { 0xA36D02E1,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_ZAxis         = { 0xA36D02E2,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_RxAxis        = { 0xA36D02F4,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_RyAxis        = { 0xA36D02F5,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_RzAxis        = { 0xA36D02E3,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_Slider        = { 0xA36D02E4,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_Button        = { 0xA36D02F0,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_Key           = { 0x55728220,0xD33C,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_POV           = { 0xA36D02F2,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_Unknown       = { 0xA36D02F3,0xC9F3,0x11CF,{ 0xBF,0xC7, 0x44,0x45,0x53,0x54,0x00,0x00 } };
const GUID GUID_ConstantForce = { 0x13541C20,0x8E33,0x11D0,{ 0x9A,0xD0, 0x00,0xA0,0xC9,0xA0,0x6E,0x35 } };
const GUID GUID_Square        = { 0x13541C22,0x8E33,0x11D0,{ 0x9A,0xD0, 0x00,0xA0,0xC9,0xA0,0x6E,0x35 } };


#define DIEB_NOTRIGGER 0xFFFFFFFF


#define DIENUM_STOP          0
#define DIENUM_CONTINUE      1


#define DI8DEVCLASS_ALL      0
#define DI8DEVCLASS_DEVICE   1
#define DI8DEVCLASS_POINTER  2
#define DI8DEVCLASS_KEYBOARD 3
#define DI8DEVCLASS_GAMECTRL 4


#define DIDF_ABSAXIS 0x00000001
#define DIDF_RELAXIS 0x00000002


#define DIEDFL_ALLDEVICES       0x00000000
#define DIEDFL_ATTACHEDONLY     0x00000001
#define DIEDFL_FORCEFEEDBACK    0x00000100
#define DIEDFL_INCLUDEALIASES   0x00010000
#define DIEDFL_INCLUDEPHANTOMS  0x00020000
#define DIEDFL_INCLUDEHIDDEN    0x00040000


#define DIDFT_ALL               0x00000000
#define DIDFT_RELAXIS           0x00000001
#define DIDFT_ABSAXIS           0x00000002
#define DIDFT_AXIS              0x00000003
#define DIDFT_PSHBUTTON         0x00000004
#define DIDFT_TGLBUTTON         0x00000008
#define DIDFT_BUTTON            0x0000000C
#define DIDFT_POV               0x00000010
#define DIDFT_COLLECTION        0x00000040
#define DIDFT_NODATA            0x00000080
#define DIDFT_ANYINSTANCE       0x00FFFF00
#define DIDFT_INSTANCEMASK      DIDFT_ANYINSTANCE
#define DIDFT_FFACTUATOR        0x01000000
#define DIDFT_FFEFFECTTRIGGER   0x02000000
#define DIDFT_OUTPUT            0x10000000
#define DIDFT_VENDORDEFINED     0x04000000
#define DIDFT_ALIAS             0x08000000
#define DIDFT_ENUMCOLLECTION(n) ((WORD)(n) << 8)
#define DIDFT_NOCOLLECTION      0x00FFFF00


#define DIDFT_MAKEINSTANCE(n) ((WORD)(n) << 8)
#define DIDFT_GETTYPE(n)     LOBYTE(n)
#define DIDFT_GETINSTANCE(n) LOWORD((n) >> 8)


#define DIDOI_FFACTUATOR        0x00000001
#define DIDOI_FFEFFECTTRIGGER   0x00000002
#define DIDOI_POLLED            0x00008000
#define DIDOI_ASPECTPOSITION    0x00000100
#define DIDOI_ASPECTVELOCITY    0x00000200
#define DIDOI_ASPECTACCEL       0x00000300
#define DIDOI_ASPECTFORCE       0x00000400
#define DIDOI_ASPECTMASK        0x00000F00
#define DIDOI_GUIDISUSAGE       0x00010000

#define DISCL_EXCLUSIVE         0x00000001
#define DISCL_NONEXCLUSIVE      0x00000002
#define DISCL_FOREGROUND        0x00000004
#define DISCL_BACKGROUND        0x00000008
#define DISCL_NOWINKEY          0x00000010


#define DI_DEGREES      100
#define DI_FFNOMINALMAX 10000
#define DI_SECONDS      1000000


#define DIEFF_OBJECTIDS     0x00000001
#define DIEFF_OBJECTOFFSETS 0x00000002
#define DIEFF_CARTESIAN     0x00000010
#define DIEFF_POLAR         0x00000020
#define DIEFF_SPHERICAL     0x00000040


#define DIES_SOLO       0x00000001
#define DIES_NODOWNLOAD 0x80000000




typedef struct DIJOYSTATE
{

	LONG  lX;
	LONG  lY;
	LONG  lZ;
	LONG  lRx;
	LONG  lRy;
	LONG  lRz;
	LONG  rglSlider[2];
	DWORD rgdwPOV[4];
	BYTE  rgbButtons[32];

} DIJOYSTATE, *LPDIJOYSTATE;

#define DIJOFS_X  FIELD_OFFSET( DIJOYSTATE, lX  )
#define DIJOFS_Y  FIELD_OFFSET( DIJOYSTATE, lY  )
#define DIJOFS_Z  FIELD_OFFSET( DIJOYSTATE, lZ  )
#define DIJOFS_RX FIELD_OFFSET( DIJOYSTATE, lRx )
#define DIJOFS_RY FIELD_OFFSET( DIJOYSTATE, lRy )
#define DIJOFS_RZ FIELD_OFFSET( DIJOYSTATE, lRz )

#define DIJOFS_SLIDER(n)   ( FIELD_OFFSET( DIJOYSTATE, rglSlider ) + (n) * sizeof( LONG  ) )
#define DIJOFS_POV(n)      ( FIELD_OFFSET( DIJOYSTATE, rgdwPOV   ) + (n) * sizeof( DWORD ) )
#define DIJOFS_BUTTON(n)   ( FIELD_OFFSET( DIJOYSTATE, rgbButtons) + (n)                   )

#define DIJOFS_BUTTON0      DIJOFS_BUTTON(0)
#define DIJOFS_BUTTON1      DIJOFS_BUTTON(1)
#define DIJOFS_BUTTON2      DIJOFS_BUTTON(2)
#define DIJOFS_BUTTON3      DIJOFS_BUTTON(3)
#define DIJOFS_BUTTON4      DIJOFS_BUTTON(4)
#define DIJOFS_BUTTON5      DIJOFS_BUTTON(5)
#define DIJOFS_BUTTON6      DIJOFS_BUTTON(6)
#define DIJOFS_BUTTON7      DIJOFS_BUTTON(7)
#define DIJOFS_BUTTON8      DIJOFS_BUTTON(8)
#define DIJOFS_BUTTON9      DIJOFS_BUTTON(9)
#define DIJOFS_BUTTON10     DIJOFS_BUTTON(10)
#define DIJOFS_BUTTON11     DIJOFS_BUTTON(11)
#define DIJOFS_BUTTON12     DIJOFS_BUTTON(12)
#define DIJOFS_BUTTON13     DIJOFS_BUTTON(13)
#define DIJOFS_BUTTON14     DIJOFS_BUTTON(14)
#define DIJOFS_BUTTON15     DIJOFS_BUTTON(15)
#define DIJOFS_BUTTON16     DIJOFS_BUTTON(16)


typedef struct DIDEVCAPS
{

	DWORD dwSize;
	DWORD dwFlags;
	DWORD dwDevType;
	DWORD dwAxes;
	DWORD dwButtons;
	DWORD dwPOVs;
	DWORD dwFFSamplePeriod;
	DWORD dwFFMinTimeResolution;
	DWORD dwFirmwareRevision;
	DWORD dwHardwareRevision;
	DWORD dwFFDriverVersion;

} DIDEVCAPS, *LPDIDEVCAPS;

typedef struct DIDEVICEOBJECTINSTANCEA
{

	DWORD dwSize;
	GUID  guidType;
	DWORD dwOfs;
	DWORD dwType;
	DWORD dwFlags;
	CHAR  tszName[MAX_PATH];
	DWORD dwFFMaxForce;
	DWORD dwFFForceResolution;
	WORD  wCollectionNumber;
	WORD  wDesignatorIndex;
	WORD  wUsagePage;
	WORD  wUsage;
	DWORD dwDimension;
	WORD  wExponent;
	WORD  wReportId;

} DIDEVICEOBJECTINSTANCEA, *LPDIDEVICEOBJECTINSTANCEA;

typedef struct DIDEVICEOBJECTINSTANCEW
{

	DWORD dwSize;
	GUID  guidType;
	DWORD dwOfs;
	DWORD dwType;
	DWORD dwFlags;
	WCHAR tszName[MAX_PATH];
	DWORD dwFFMaxForce;
	DWORD dwFFForceResolution;
	WORD  wCollectionNumber;
	WORD  wDesignatorIndex;
	WORD  wUsagePage;
	WORD  wUsage;
	DWORD dwDimension;
	WORD  wExponent;
	WORD  wReportId;

} DIDEVICEOBJECTINSTANCEW, *LPDIDEVICEOBJECTINSTANCEW;

#ifdef UNICODE
typedef DIDEVICEOBJECTINSTANCEW DIDEVICEOBJECTINSTANCE;
typedef LPDIDEVICEOBJECTINSTANCEW LPDIDEVICEOBJECTINSTANCE;
#else  // #ifdef UNICODE
typedef DIDEVICEOBJECTINSTANCEA DIDEVICEOBJECTINSTANCE;
typedef LPDIDEVICEOBJECTINSTANCEA LPDIDEVICEOBJECTINSTANCE;
#endif // #ifdef UNICODE
typedef const DIDEVICEOBJECTINSTANCEA *LPCDIDEVICEOBJECTINSTANCEA;
typedef const DIDEVICEOBJECTINSTANCEW *LPCDIDEVICEOBJECTINSTANCEW;
typedef const DIDEVICEOBJECTINSTANCE  *LPCDIDEVICEOBJECTINSTANCE;

typedef BOOL (FAR PASCAL * LPDIENUMDEVICEOBJECTSCALLBACKA)(LPCDIDEVICEOBJECTINSTANCEA, LPVOID);
typedef BOOL (FAR PASCAL * LPDIENUMDEVICEOBJECTSCALLBACKW)(LPCDIDEVICEOBJECTINSTANCEW, LPVOID);
#ifdef UNICODE
#define LPDIENUMDEVICEOBJECTSCALLBACK  LPDIENUMDEVICEOBJECTSCALLBACKW
#else  // #ifdef UNICODE
#define LPDIENUMDEVICEOBJECTSCALLBACK  LPDIENUMDEVICEOBJECTSCALLBACKA
#endif // #ifdef UNICODE


#ifndef D3DCOLOR_DEFINED

typedef DWORD D3DCOLOR;
#define D3DCOLOR_DEFINED

#endif // #ifndef D3DCOLOR_DEFINED

typedef struct _DICOLORSET
{

	DWORD    dwSize;
	D3DCOLOR cTextFore;
	D3DCOLOR cTextHighlight;
	D3DCOLOR cCalloutLine;
	D3DCOLOR cCalloutHighlight;
	D3DCOLOR cBorder;
	D3DCOLOR cControlFill;
	D3DCOLOR cHighlightFill;
	D3DCOLOR cAreaFill;

} DICOLORSET, *LPDICOLORSET;

typedef const DICOLORSET *LPCDICOLORSET;


typedef struct DIPROPHEADER
{

    DWORD dwSize;
    DWORD dwHeaderSize;
    DWORD dwObj;
    DWORD dwHow;

} DIPROPHEADER, *LPDIPROPHEADER;

typedef const DIPROPHEADER *LPCDIPROPHEADER;


typedef struct DIDEVICEOBJECTDATA
{

    DWORD    dwOfs;
    DWORD    dwData;
    DWORD    dwTimeStamp;
    DWORD    dwSequence;
    UINT_PTR uAppData;

} DIDEVICEOBJECTDATA, *LPDIDEVICEOBJECTDATA;

typedef const DIDEVICEOBJECTDATA *LPCDIDEVICEOBJECTDATA;


typedef struct DIOBJECTDATAFORMAT
{

	CONST GUID *pguid;
	DWORD       dwOfs;
	DWORD       dwType;
	DWORD       dwFlags;

} DIOBJECTDATAFORMAT, *LPDIOBJECTDATAFORMAT;

typedef const DIOBJECTDATAFORMAT *LPCDIOBJECTDATAFORMAT;


typedef struct DIDATAFORMAT
{

	DWORD                dwSize;
	DWORD                dwObjSize;
	DWORD                dwFlags;
	DWORD                dwDataSize;
	DWORD                dwNumObjs;
	LPDIOBJECTDATAFORMAT rgodf;

} DIDATAFORMAT, *LPDIDATAFORMAT;

typedef const DIDATAFORMAT *LPCDIDATAFORMAT;


typedef struct DIDEVICEINSTANCEA
{

	DWORD dwSize;
	GUID  guidInstance;
	GUID  guidProduct;
	DWORD dwDevType;
	CHAR  tszInstanceName[ MAX_PATH ];
	CHAR  tszProductName[ MAX_PATH ];
	GUID  guidFFDriver;
	WORD  wUsagePage;
	WORD  wUsage;

} DIDEVICEINSTANCEA, *LPDIDEVICEINSTANCEA;

typedef struct DIDEVICEINSTANCEW
{

	DWORD dwSize;
	GUID  guidInstance;
	GUID  guidProduct;
	DWORD dwDevType;
	WCHAR tszInstanceName[ MAX_PATH ];
	WCHAR tszProductName[ MAX_PATH ];
	GUID  guidFFDriver;
	WORD  wUsagePage;
	WORD  wUsage;

} DIDEVICEINSTANCEW, *LPDIDEVICEINSTANCEW;

#ifdef UNICODE
typedef DIDEVICEINSTANCEW   DIDEVICEINSTANCE;
typedef LPDIDEVICEINSTANCEW LPDIDEVICEINSTANCE;
#else  // #ifdef UNICODE
typedef DIDEVICEINSTANCEA   DIDEVICEINSTANCE;
typedef LPDIDEVICEINSTANCEA LPDIDEVICEINSTANCE;
#endif // #ifdef UNICODE

typedef const DIDEVICEINSTANCEA *LPCDIDEVICEINSTANCEA;
typedef const DIDEVICEINSTANCEW *LPCDIDEVICEINSTANCEW;

typedef const DIDEVICEINSTANCE  *LPCDIDEVICEINSTANCE;


typedef BOOL (FAR PASCAL * LPDIENUMDEVICESCALLBACKA)(LPCDIDEVICEINSTANCEA, LPVOID);
typedef BOOL (FAR PASCAL * LPDIENUMDEVICESCALLBACKW)(LPCDIDEVICEINSTANCEW, LPVOID);

#ifdef UNICODE
#define LPDIENUMDEVICESCALLBACK  LPDIENUMDEVICESCALLBACKW
#else  // #ifdef UNICODE
#define LPDIENUMDEVICESCALLBACK  LPDIENUMDEVICESCALLBACKA
#endif // #ifdef UNICODE


typedef BOOL (FAR PASCAL * LPDICONFIGUREDEVICESCALLBACK)(IUnknown FAR *, LPVOID);


typedef struct DIENVELOPE
{

	DWORD dwSize;
	DWORD dwAttackLevel;
	DWORD dwAttackTime;
	DWORD dwFadeLevel;
	DWORD dwFadeTime;

} DIENVELOPE, *LPDIENVELOPE;

typedef const DIENVELOPE *LPCDIENVELOPE;


typedef struct DICONSTANTFORCE
{
	LONG lMagnitude;

} DICONSTANTFORCE, *LPDICONSTANTFORCE;

typedef const DICONSTANTFORCE *LPCDICONSTANTFORCE;


typedef struct DIEFFECT
{

	DWORD        dwSize;
	DWORD        dwFlags;
	DWORD        dwDuration;
	DWORD        dwSamplePeriod;
	DWORD        dwGain;
	DWORD        dwTriggerButton;
	DWORD        dwTriggerRepeatInterval;
	DWORD        cAxes;
	LPDWORD      rgdwAxes;
	LPLONG       rglDirection;
	LPDIENVELOPE lpEnvelope;
	DWORD        cbTypeSpecificParams;
	LPVOID       lpvTypeSpecificParams;
	DWORD        dwStartDelay;

} DIEFFECT, *LPDIEFFECT;

typedef DIEFFECT        DIEFFECT_DX6;
typedef LPDIEFFECT      LPDIEFFECT_DX6;
typedef const DIEFFECT *LPCDIEFFECT;


typedef struct DIEFFESCAPE
{

	DWORD  dwSize;
	DWORD  dwCommand;
	LPVOID lpvInBuffer;
	DWORD  cbInBuffer;
	LPVOID lpvOutBuffer;
	DWORD  cbOutBuffer;

} DIEFFESCAPE, *LPDIEFFESCAPE;


typedef struct DIEFFECTINFOA
{

	DWORD dwSize;
	GUID  guid;
	DWORD dwEffType;
	DWORD dwStaticParams;
	DWORD dwDynamicParams;
	CHAR  tszName[MAX_PATH];

} DIEFFECTINFOA, *LPDIEFFECTINFOA;

typedef struct DIEFFECTINFOW
{

	DWORD dwSize;
	GUID  guid;
	DWORD dwEffType;
	DWORD dwStaticParams;
	DWORD dwDynamicParams;
	WCHAR tszName[MAX_PATH];

} DIEFFECTINFOW, *LPDIEFFECTINFOW;

#ifdef UNICODE
typedef DIEFFECTINFOW DIEFFECTINFO;
typedef LPDIEFFECTINFOW LPDIEFFECTINFO;
#else  // #ifdef UNICODE
typedef DIEFFECTINFOA DIEFFECTINFO;
typedef LPDIEFFECTINFOA LPDIEFFECTINFO;
#endif // #ifdef UNICODE

typedef const DIEFFECTINFOA *LPCDIEFFECTINFOA;
typedef const DIEFFECTINFOW *LPCDIEFFECTINFOW;
typedef const DIEFFECTINFO  *LPCDIEFFECTINFO;


typedef BOOL (FAR PASCAL * LPDIENUMEFFECTSCALLBACKA)(LPCDIEFFECTINFOA, LPVOID);
typedef BOOL (FAR PASCAL * LPDIENUMEFFECTSCALLBACKW)(LPCDIEFFECTINFOW, LPVOID);

#ifdef UNICODE
#define LPDIENUMEFFECTSCALLBACK  LPDIENUMEFFECTSCALLBACKW
#else   // #ifdef UNICODE
#define LPDIENUMEFFECTSCALLBACK  LPDIENUMEFFECTSCALLBACKA
#endif // #ifdef UNICODE


typedef struct DIFILEEFFECT
{

    DWORD       dwSize;
    GUID        GuidEffect;
    LPCDIEFFECT lpDiEffect;
    CHAR        szFriendlyName[ MAX_PATH ];

}DIFILEEFFECT, *LPDIFILEEFFECT;

typedef const DIFILEEFFECT *LPCDIFILEEFFECT;

typedef BOOL (FAR PASCAL * LPDIENUMEFFECTSINFILECALLBACK)(LPCDIFILEEFFECT , LPVOID);


typedef struct _DIACTIONA
{

	UINT_PTR       uAppData;
	DWORD          dwSemantic;
	OPTIONAL DWORD dwFlags;
	OPTIONAL union
	{
		LPCSTR lptszActionName;
		UINT   uResIdString;
	};
	OPTIONAL GUID  guidInstance;
	OPTIONAL DWORD dwObjID;
	OPTIONAL DWORD dwHow;

} DIACTIONA, *LPDIACTIONA;

typedef struct _DIACTIONW
{

	UINT_PTR       uAppData;
	DWORD          dwSemantic;
	OPTIONAL DWORD dwFlags;
	OPTIONAL union
	{
		LPCWSTR lptszActionName;
		UINT    uResIdString;
	};
	OPTIONAL GUID  guidInstance;
	OPTIONAL DWORD dwObjID;
	OPTIONAL DWORD dwHow;

} DIACTIONW, *LPDIACTIONW;

#ifdef UNICODE
typedef DIACTIONW   DIACTION;
typedef LPDIACTIONW LPDIACTION;
#else  // #ifdef UNICODE
typedef DIACTIONA   DIACTION;
typedef LPDIACTIONA LPDIACTION;
#endif // #ifdef UNICODE


typedef struct _DIACTIONFORMATA
{
	DWORD              dwSize;
	DWORD              dwActionSize;
	DWORD              dwDataSize;
	DWORD              dwNumActions;
	LPDIACTIONA        rgoAction;
	GUID               guidActionMap;
	DWORD              dwGenre;
	DWORD              dwBufferSize;
	OPTIONAL LONG      lAxisMin;
	OPTIONAL LONG      lAxisMax;
	OPTIONAL HINSTANCE hInstString;
	FILETIME           ftTimeStamp;
	DWORD              dwCRC;
	CHAR               tszActionMap[ MAX_PATH ];

} DIACTIONFORMATA, *LPDIACTIONFORMATA;

typedef struct _DIACTIONFORMATW
{

	DWORD              dwSize;
	DWORD              dwActionSize;
	DWORD              dwDataSize;
	DWORD              dwNumActions;
	LPDIACTIONW        rgoAction;
	GUID               guidActionMap;
	DWORD              dwGenre;
	DWORD              dwBufferSize;
	OPTIONAL LONG      lAxisMin;
	OPTIONAL LONG      lAxisMax;
	OPTIONAL HINSTANCE hInstString;
	FILETIME           ftTimeStamp;
	DWORD              dwCRC;
	WCHAR              tszActionMap[ MAX_PATH ];

} DIACTIONFORMATW, *LPDIACTIONFORMATW;

#ifdef UNICODE
typedef DIACTIONFORMATW   DIACTIONFORMAT;
typedef LPDIACTIONFORMATW LPDIACTIONFORMAT;
#else  // #ifdef UNICODE
typedef DIACTIONFORMATA   DIACTIONFORMAT;
typedef LPDIACTIONFORMATA LPDIACTIONFORMAT;
#endif // #ifdef UNICODE

typedef const DIACTIONFORMATA *LPCDIACTIONFORMATA;
typedef const DIACTIONFORMATW *LPCDIACTIONFORMATW;
typedef const DIACTIONFORMAT  *LPCDIACTIONFORMAT;


typedef struct _DIDEVICEIMAGEINFOA
{
	CHAR tszImagePath[ MAX_PATH ];
	DWORD dwFlags;
	DWORD dwViewID;
	RECT  rcOverlay;
	DWORD dwObjID;
	DWORD dwcValidPts;
	POINT rgptCalloutLine[5];
	RECT  rcCalloutRect;
	DWORD dwTextAlign;
 
} DIDEVICEIMAGEINFOA, *LPDIDEVICEIMAGEINFOA;

typedef struct _DIDEVICEIMAGEINFOW
{

	WCHAR tszImagePath[ MAX_PATH ];
	DWORD dwFlags;
	DWORD dwViewID;
	RECT  rcOverlay;
	DWORD dwObjID;
	DWORD dwcValidPts;
	POINT rgptCalloutLine[ 5 ];
	RECT  rcCalloutRect;
	DWORD dwTextAlign;
   
} DIDEVICEIMAGEINFOW, *LPDIDEVICEIMAGEINFOW;

#ifdef UNICODE
typedef DIDEVICEIMAGEINFOW   DIDEVICEIMAGEINFO;
typedef LPDIDEVICEIMAGEINFOW LPDIDEVICEIMAGEINFO;
#else  // #ifdef UNICODE
typedef DIDEVICEIMAGEINFOA   DIDEVICEIMAGEINFO;
typedef LPDIDEVICEIMAGEINFOA LPDIDEVICEIMAGEINFO;
#endif // #ifdef UNICODE

typedef const DIDEVICEIMAGEINFOA *LPCDIDEVICEIMAGEINFOA;
typedef const DIDEVICEIMAGEINFOW *LPCDIDEVICEIMAGEINFOW;


typedef struct _DIDEVICEIMAGEINFOHEADERA
{

	DWORD                dwSize;
	DWORD                dwSizeImageInfo;
	DWORD                dwcViews;
	DWORD                dwcButtons;
	DWORD                dwcAxes;
	DWORD                dwcPOVs;
	DWORD                dwBufferSize;
	DWORD                dwBufferUsed;

	LPDIDEVICEIMAGEINFOA lprgImageInfoArray;

} DIDEVICEIMAGEINFOHEADERA, *LPDIDEVICEIMAGEINFOHEADERA;

typedef struct _DIDEVICEIMAGEINFOHEADERW
{

	DWORD		     dwSize;
	DWORD    	     dwSizeImageInfo;
	DWORD		     dwcViews;
	DWORD		     dwcButtons;
	DWORD		     dwcAxes;
	DWORD                dwcPOVs;
	DWORD                dwBufferSize;
	DWORD                dwBufferUsed;
	LPDIDEVICEIMAGEINFOW lprgImageInfoArray;

} DIDEVICEIMAGEINFOHEADERW, *LPDIDEVICEIMAGEINFOHEADERW;

#ifdef UNICODE
typedef DIDEVICEIMAGEINFOHEADERW   DIDEVICEIMAGEINFOHEADER;
typedef LPDIDEVICEIMAGEINFOHEADERW LPDIDEVICEIMAGEINFOHEADER;
#else  // #ifdef UNICODE
typedef DIDEVICEIMAGEINFOHEADERA   DIDEVICEIMAGEINFOHEADER;
typedef LPDIDEVICEIMAGEINFOHEADERA LPDIDEVICEIMAGEINFOHEADER;
#endif // #ifdef UNICODE

typedef const DIDEVICEIMAGEINFOHEADERA *LPCDIDEVICEIMAGEINFOHEADERA;
typedef const DIDEVICEIMAGEINFOHEADERW *LPCDIDEVICEIMAGEINFOHEADERW;


typedef struct _DICONFIGUREDEVICESPARAMSA
{
	DWORD              dwSize;
	DWORD              dwcUsers;
	LPSTR              lptszUserNames;
	DWORD              dwcFormats;
	LPDIACTIONFORMATA  lprgFormats;
	HWND               hwnd;
	DICOLORSET         dics;
	IUnknown FAR      *lpUnkDDSTarget;

} DICONFIGUREDEVICESPARAMSA, *LPDICONFIGUREDEVICESPARAMSA;

typedef struct _DICONFIGUREDEVICESPARAMSW
{

	DWORD              dwSize;
	DWORD              dwcUsers;
	LPWSTR             lptszUserNames;
	DWORD              dwcFormats;
	LPDIACTIONFORMATW  lprgFormats;
	HWND               hwnd;
	DICOLORSET         dics;
	IUnknown FAR      *lpUnkDDSTarget;

} DICONFIGUREDEVICESPARAMSW, *LPDICONFIGUREDEVICESPARAMSW;

#ifdef UNICODE
typedef DICONFIGUREDEVICESPARAMSW   DICONFIGUREDEVICESPARAMS;
typedef LPDICONFIGUREDEVICESPARAMSW LPDICONFIGUREDEVICESPARAMS;
#else  // #ifdef UNICODE
typedef DICONFIGUREDEVICESPARAMSA   DICONFIGUREDEVICESPARAMS;
typedef LPDICONFIGUREDEVICESPARAMSA LPDICONFIGUREDEVICESPARAMS;
#endif // #ifdef UNICODE

typedef const DICONFIGUREDEVICESPARAMSA *LPCDICONFIGUREDEVICESPARAMSA;
typedef const DICONFIGUREDEVICESPARAMSW *LPCDICONFIGUREDEVICESPARAMSW;


typedef struct DIPERIODIC
{

	DWORD dwMagnitude;
	LONG  lOffset;
	DWORD dwPhase;
	DWORD dwPeriod;

} DIPERIODIC, *LPDIPERIODIC;

typedef const DIPERIODIC *LPCDIPERIODIC;


typedef struct DIPROPRANGE
{

	DIPROPHEADER diph;
	LONG         lMin;
	LONG         lMax;

} DIPROPRANGE, *LPDIPROPRANGE;




EXTERN_C const IID IID_IDirectInputEffect;
#define INTERFACE IDirectInputEffect
DECLARE_INTERFACE_(IDirectInputEffect, IUnknown)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;

	STDMETHOD(Initialize)(THIS_ HINSTANCE,DWORD,REFGUID) PURE;
	STDMETHOD(GetEffectGuid)(THIS_ LPGUID) PURE;
	STDMETHOD(GetParameters)(THIS_ LPDIEFFECT,DWORD) PURE;
	STDMETHOD(SetParameters)(THIS_ LPCDIEFFECT,DWORD) PURE;
	STDMETHOD(Start)(THIS_ DWORD,DWORD) PURE;
	STDMETHOD(Stop)(THIS) PURE;
	STDMETHOD(GetEffectStatus)(THIS_ LPDWORD) PURE;
	STDMETHOD(Download)(THIS) PURE;
	STDMETHOD(Unload)(THIS) PURE;
	STDMETHOD(Escape)(THIS_ LPDIEFFESCAPE) PURE;
};
#undef INTERFACE


typedef struct IDirectInputEffect *LPDIRECTINPUTEFFECT;


#define IDirectInputEffect_QueryInterface(p,a,b) (p)->lpVtbl->QueryInterface(p,a,b)
#define IDirectInputEffect_AddRef(p) (p)->lpVtbl->AddRef(p)
#define IDirectInputEffect_Release(p) (p)->lpVtbl->Release(p)
#define IDirectInputEffect_Initialize(p,a,b,c) (p)->lpVtbl->Initialize(p,a,b,c)
#define IDirectInputEffect_GetEffectGuid(p,a) (p)->lpVtbl->GetEffectGuid(p,a)
#define IDirectInputEffect_GetParameters(p,a,b) (p)->lpVtbl->GetParameters(p,a,b)
#define IDirectInputEffect_SetParameters(p,a,b) (p)->lpVtbl->SetParameters(p,a,b)
#define IDirectInputEffect_Start(p,a,b) (p)->lpVtbl->Start(p,a,b)
#define IDirectInputEffect_Stop(p) (p)->lpVtbl->Stop(p)
#define IDirectInputEffect_GetEffectStatus(p,a) (p)->lpVtbl->GetEffectStatus(p,a)
#define IDirectInputEffect_Download(p) (p)->lpVtbl->Download(p)
#define IDirectInputEffect_Unload(p) (p)->lpVtbl->Unload(p)
#define IDirectInputEffect_Escape(p,a) (p)->lpVtbl->Escape(p,a)


typedef BOOL (FAR PASCAL * LPDIENUMCREATEDEFFECTOBJECTSCALLBACK)(LPDIRECTINPUTEFFECT, LPVOID);




EXTERN_C const IID IID_IDirectInputDevice8W;
#define INTERFACE IDirectInputDevice8W
DECLARE_INTERFACE_(IDirectInputDevice8W, IUnknown)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;

	STDMETHOD(GetCapabilities)(THIS_ LPDIDEVCAPS) PURE;
	STDMETHOD(EnumObjects)(THIS_ LPDIENUMDEVICEOBJECTSCALLBACKW,LPVOID,DWORD) PURE;
	STDMETHOD(GetProperty)(THIS_ REFGUID,LPDIPROPHEADER) PURE;
	STDMETHOD(SetProperty)(THIS_ REFGUID,LPCDIPROPHEADER) PURE;
	STDMETHOD(Acquire)(THIS) PURE;
	STDMETHOD(Unacquire)(THIS) PURE;
	STDMETHOD(GetDeviceState)(THIS_ DWORD,LPVOID) PURE;
	STDMETHOD(GetDeviceData)(THIS_ DWORD,LPDIDEVICEOBJECTDATA,LPDWORD,DWORD) PURE;
	STDMETHOD(SetDataFormat)(THIS_ LPCDIDATAFORMAT) PURE;
	STDMETHOD(SetEventNotification)(THIS_ HANDLE) PURE;
	STDMETHOD(SetCooperativeLevel)(THIS_ HWND,DWORD) PURE;
	STDMETHOD(GetObjectInfo)(THIS_ LPDIDEVICEOBJECTINSTANCEW,DWORD,DWORD) PURE;
	STDMETHOD(GetDeviceInfo)(THIS_ LPDIDEVICEINSTANCEW) PURE;
	STDMETHOD(RunControlPanel)(THIS_ HWND,DWORD) PURE;
	STDMETHOD(Initialize)(THIS_ HINSTANCE,DWORD,REFGUID) PURE;
	STDMETHOD(CreateEffect)(THIS_ REFGUID,LPCDIEFFECT,LPDIRECTINPUTEFFECT *,LPUNKNOWN) PURE;
	STDMETHOD(EnumEffects)(THIS_ LPDIENUMEFFECTSCALLBACKW,LPVOID,DWORD) PURE;
	STDMETHOD(GetEffectInfo)(THIS_ LPDIEFFECTINFOW,REFGUID) PURE;
	STDMETHOD(GetForceFeedbackState)(THIS_ LPDWORD) PURE;
	STDMETHOD(SendForceFeedbackCommand)(THIS_ DWORD) PURE;
	STDMETHOD(EnumCreatedEffectObjects)(THIS_ LPDIENUMCREATEDEFFECTOBJECTSCALLBACK,LPVOID,DWORD) PURE;
	STDMETHOD(Escape)(THIS_ LPDIEFFESCAPE) PURE;
	STDMETHOD(Poll)(THIS) PURE;
	STDMETHOD(SendDeviceData)(THIS_ DWORD,LPCDIDEVICEOBJECTDATA,LPDWORD,DWORD) PURE;
	STDMETHOD(EnumEffectsInFile)(THIS_ LPCWSTR,LPDIENUMEFFECTSINFILECALLBACK,LPVOID,DWORD) PURE;
	STDMETHOD(WriteEffectToFile)(THIS_ LPCWSTR,DWORD,LPDIFILEEFFECT,DWORD) PURE;
	STDMETHOD(BuildActionMap)(THIS_ LPDIACTIONFORMATW,LPCWSTR,DWORD) PURE;
	STDMETHOD(SetActionMap)(THIS_ LPDIACTIONFORMATW,LPCWSTR,DWORD) PURE;
	STDMETHOD(GetImageInfo)(THIS_ LPDIDEVICEIMAGEINFOHEADERW) PURE;
};
#undef INTERFACE

typedef struct IDirectInputDevice8W *LPDIRECTINPUTDEVICE8W;


EXTERN_C const IID IID_IDirectInputDevice8A;
#define INTERFACE IDirectInputDevice8A
DECLARE_INTERFACE_(IDirectInputDevice8A, IUnknown)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;

	STDMETHOD(GetCapabilities)(THIS_ LPDIDEVCAPS) PURE;
	STDMETHOD(EnumObjects)(THIS_ LPDIENUMDEVICEOBJECTSCALLBACKA,LPVOID,DWORD) PURE;
	STDMETHOD(GetProperty)(THIS_ REFGUID,LPDIPROPHEADER) PURE;
	STDMETHOD(SetProperty)(THIS_ REFGUID,LPCDIPROPHEADER) PURE;
	STDMETHOD(Acquire)(THIS) PURE;
	STDMETHOD(Unacquire)(THIS) PURE;
	STDMETHOD(GetDeviceState)(THIS_ DWORD,LPVOID) PURE;
	STDMETHOD(GetDeviceData)(THIS_ DWORD,LPDIDEVICEOBJECTDATA,LPDWORD,DWORD) PURE;
	STDMETHOD(SetDataFormat)(THIS_ LPCDIDATAFORMAT) PURE;
	STDMETHOD(SetEventNotification)(THIS_ HANDLE) PURE;
	STDMETHOD(SetCooperativeLevel)(THIS_ HWND,DWORD) PURE;
	STDMETHOD(GetObjectInfo)(THIS_ LPDIDEVICEOBJECTINSTANCEA,DWORD,DWORD) PURE;
	STDMETHOD(GetDeviceInfo)(THIS_ LPDIDEVICEINSTANCEA) PURE;
	STDMETHOD(RunControlPanel)(THIS_ HWND,DWORD) PURE;
	STDMETHOD(Initialize)(THIS_ HINSTANCE,DWORD,REFGUID) PURE;
	STDMETHOD(CreateEffect)(THIS_ REFGUID,LPCDIEFFECT,LPDIRECTINPUTEFFECT *,LPUNKNOWN) PURE;
	STDMETHOD(EnumEffects)(THIS_ LPDIENUMEFFECTSCALLBACKA,LPVOID,DWORD) PURE;
	STDMETHOD(GetEffectInfo)(THIS_ LPDIEFFECTINFOA,REFGUID) PURE;
	STDMETHOD(GetForceFeedbackState)(THIS_ LPDWORD) PURE;
	STDMETHOD(SendForceFeedbackCommand)(THIS_ DWORD) PURE;
	STDMETHOD(EnumCreatedEffectObjects)(THIS_ LPDIENUMCREATEDEFFECTOBJECTSCALLBACK,LPVOID,DWORD) PURE;
	STDMETHOD(Escape)(THIS_ LPDIEFFESCAPE) PURE;
	STDMETHOD(Poll)(THIS) PURE;
	STDMETHOD(SendDeviceData)(THIS_ DWORD,LPCDIDEVICEOBJECTDATA,LPDWORD,DWORD) PURE;
	STDMETHOD(EnumEffectsInFile)(THIS_ LPCSTR,LPDIENUMEFFECTSINFILECALLBACK,LPVOID,DWORD) PURE;
	STDMETHOD(WriteEffectToFile)(THIS_ LPCSTR,DWORD,LPDIFILEEFFECT,DWORD) PURE;
	STDMETHOD(BuildActionMap)(THIS_ LPDIACTIONFORMATA,LPCSTR,DWORD) PURE;
	STDMETHOD(SetActionMap)(THIS_ LPDIACTIONFORMATA,LPCSTR,DWORD) PURE;
	STDMETHOD(GetImageInfo)(THIS_ LPDIDEVICEIMAGEINFOHEADERA) PURE;
};
#undef INTERFACE

typedef struct IDirectInputDevice8A *LPDIRECTINPUTDEVICE8A;


#ifdef UNICODE
#define IID_IDirectInputDevice8 IID_IDirectInputDevice8W
#define IDirectInputDevice8     IDirectInputDevice8W
#define IDirectInputDevice8Vtbl IDirectInputDevice8WVtbl
#else
#define IID_IDirectInputDevice8 IID_IDirectInputDevice8A
#define IDirectInputDevice8     IDirectInputDevice8A
#define IDirectInputDevice8Vtbl IDirectInputDevice8AVtbl
#endif


typedef struct IDirectInputDevice8 *LPDIRECTINPUTDEVICE8;


typedef BOOL (FAR PASCAL * LPDIENUMDEVICESBYSEMANTICSCBA)(LPCDIDEVICEINSTANCEA, LPDIRECTINPUTDEVICE8A, DWORD, DWORD, LPVOID);
typedef BOOL (FAR PASCAL * LPDIENUMDEVICESBYSEMANTICSCBW)(LPCDIDEVICEINSTANCEW, LPDIRECTINPUTDEVICE8W, DWORD, DWORD, LPVOID);

#ifdef UNICODE
#define LPDIENUMDEVICESBYSEMANTICSCB  LPDIENUMDEVICESBYSEMANTICSCBW
#else  // #ifdef UNICODE
#define LPDIENUMDEVICESBYSEMANTICSCB  LPDIENUMDEVICESBYSEMANTICSCBA
#endif // #ifdef UNICODE


#define IDirectInputDevice8_QueryInterface(p,a,b) (p)->lpVtbl->QueryInterface(p,a,b)
#define IDirectInputDevice8_AddRef(p) (p)->lpVtbl->AddRef(p)
#define IDirectInputDevice8_Release(p) (p)->lpVtbl->Release(p)
#define IDirectInputDevice8_GetCapabilities(p,a) (p)->lpVtbl->GetCapabilities(p,a)
#define IDirectInputDevice8_EnumObjects(p,a,b,c) (p)->lpVtbl->EnumObjects(p,a,b,c)
#define IDirectInputDevice8_GetProperty(p,a,b) (p)->lpVtbl->GetProperty(p,a,b)
#define IDirectInputDevice8_SetProperty(p,a,b) (p)->lpVtbl->SetProperty(p,a,b)
#define IDirectInputDevice8_Acquire(p) (p)->lpVtbl->Acquire(p)
#define IDirectInputDevice8_Unacquire(p) (p)->lpVtbl->Unacquire(p)
#define IDirectInputDevice8_GetDeviceState(p,a,b) (p)->lpVtbl->GetDeviceState(p,a,b)
#define IDirectInputDevice8_GetDeviceData(p,a,b,c,d) (p)->lpVtbl->GetDeviceData(p,a,b,c,d)
#define IDirectInputDevice8_SetDataFormat(p,a) (p)->lpVtbl->SetDataFormat(p,a)
#define IDirectInputDevice8_SetEventNotification(p,a) (p)->lpVtbl->SetEventNotification(p,a)
#define IDirectInputDevice8_SetCooperativeLevel(p,a,b) (p)->lpVtbl->SetCooperativeLevel(p,a,b)
#define IDirectInputDevice8_GetObjectInfo(p,a,b,c) (p)->lpVtbl->GetObjectInfo(p,a,b,c)
#define IDirectInputDevice8_GetDeviceInfo(p,a) (p)->lpVtbl->GetDeviceInfo(p,a)
#define IDirectInputDevice8_RunControlPanel(p,a,b) (p)->lpVtbl->RunControlPanel(p,a,b)
#define IDirectInputDevice8_Initialize(p,a,b,c) (p)->lpVtbl->Initialize(p,a,b,c)
#define IDirectInputDevice8_CreateEffect(p,a,b,c,d) (p)->lpVtbl->CreateEffect(p,a,b,c,d)
#define IDirectInputDevice8_EnumEffects(p,a,b,c) (p)->lpVtbl->EnumEffects(p,a,b,c)
#define IDirectInputDevice8_GetEffectInfo(p,a,b) (p)->lpVtbl->GetEffectInfo(p,a,b)
#define IDirectInputDevice8_GetForceFeedbackState(p,a) (p)->lpVtbl->GetForceFeedbackState(p,a)
#define IDirectInputDevice8_SendForceFeedbackCommand(p,a) (p)->lpVtbl->SendForceFeedbackCommand(p,a)
#define IDirectInputDevice8_EnumCreatedEffectObjects(p,a,b,c) (p)->lpVtbl->EnumCreatedEffectObjects(p,a,b,c)
#define IDirectInputDevice8_Escape(p,a) (p)->lpVtbl->Escape(p,a)
#define IDirectInputDevice8_Poll(p) (p)->lpVtbl->Poll(p)
#define IDirectInputDevice8_SendDeviceData(p,a,b,c,d) (p)->lpVtbl->SendDeviceData(p,a,b,c,d)
#define IDirectInputDevice8_EnumEffectsInFile(p,a,b,c,d) (p)->lpVtbl->EnumEffectsInFile(p,a,b,c,d)
#define IDirectInputDevice8_WriteEffectToFile(p,a,b,c,d) (p)->lpVtbl->WriteEffectToFile(p,a,b,c,d)
#define IDirectInputDevice8_BuildActionMap(p,a,b,c) (p)->lpVtbl->BuildActionMap(p,a,b,c)
#define IDirectInputDevice8_SetActionMap(p,a,b,c) (p)->lpVtbl->SetActionMap(p,a,b,c)
#define IDirectInputDevice8_GetImageInfo(p,a) (p)->lpVtbl->GetImageInfo(p,a)




EXTERN_C const IID IID_IDirectInput8W;
#define INTERFACE IDirectInput8W
DECLARE_INTERFACE_(IDirectInput8W, IUnknown)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;

	STDMETHOD(CreateDevice)(THIS_ REFGUID,LPDIRECTINPUTDEVICE8W *,LPUNKNOWN) PURE;
	STDMETHOD(EnumDevices)(THIS_ DWORD,LPDIENUMDEVICESCALLBACKW,LPVOID,DWORD) PURE;
	STDMETHOD(GetDeviceStatus)(THIS_ REFGUID) PURE;
	STDMETHOD(RunControlPanel)(THIS_ HWND,DWORD) PURE;
	STDMETHOD(Initialize)(THIS_ HINSTANCE,DWORD) PURE;
	STDMETHOD(FindDevice)(THIS_ REFGUID,LPCWSTR,LPGUID) PURE;
	STDMETHOD(EnumDevicesBySemantics)(THIS_ LPCWSTR,LPDIACTIONFORMATW,LPDIENUMDEVICESBYSEMANTICSCBW,LPVOID,DWORD) PURE;
	STDMETHOD(ConfigureDevices)(THIS_ LPDICONFIGUREDEVICESCALLBACK,LPDICONFIGUREDEVICESPARAMSW,DWORD,LPVOID) PURE;
};
#undef INTERFACE

typedef struct IDirectInput8W *LPDIRECTINPUT8W;


EXTERN_C const IID IID_IDirectInput8A;
#define INTERFACE IDirectInput8A
DECLARE_INTERFACE_(IDirectInput8A, IUnknown)
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;

	STDMETHOD(CreateDevice)(THIS_ REFGUID,LPDIRECTINPUTDEVICE8A *,LPUNKNOWN) PURE;
	STDMETHOD(EnumDevices)(THIS_ DWORD,LPDIENUMDEVICESCALLBACKA,LPVOID,DWORD) PURE;
	STDMETHOD(GetDeviceStatus)(THIS_ REFGUID) PURE;
	STDMETHOD(RunControlPanel)(THIS_ HWND,DWORD) PURE;
	STDMETHOD(Initialize)(THIS_ HINSTANCE,DWORD) PURE;
	STDMETHOD(FindDevice)(THIS_ REFGUID,LPCSTR,LPGUID) PURE;
	STDMETHOD(EnumDevicesBySemantics)(THIS_ LPCSTR,LPDIACTIONFORMATA,LPDIENUMDEVICESBYSEMANTICSCBA,LPVOID,DWORD) PURE;
	STDMETHOD(ConfigureDevices)(THIS_ LPDICONFIGUREDEVICESCALLBACK,LPDICONFIGUREDEVICESPARAMSA,DWORD,LPVOID) PURE;
};
#undef INTERFACE

typedef struct IDirectInput8A *LPDIRECTINPUT8A;


#ifdef UNICODE
#define IID_IDirectInput8 IID_IDirectInput8W
#define IDirectInput8     IDirectInput8W
#define IDirectInput8Vtbl IDirectInput8WVtbl
#else
#define IID_IDirectInput8 IID_IDirectInput8A
#define IDirectInput8     IDirectInput8A
#define IDirectInput8Vtbl IDirectInput8AVtbl
#endif


typedef struct IDirectInput8 *LPDIRECTINPUT8;


#define IDirectInput8_QueryInterface(         p,a,b       ) (p)->lpVtbl->QueryInterface(p,a,b)
#define IDirectInput8_AddRef(                 p           ) (p)->lpVtbl->AddRef(p)
#define IDirectInput8_Release(                p           ) (p)->lpVtbl->Release(p)
#define IDirectInput8_CreateDevice(           p,a,b,c     ) (p)->lpVtbl->CreateDevice(p,a,b,c)
#define IDirectInput8_EnumDevices(            p,a,b,c,d   ) (p)->lpVtbl->EnumDevices(p,a,b,c,d)
#define IDirectInput8_GetDeviceStatus(        p,a         ) (p)->lpVtbl->GetDeviceStatus(p,a)
#define IDirectInput8_RunControlPanel(        p,a,b       ) (p)->lpVtbl->RunControlPanel(p,a,b)
#define IDirectInput8_Initialize(             p,a,b       ) (p)->lpVtbl->Initialize(p,a,b)
#define IDirectInput8_FindDevice(             p,a,b,c     ) (p)->lpVtbl->FindDevice(p,a,b,c)
#define IDirectInput8_EnumDevicesBySemantics( p,a,b,c,d,e ) (p)->lpVtbl->EnumDevicesBySemantics(p,a,b,c,d,e)
#define IDirectInput8_ConfigureDevices(       p,a,b,c,d   ) (p)->lpVtbl->ConfigureDevices(p,a,b,c,d)




typedef struct {

	LONG lX;
	LONG lY;
	BYTE bButtonA;
	BYTE bButtonB;
	BYTE bButtonX;
	BYTE bButtonY;

} n_game_input_DirectInput_data; 

DIOBJECTDATAFORMAT n_game_input_DirectInput_DIOBJECTDATAFORMAT[] = {
 
	{ &GUID_XAxis,  FIELD_OFFSET( n_game_input_DirectInput_data,       lX ), DIDFT_AXIS   | DIDFT_ANYINSTANCE, 0, },
	{ &GUID_YAxis,  FIELD_OFFSET( n_game_input_DirectInput_data,       lY ), DIDFT_AXIS   | DIDFT_ANYINSTANCE, 0, },
	{ &GUID_Button, FIELD_OFFSET( n_game_input_DirectInput_data, bButtonA ), DIDFT_BUTTON | DIDFT_ANYINSTANCE, 0, },
	{ &GUID_Button, FIELD_OFFSET( n_game_input_DirectInput_data, bButtonB ), DIDFT_BUTTON | DIDFT_ANYINSTANCE, 0, },
	{ &GUID_Button, FIELD_OFFSET( n_game_input_DirectInput_data, bButtonX ), DIDFT_BUTTON | DIDFT_ANYINSTANCE, 0, },
	{ &GUID_Button, FIELD_OFFSET( n_game_input_DirectInput_data, bButtonY ), DIDFT_BUTTON | DIDFT_ANYINSTANCE, 0, },
};

DIDATAFORMAT n_game_input_DirectInput_DIDATAFORMAT = {
 
	sizeof( DIDATAFORMAT       ),
	sizeof( DIOBJECTDATAFORMAT ),
	DIDF_ABSAXIS,
	sizeof( n_game_input_DirectInput_data ),
	sizeof( n_game_input_DirectInput_DIOBJECTDATAFORMAT ) / sizeof( n_game_input_DirectInput_DIOBJECTDATAFORMAT[ 0 ] ),
	n_game_input_DirectInput_DIOBJECTDATAFORMAT,

}; 




typedef struct {

	HMODULE              hmod;
	HWND                 hwnd;

	IDirectInput8       *IDirectInput8;
	IDirectInputDevice8 *IDirectInputDevice8;

} n_game_input_DirectInput;




static n_game_input_DirectInput *n_game_input_DirectInput_DIEnumDevicesCallback_target = NULL;

BOOL CALLBACK
n_game_input_DirectInput_DIEnumDevicesCallback( LPCDIDEVICEINSTANCE lpddi, LPVOID pvRef )
{

	n_game_input_DirectInput *p = n_game_input_DirectInput_DIEnumDevicesCallback_target;

	HRESULT hr = IDirectInput8_CreateDevice
	(
		p->IDirectInput8,
		&lpddi->guidInstance,
		&p->IDirectInputDevice8,
		NULL
	);

    	if ( FAILED( hr ) ) { return DIENUM_CONTINUE; }


	return DIENUM_STOP;
}




#define n_game_input_DirectInput_zero( p ) n_memory_zero( p, sizeof( n_game_input_DirectInput ) )

void
n_game_input_DirectInput_exit( n_game_input_DirectInput *p )
{

	if ( p == NULL ) { return; }


	if ( p->IDirectInputDevice8 != NULL )
	{
		IDirectInputDevice8_Unacquire( p->IDirectInputDevice8 );
		IDirectInputDevice8_Release( p->IDirectInputDevice8 );
	}

	if ( p->IDirectInput8 != NULL )
	{
		IDirectInput8_Release( p->IDirectInput8 );
	}


	if ( p->hmod != NULL )
	{
		FreeLibrary( p->hmod );
	}


	n_game_input_DirectInput_zero( p );


	return;
}

void
n_game_input_DirectInput_init( n_game_input_DirectInput *p, HWND hwnd )
{

	if ( p == NULL ) { return; }


	n_game_input_DirectInput_exit( p );


	p->hmod = LoadLibrary( n_posix_literal( "Dinput8.dll" ) );
	if ( p->hmod == NULL )
	{
n_posix_debug_literal( " LoadLibrary() " );

		return;
	}


	FARPROC n_DirectInputCreate8 = GetProcAddress( p->hmod, "DirectInput8Create" );
	if ( n_DirectInputCreate8 == NULL )
	{
n_posix_debug_literal( " GetProcAddress() n_DirectInputCreate8 " );

		n_game_input_DirectInput_exit( p );

		return;
	}


	HRESULT hret = 0;


	const HINSTANCE hinst = GetModuleHandle( NULL );

#ifdef UNICODE
	const GUID n_IID_IDirectInput = { 0xBF798031,0x483A,0x4DA2,{ 0xAA,0x99, 0x5D,0x64,0xED,0x36,0x97,0x00 } };
#else  // #ifdef UNICODE
	const GUID n_IID_IDirectInput = { 0xBF798030,0x483A,0x4DA2,{ 0xAA,0x99, 0x5D,0x64,0xED,0x36,0x97,0x00 } };
#endif // #ifdef UNICODE

	hret = n_DirectInputCreate8
	(
		hinst,
		0x0800,
		&n_IID_IDirectInput,
		&p->IDirectInput8,
		NULL
	);

	if ( FAILED( hret ) )
	{
n_posix_debug_literal( " n_DirectInputCreate8() " );

		n_game_input_DirectInput_exit( p );

		return;
	}


	// [x] : error : DIEDFL_FORCEFEEDBACK
	//
	//	no object returns

	n_game_input_DirectInput_DIEnumDevicesCallback_target = p;

	hret = IDirectInput8_EnumDevices
	(
		p->IDirectInput8,
		DI8DEVCLASS_GAMECTRL,
		n_game_input_DirectInput_DIEnumDevicesCallback,
		NULL,
		DIEDFL_ATTACHEDONLY// | DIEDFL_FORCEFEEDBACK
	);

	if ( ( FAILED( hret ) )||( p->IDirectInputDevice8 == NULL ) )
	{
n_posix_debug_literal( " IDirectInputDevice8 : %d %x ", hret, hret );

		n_game_input_DirectInput_exit( p );

		return;
	}


	p->hwnd = hwnd;

/*
	// [x] : error happens at Acquire()
	//
	//	#define E_ACCESSDENIED ((HRESULT)0x80070005L)
	//	#define DIERR_OTHERAPPHASPRIO E_ACCESSDENIED

	IDirectInputDevice8_SetCooperativeLevel
	(
		p->IDirectInputDevice8,
		p->hwnd,
		DISCL_EXCLUSIVE | DISCL_FOREGROUND
	);
*/

	hret = IDirectInputDevice8_SetDataFormat
	(
		p->IDirectInputDevice8,
		&n_game_input_DirectInput_DIDATAFORMAT
	);

	if ( FAILED( hret ) )
	{
n_posix_debug_literal( " IDirectInputDevice8_SetDataFormat() " );

		return;
	}


	hret = IDirectInputDevice8_Acquire( p->IDirectInputDevice8 );

	if ( FAILED( hret ) )
	{
n_win_hwndprintf_literal( p->hwnd, "Acquire() : %d %x ", hret, hret );
	}


	return;
}

void
n_game_input_DirectInput_vibrate( n_game_input_DirectInput *p, int v )
{

	if ( p       == NULL ) { return; }
	if ( p->hmod == NULL ) { return; }

/*
	DIPERIODIC diperiodic;

	diperiodic.dwMagnitude = DI_FFNOMINALMAX;
	diperiodic.lOffset     = 0;
	diperiodic.dwPhase     = 0;
	diperiodic.dwPeriod    = (DWORD) ( 0.5 * DI_SECONDS );
*/
/*
	DIENVELOPE dienvelope;

	dienvelope.dwSize        = sizeof( DIENVELOPE );
	dienvelope.dwAttackLevel = 0;
	dienvelope.dwAttackTime  = (DWORD) ( 0.5 * DI_SECONDS );
	dienvelope.dwFadeLevel   = 0;
	dienvelope.dwFadeTime    = (DWORD) ( 1.0 * DI_SECONDS );
*/

	DIEFFECT   dieffect; ZeroMemory( &dieffect, sizeof( DIEFFECT ) );

	DWORD           axes     [ 2 ] = { DIJOFS_X, DIJOFS_Y };
	LONG            direction[ 2 ] = { 1, 1 };
	DICONSTANTFORCE diconstantforce;

	dieffect.dwSize                  = sizeof( DIEFFECT );
	dieffect.dwFlags                 = DIEFF_CARTESIAN | DIEFF_OBJECTOFFSETS;
	dieffect.dwDuration              = INFINITE;
	dieffect.dwSamplePeriod          = 0;
	dieffect.dwGain                  = DI_FFNOMINALMAX;
	dieffect.dwTriggerButton         = DIEB_NOTRIGGER;
	dieffect.dwTriggerRepeatInterval = 0;      
	dieffect.cAxes                   = 2;
	dieffect.rgdwAxes                = axes;
	dieffect.rglDirection            = direction;
	dieffect.lpEnvelope              = NULL;
	dieffect.cbTypeSpecificParams    = sizeof( DICONSTANTFORCE );
	dieffect.lpvTypeSpecificParams   = &diconstantforce;
	dieffect.dwStartDelay            = 0;


	// [x] : return code
	//
	//	#define E_NOTIMPL ((HRESULT)0x80004001L)
	//	#define DIERR_UNSUPPORTED E_NOTIMPL

	IDirectInputEffect *n_IDirectInputEffect = NULL;

	HRESULT hret = IDirectInputDevice8_CreateEffect
	(
		p->IDirectInputDevice8,
		&GUID_Square,//&GUID_ConstantForce,
		&dieffect,
		&n_IDirectInputEffect,
		NULL
	);

	if ( FAILED( hret ) )
	{
n_win_hwndprintf_literal( p->hwnd, " CreateEffect() : %d %x ", hret, hret );
	}

	if ( n_IDirectInputEffect != NULL )
	{

		IDirectInputEffect_Start( n_IDirectInputEffect, 1, DIES_SOLO );
		Sleep( 1000 );
		IDirectInputEffect_Stop( n_IDirectInputEffect );

		IDirectInputEffect_Release( n_IDirectInputEffect );

	}


	return;
}

bool
n_game_input_DirectInput_loop( n_game_input_DirectInput *p, int vk )
{

	if ( p       == NULL ) { return false; }
	if ( p->hmod == NULL ) { return false; }


	HRESULT hret;


	hret = IDirectInputDevice8_Poll( p->IDirectInputDevice8 );

	if ( FAILED( hret ) )
	{
n_win_hwndprintf_literal( p->hwnd, "Poll() : %d %x ", hret, hret );

		return false;
	}


	n_game_input_DirectInput_data data;

	hret = IDirectInputDevice8_GetDeviceState
	(
		p->IDirectInputDevice8,
		sizeof( n_game_input_DirectInput_data ),
		&data
	);
	if ( FAILED( hret ) )
	{
n_win_hwndprintf_literal( p->hwnd, "GetDeviceState() : %d %x ", hret, hret );
	}
/*
n_posix_debug_literal
(
	"%d %d"
	"\n"
	"%d %d %d %d"
	,
	data.lX, data.lY,
	data.bButtonA, data.bButtonB, data.bButtonX, data.bButtonY
);
*/
	if ( ( vk == VK_UP    )&&( data.lY ==     0 ) ) { return true; }
	if ( ( vk == VK_DOWN  )&&( data.lY == 65535 ) ) { return true; }
	if ( ( vk == VK_LEFT  )&&( data.lX ==     0 ) ) { return true; }
	if ( ( vk == VK_RIGHT )&&( data.lX == 65535 ) ) { return true; }


	return false;
}


