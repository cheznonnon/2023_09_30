// Nonnon Character Map
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_APPS_NAME_CHARMAP

#include "../nonnon/project/define_unicode.c"

#endif // #ifndef N_APPS_NAME_CHARMAP




//#define N_MEMORY_DEBUG




#include "../nonnon/win32/gdi/doublebuffer.c"
#include "../nonnon/win32/clipboard.c"
#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_scrollbar.c"
#include "../nonnon/win32/win_smallbutton_direct.c"
#include "../nonnon/win32/win_statusbar_ownerdraw.c"
#include "../nonnon/win32/win_txtbox.c"

#include "../nonnon/project/small_find.c"
#include "../nonnon/project/macro.c"




#define N_CHARMAP_SMALLICON_OFFSET ( 10 )




#define H_CANVAS charmap.hgui[ 0 ]
#define H_SMLBTN charmap.hgui[ 1 ]
#define GUI_MAX                2




// internal

typedef struct {

	HWND                      hgui[ GUI_MAX ];
	n_win_txtbox              find;
	n_win_txtbox              list;
	n_win_scrollbar           scrl;
	n_win_smallbutton_direct  smallbutton;
	n_win_statusbar_ownerdraw statusbar;

	int                       offset;
	int                       focus;
	int                       click;

	n_posix_bool              big_onoff;

} n_charmap;


static n_charmap charmap;




#define n_charmap_zero( p ) n_memory_zero( p, sizeof( n_charmap ) );

n_posix_char*
n_charmap_character_get( int index )
{

	static n_posix_char str[ 3 ] = { N_STRING_CHAR_NUL, N_STRING_CHAR_NUL, N_STRING_CHAR_NUL };


	str[ 0 ] = index;

#ifndef UNICODE
	if ( index >= 256 )
	{
		if ( IsDBCSLeadByte( ( index >> 8 ) & 0x000000ff ) )
		{
			str[ 0 ] = ( index >> 8 ) & 0x000000ff;
			str[ 1 ] = ( index >> 0 ) & 0x000000ff;
		} else {
			str[ 0 ] = '\0';
			str[ 1 ] = '\0';
		}
	}
#endif // #ifdef UNICODE


	return str;
}

// internal
int CALLBACK
n_charmap_list_EnumFontsProc( const LOGFONT *lf, const TEXTMETRIC *tm, u32 type, LPARAM lparam )
{

	if ( lparam == 0 )
	{

		n_win_txtbox_line_add( &charmap.list, 0, (void*) lf->lfFaceName );

	} else {

		LOGFONT *l = (void*) lparam;

		if ( n_string_is_same( l->lfFaceName, lf->lfFaceName ) )
		{
			n_memory_copy( lf, l, sizeof( LOGFONT ) );
			return n_false;
		}

	}


	return n_true;
}

void
n_charmap_list_init( HWND hwnd )
{

	HDC hdc = GetDC( hwnd );

	EnumFonts( hdc, NULL, n_charmap_list_EnumFontsProc, (LPARAM) 0 );

	ReleaseDC( hwnd, hdc );


	n_txt_sort_up( &charmap.list.txt    );
	n_txt_del    ( &charmap.list.txt, 0 );

	n_win_txtbox_str2index_literal( &charmap.list, "Arial", n_true );


	return;
}

HFONT
n_charmap_list_selection( HWND hwnd, n_type_gfx size )
{

	// [Needed] : n_win_font_exit( hfont );


	LOGFONT lf; n_memory_zero( &lf, sizeof( LOGFONT ) );

	n_win_txtbox_selection_get( &charmap.list, lf.lfFaceName );


	HDC hdc = GetDC( hwnd );

	EnumFonts( hdc, NULL, n_charmap_list_EnumFontsProc, (LPARAM) &lf );

	ReleaseDC( hwnd, hdc );


	lf.lfWidth  = 0;
	lf.lfHeight = size;


	return n_win_font_logfont2hfont( &lf );
}

void
n_charmap_status_refresh( void )
{

	n_posix_char str[ 100 ];


	int f = 256 * ( charmap.offset + 0 );
	int t = 256 * ( charmap.offset + 1 );

	n_posix_sprintf_literal( str, " Range : Hex 0x%04x - 0x%04x : Dec %d - %d", f, t - 1, f, t - 1 );

	n_win_statusbar_od_text( &charmap.statusbar, str, 0 );


	if ( ( charmap.focus == -1 )&&( charmap.click == -1 ) )
	{
		n_posix_sprintf_literal( str, " Click a character" );
	} else
	if ( charmap.click != -1 )
	{
		n_posix_sprintf_literal( str, " Hex 0x%04x : Dec %d", charmap.click, charmap.click );
	} else
	if ( charmap.focus != -1 )
	{
		n_posix_sprintf_literal( str, " Hex 0x%04x : Dec %d", charmap.focus, charmap.focus );
	}

	n_win_statusbar_od_text( &charmap.statusbar, str, 1 );


	return;
}

void
n_charmap_canvas_refresh( void )
{

	n_win_refresh( H_CANVAS, n_false );


	return;
}

void
n_charmap_resize( HWND hwnd, n_bool is_first )
{

	const n_bool redraw = n_true;


	static n_win w;


	n_type_gfx ctl,m; n_win_stdsize( hwnd, &ctl, NULL, &m );


	int        nwset = N_WIN_SET_DEFAULT;
	n_type_gfx csx   = -1;
	n_type_gfx csy   = -1;

	if ( is_first )
	{

		nwset = N_WIN_SET_CENTERING;

		n_win_desktop_size( &csx, &csy );
		csx = m + (n_type_gfx) ( (n_type_real) csx * 0.6 );
		csy = m + (n_type_gfx) ( (n_type_real) csy * 0.6 );

		if ( csx > csy )
		{
			csx = (n_type_gfx) ( (n_type_real) csy * sqrt( 2 ) );
		}

	} else {

		nwset = n_project_n_win_set();

	}

	n_win_set( hwnd, &w, csx,csy, nwset );

	csx = w.csx - m;
	csy = w.csy - m;


	csy -= ctl;


	n_type_gfx scroll_sx = GetSystemMetrics( SM_CXVSCROLL );
	n_type_gfx scroll_sy = csy;

	{

		n_type_gfx x = 0;
		n_type_gfx y = 0;

		n_type_gfx u_x = csx / 3;

		n_type_gfx ssx = ( u_x * 1 );
		n_type_gfx ssy = ctl;
		n_type_gfx lsx = ( u_x * 1 );
		n_type_gfx lsy = csy - ssy;
		n_type_gfx rsx = ( u_x * 2 ) - scroll_sx;
		n_type_gfx rsy = csy;

		n_win_txtbox_move( &charmap.find, x,y, ssx,ssy, redraw ); y += ssy;
		n_win_txtbox_move( &charmap.list, x,y, lsx,lsy, redraw ); x += lsx; y = 0;
		n_win_move       (  H_CANVAS    , x,y, rsx,rsy, redraw ); x += rsx; y = 0;

		x = csx - scroll_sx;
		y = 0;
		n_win_scrollbar_move( &charmap.scrl, x,y, scroll_sx,scroll_sy, redraw );

		n_win_txtbox_smallbutton_direct_embed( &charmap.find, &charmap.smallbutton, 0 );

		n_win_smallbutton_direct_bitmap_init( &charmap.smallbutton );

	}

	n_win_statusbar_od_automove( &charmap.statusbar );


	return;
}

void
n_charmap_search( void )
{

	n_posix_char *str = n_win_txtbox_selection_new( &charmap.find );


	int index = 0;

	if ( n_string_is_empty( str ) )
	{

		index = -1;

	} else
	if ( n_string_search_simple_literal( str, "hex:" ) )
	{

		index = n_string_hex2u32( &str[ 4 ], n_posix_strlen( &str[ 4 ] ) );

	} else
	if ( n_string_search_simple_literal( str, "dec:" ) )
	{

		index = n_posix_atoi( &str[ 4 ] );

	} else {

#ifdef UNICODE
		index = (u16) str[ 0 ];
#else  // #ifdef UNICODE
		index = (u8 ) str[ 0 ];
		if ( IsDBCSLeadByte( index ) )
		{
			index = ( ( index + 1 ) << 8 ) + str[ 1 ];
		}
#endif // #ifdef UNICODE


	}


	n_string_free( str );


	if ( index != -1 )
	{
		charmap.offset = index / 256;
		charmap.focus  = index;
	} else {
		charmap.focus  = -1;
	}


	n_charmap_canvas_refresh();
	n_charmap_status_refresh();

	charmap.scrl.unit_pos = 0;
	n_win_scrollbar_scroll_unit( &charmap.scrl, charmap.offset, N_WIN_SCROLLBAR_SCROLL_AUTO );
	n_win_scrollbar_draw_always( &charmap.scrl, n_true );


	return;
}

void
n_charmap_proc_mouse( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {

	case WM_LBUTTONDOWN   :
	case WM_MBUTTONDOWN   :
	case WM_RBUTTONDOWN   :
	case WM_LBUTTONDBLCLK :
	case WM_MBUTTONDBLCLK :
	case WM_RBUTTONDBLCLK :
	{
//n_win_hwndprintf_literal( hwnd, " %d ", n_win_is_hovered( H_CANVAS ) );

		if ( n_false == n_win_is_hovered( H_CANVAS ) ) { break; }

		if ( charmap.big_onoff ) { break; }

		RECT rect; GetClientRect( H_CANVAS, &rect );
		n_type_gfx sx,sy; n_win_rect_expand_size( &rect, NULL, NULL, &sx, &sy );

		n_type_gfx unit_sx = ( sx / 16 );
		n_type_gfx unit_sy = ( sy / 16 );

		charmap.click = -1;

		n_type_gfx x = 0;
		n_type_gfx y = 0;
		n_type_gfx i = charmap.offset * 256;
		n_posix_loop
		{

			n_bool ret = n_win_is_hovered_offset( H_CANVAS, x * unit_sx, y * unit_sy, unit_sx, unit_sy );
			if ( ret )
			{
				charmap.click = i;

				n_charmap_canvas_refresh();
				n_charmap_status_refresh();

				n_clipboard_text_set( hwnd, n_charmap_character_get( charmap.click ) );

				break;
			}

			i++;

			x++;
			if ( x >= 16 )
			{

				x = 0;

				y++;
				if ( y >= 16 ) { break; }
			}
		}

	}
	break;


	case WM_LBUTTONUP :

		if ( n_false == n_win_is_hovered( H_CANVAS ) ) { break; }

		if ( charmap.big_onoff ) { break; }

		if ( charmap.focus != charmap.click )
		{
			charmap.focus = charmap.click;
		} else {
			charmap.focus = -1;
		}

		charmap.click = -1;

		n_charmap_canvas_refresh();
		n_charmap_status_refresh();

	break;


	case WM_RBUTTONUP :

		if ( n_false == n_win_is_hovered( H_CANVAS ) ) { break; }

		if ( charmap.big_onoff ) { charmap.big_onoff = n_posix_false; } else { charmap.big_onoff = n_posix_true; }

		charmap.focus = charmap.click;

		n_charmap_canvas_refresh();
		n_charmap_status_refresh();

	break;


	} // switch


	return;
}

LRESULT CALLBACK
n_charmap_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{
//n_posix_debug_literal( " ! " );

	if ( wparam == VK_RETURN )
	{
		n_charmap_search();

		return n_true;
	}


	return n_false;
}

void
n_charmap_on_settingchange( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();

		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_txtbox_on_settingchange( &charmap.find );
		n_win_txtbox_on_settingchange( &charmap.list );

		n_win_smallbutton_direct_on_settingchange( &charmap.smallbutton, n_project_small_find );

		n_win_scrollbar_on_settingchange( &charmap.scrl, n_true, n_true );

		n_charmap_resize( hwnd, n_false );

	break;


	} // switch


}
LRESULT CALLBACK
n_charmap_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_charmap_on_settingchange( hwnd, msg, wparam, lparam );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_project_darkmode();

		n_win_ime_disable( hwnd );

		n_charmap_zero( &charmap );

		n_win_smallbutton_direct_zero( &charmap.smallbutton );

		charmap.focus = -1;
		charmap.click = -1;


		// Window

		n_win_init_literal( hwnd, "Nonnon Character Map", "A_MAIN", "" );


		{

			int option = 0;

			//option |= N_WIN_SCROLLBAR_OPTION_NO_ARROWS;
			option |= N_WIN_SCROLLBAR_OPTION_PAGER;

			n_win_scrollbar_init( &charmap.scrl, hwnd, N_WIN_SCROLLBAR_LAYOUT_VERTICAL, 0, option );

		}


		n_win_gui_literal( hwnd, CANVAS, "", &H_CANVAS );
		n_win_gui_literal( hwnd, CANVAS, "", &H_SMLBTN );

		{

			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_ONELINE;

			int option = 0;

			n_win_txtbox_zero( &charmap.find );
			n_win_txtbox_init( &charmap.find, hwnd, style, option );

#ifdef _WIN64
			SetWindowSubclass( charmap.find.hwnd, n_win_subclass_txtbox_on_keydown, 0, (DWORD_PTR) n_charmap_on_keydown );
#else  // #ifdef _WIN64
			n_win_property_init_literal
			(
				charmap.find.hwnd,
				"n_win_subclass_txtbox_on_keydown()",
				(int) n_win_gui_subclass_set( charmap.find.hwnd, n_win_subclass_txtbox_on_keydown )
			);
			n_win_property_init_literal( charmap.find.hwnd, "WM_KEYDOWN", (int) n_charmap_on_keydown );
#endif // #ifdef _WIN64

		}

		{

			int style  = 0;

			style  |= N_WIN_TXTBOX_STYLE_LISTBOX;
			style  |= N_WIN_TXTBOX_STYLE_VSCROLL;
			style  |= N_WIN_TXTBOX_STYLE_STRIPED;

			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL;

			if ( n_win_fluent_ui_onoff )
			{
				option |= N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;
			}

			n_win_txtbox_zero( &charmap.list );
			n_win_txtbox_init( &charmap.list, hwnd, style, option );

		}

		n_win_statusbar_od_zero( &charmap.statusbar );
		n_win_statusbar_od_init( &charmap.statusbar, hwnd, 2 );


		// Style

		n_project_window_resizable( hwnd );

		n_win_smallbutton_direct_init_by_data( &charmap.smallbutton, charmap.find.hwnd, hwnd, hwnd, 1, n_project_small_find );
		charmap.smallbutton.show_onoff = n_posix_true;


		// Init

		SetFocus( charmap.list.hwnd );

		n_charmap_resize( hwnd, n_true );

		n_charmap_list_init( hwnd );

		n_win_scrollbar_parameter( &charmap.scrl, 1, 1, 255, 0, n_false );

		n_charmap_status_refresh();


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :

		n_charmap_resize( hwnd, n_false );
		n_charmap_canvas_refresh();

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( H_CANVAS != di->hwndItem ) { break; }


		RECT rect = di->rcItem;//; GetClientRect( H_CANVAS, &rect );

		n_type_gfx sx,sy; n_win_rect_expand_size( &rect, NULL, NULL, &sx, &sy );


		COLORREF color_normal_bg = n_win_darkmode_systemcolor( COLOR_BTNFACE       );
		COLORREF color_normal_fg = n_win_darkmode_systemcolor( COLOR_BTNTEXT       );
		COLORREF color_select_bg = n_win_darkmode_systemcolor( COLOR_HIGHLIGHT     );
		COLORREF color_select_fg = n_win_darkmode_systemcolor( COLOR_HIGHLIGHTTEXT );
		COLORREF color_click__bg = n_win_color_blend( color_select_fg, color_select_bg, 0.75 );
		COLORREF color_click__fg = n_win_darkmode_systemcolor( COLOR_HIGHLIGHTTEXT );


		HDC hdc = n_gdi_doublebuffer_simple_init( H_CANVAS, sx,sy );


		n_win_box( hwnd, hdc, &rect, color_normal_bg );


		n_type_gfx unit_sx = ( sx / 16 );
		n_type_gfx unit_sy = ( sy / 16 );


		if ( charmap.big_onoff )
		{

			int   pt = (int) ( (n_type_real) n_posix_min_n_type_gfx( sx, sy ) * 0.8 );
			HFONT hf = n_charmap_list_selection( hwnd, pt );
			HFONT pf = SelectObject( hdc, hf );

			int  dt = DT_NOPREFIX | DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
			RECT r  = n_win_rect_set( NULL, 0, 0, sx, sy );

			COLORREF fg,bg;
			if ( n_win_darkmode_onoff )
			{
				fg = RGB( 255,255,255 );
				bg = RGB(   0,  0,  0 );
			} else {
				fg = RGB(   0,  0,  0 );
				bg = RGB( 255,255,255 );
			}

			n_win_box( hwnd, hdc, &r, bg );
			SetBkColor  ( hdc, bg );
			SetTextColor( hdc, fg );

			DrawText( hdc, n_charmap_character_get( charmap.click ), -1, &r, dt );
			DrawEdge( hdc, &r, EDGE_ETCHED, BF_RECT );

			n_win_font_exit( SelectObject( hdc, pf ) );

			n_gdi_doublebuffer_simple_exit();


			charmap.focus = -1;


			break;
		}


		n_type_gfx pt = (n_type_gfx) ( (n_type_real) n_posix_min_n_type_gfx( unit_sx, unit_sy ) * 0.8 );
		HFONT      hf = n_charmap_list_selection( hwnd, pt );
		HFONT      pf = SelectObject( hdc, hf );


		n_type_gfx x = 0;
		n_type_gfx y = 0;
		n_type_gfx i = charmap.offset * 256;
		n_posix_loop
		{//break;

			int  dt = DT_NOPREFIX | DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
			RECT r  = n_win_rect_set( NULL, x * unit_sx, y * unit_sy, unit_sx, unit_sy );

			if ( charmap.focus == i )
			{
				n_win_box( hwnd, hdc, &r, color_select_bg );
				SetBkColor  ( hdc, color_select_bg );
				SetTextColor( hdc, color_select_fg );
			} else
			if ( charmap.click == i )
			{
				n_win_box( hwnd, hdc, &r, color_click__bg );
				SetBkColor  ( hdc, color_click__bg );
				SetTextColor( hdc, color_click__fg );
			} else {
				n_win_box( hwnd, hdc, &r, color_normal_bg );
				SetBkColor  ( hdc, color_normal_bg );
				SetTextColor( hdc, color_normal_fg );
			}

			DrawText( hdc, n_charmap_character_get( i ), -1, &r, dt );
			DrawEdge( hdc, &r, EDGE_ETCHED, BF_RECT );

			i++;

			x++;
			if ( x >= 16 )
			{

				x = 0;

				y++;
				if ( y >= 16 ) { break; }
			}
		}

		n_win_font_exit( SelectObject( hdc, pf ) );


		n_gdi_doublebuffer_simple_exit();

	}
	break;


	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == charmap.find.hwnd )
		{

			if ( wparam == WM_LBUTTONDOWN )
			{
				if ( n_string_is_empty( n_txt_get( &charmap.find.txt, 0 ) ) )
				{
					charmap.focus = -1;
				}

				n_charmap_search();

				n_charmap_canvas_refresh();
				n_charmap_status_refresh();
			}

		} else
		if ( ( h == charmap.smallbutton.hwnd_msg )&&( wparam == 1 ) )
		{

			n_charmap_search();

		} else
		if ( h == charmap.list.hwnd )
		{

			if ( wparam == WM_LBUTTONDOWN )
			{
				n_charmap_canvas_refresh();
				n_charmap_search();
			}

		} else
		if ( h == charmap.scrl.hwnd )
		{

			int p_offset = charmap.offset;

			charmap.offset = (int) wparam;

			if ( p_offset != charmap.offset )
			{
				n_charmap_status_refresh();
				n_charmap_canvas_refresh();
			}

		}
	}
	break;

	case WM_MOUSEWHEEL :

		if ( n_win_is_hovered( charmap.list.hwnd ) ) { break; }

		//if ( charmap.scrl.hwnd == n_win_cursor2hwnd_relative( H_CANVAS ) )
		{
			int delta = n_win_scrollbar_wheeldelta( wparam, 0, n_false );

			n_win_scrollbar_scroll_unit( &charmap.scrl, delta, N_WIN_SCROLLBAR_SCROLL_AUTO );
			n_win_scrollbar_draw_always( &charmap.scrl, n_true );

			n_win_message_send( hwnd, WM_COMMAND, charmap.scrl.unit_pos, charmap.scrl.hwnd );
		}
	break;

/*
	case WM_KEYDOWN :

		// [x] : conflict with an input field

		if ( wparam == VK_LEFT )
		{
			charmap.offset = n_posix_max( 0, charmap.offset - 1 );
			n_charmap_status_refresh();
			n_charmap_canvas_refresh();
		} else
		if ( wparam == VK_RIGHT )
		{
			charmap.offset = n_posix_min( 255, charmap.offset + 1 );
			n_charmap_status_refresh();
			n_charmap_canvas_refresh();
		}// else

	break;
*/

	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_smallbutton_direct_exit( &charmap.smallbutton );

		n_win_txtbox_exit( &charmap.find );
		n_win_txtbox_exit( &charmap.list );

		n_win_statusbar_od_exit( &charmap.statusbar );

		n_win_scrollbar_exit( &charmap.scrl );

#ifdef _WIN64
		RemoveWindowSubclass( charmap.find.hwnd, n_win_subclass_txtbox_on_keydown, 0 );
#else  // #ifdef _WIN64
		n_win_property_exit_literal( charmap.find.hwnd, "WM_KEYDOWN" );
#endif // #ifdef _WIN64

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &charmap.find );
		if ( ret ) { return ret; }
	}

	n_win_txtbox_proc( hwnd, msg, wparam, lparam, &charmap.list );

	n_win_smallbutton_direct_proc( hwnd, msg, wparam, lparam, &charmap.smallbutton );

	n_win_statusbar_od_proc( hwnd, msg, wparam, lparam, &charmap.statusbar );

	n_win_scrollbar_proc    ( hwnd, msg, wparam, lparam, &charmap.scrl );
	n_win_scrollbar_subclass( hwnd, msg, wparam, lparam, &charmap.scrl );

	n_win_simplemenu_proc( hwnd, msg, &wparam, &lparam, NULL );

	n_charmap_proc_mouse( hwnd, msg, wparam, lparam );

	{
		LRESULT ret = 0;
		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
		{
			return ret;
		}
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

#ifndef N_APPS_NAME_CHARMAP

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_charmap_wndproc );
}

#endif // #ifndef N_APPS_NAME_CHARMAP


#undef H_CANVAS
#undef H_SMLBTN
#undef GUI_MAX


