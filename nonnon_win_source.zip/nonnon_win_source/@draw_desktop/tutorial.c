// Tutorial
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




#include "../nonnon/win32/win.c"


#include "../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Tutorial", "MAIN_ICON", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_LBUTTONDOWN :
	{

		n_type_gfx sx = 256;
		n_type_gfx sy = 256;


		n_gdi_doublebuffer_init( &n_gdi_doublebuffer_instance, 0, NULL, sx,sy );

		n_gdi_doublebuffer_presync( &n_gdi_doublebuffer_instance );
//n_gdi_doublebuffer_simple_fill( 0 );


		n_gdi_doublebuffer db; n_gdi_doublebuffer_zero( &db );

		n_gdi_doublebuffer_init( &db, hwnd, NULL, sx,sy );

		n_bmp_flush_fastcopy( &n_gdi_doublebuffer_instance.bmp, &db.bmp );

		n_gdi_doublebuffer_exit( &db );


		n_gdi_doublebuffer_simple_exit();

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


