// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : trouble shooter
//
//	[ when engine seems to be misbehave ]
//
//	set n_bmp.transparent_onoff n_posix_false




#ifndef _H_NONNON_WIN32_GAME_TRANSITION
#define _H_NONNON_WIN32_GAME_TRANSITION




#include "../neutral/bmp/all.c"
#include "../neutral/random.c"


#include "./helper.c"




#define N_GAME_TRANSITION_NOTHING   0
#define N_GAME_TRANSITION_WIPE_X    1
#define N_GAME_TRANSITION_WIPE_Y    2
#define N_GAME_TRANSITION_SHUTTER   3
#define N_GAME_TRANSITION_INFLATE   4
#define N_GAME_TRANSITION_CIRCLE    5
#define N_GAME_TRANSITION_FADE      6
#define N_GAME_TRANSITION_DIZZY     7
#define N_GAME_TRANSITION_MOSAIC    8
#define N_GAME_TRANSITION_WHIRL     9
#define N_GAME_TRANSITION_SCROLL_U 10
#define N_GAME_TRANSITION_SCROLL_D 11
#define N_GAME_TRANSITION_SCROLL_L 12
#define N_GAME_TRANSITION_SCROLL_R 13
#define N_GAME_TRANSITION_LAST     13

static n_type_gfx n_game_transition_circle_x = 0;
static n_type_gfx n_game_transition_circle_y = 0;

static n_type_gfx n_game_transition_offset_x = 0;
static n_type_gfx n_game_transition_offset_y = 0;

typedef struct {

	n_bmp       *bmp_old;
	n_bmp       *bmp_new;
	n_bmp       *bmp_ret;
	n_type_gfx   x,y,sx,sy;
	n_type_real  blend;
	u32          oy, cores;

} n_game_transition_fade_thread_struct;

void
n_game_transition_fade_thread_main( n_game_transition_fade_thread_struct *p )
{

	// [!] : no error check available

	n_type_gfx fx = 0;
	n_type_gfx fy = p->oy;
	n_type_gfx tx = 0;
	n_type_gfx ty = p->oy;
	n_posix_loop
	{

		u32 color_old; n_bmp_ptr_get_fast( p->bmp_old, fx,fy, &color_old );
		u32 color_new; n_bmp_ptr_get_fast( p->bmp_new, fx,fy, &color_new );

		u32 color = n_bmp_blend_pixel( color_old, color_new, p->blend );

		n_bmp_ptr_set_fast( p->bmp_ret, p->x + tx, p->y + ty, color );

		fx++; tx++;
		if ( fx >= p->sx )
		{
			fx = tx = 0;

			fy += p->cores;
			ty += p->cores;
			if ( fy >= p->sy ) { break; }
		}
	}


	return;
}

n_thread_return
n_game_transition_fade_thread( n_thread_argument p )
{

	n_game_transition_fade_thread_main( (void*) p );

	return 0;
}

// internal
void
n_game_transition_fade( n_bmp *bmp_old, n_bmp *bmp_new, n_bmp *bmp_ret, n_type_gfx x, n_type_gfx y, n_type_real blend )
{

	n_type_gfx sx = N_BMP_SX( bmp_old );
	n_type_gfx sy = N_BMP_SY( bmp_old );


	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_thread_onoff() )
		&&
		( ( sx * sy ) >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_game_transition_fade() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		u32 cores = n_thread_core_count;

		n_thread                             *h = (void*) n_memory_new( cores * sizeof( n_thread                             ) );
		n_game_transition_fade_thread_struct *p = (void*) n_memory_new( cores * sizeof( n_game_transition_fade_thread_struct ) );


		u32 i = 0;
		n_posix_loop
		{

			n_game_transition_fade_thread_struct tmp = { bmp_old, bmp_new, bmp_ret, x,y,sx,sy, blend, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_game_transition_fade_thread_struct ) );

			h[ i ] = n_thread_init( n_game_transition_fade_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		n_posix_loop
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_game_transition_fade_thread_struct tmp = { bmp_old, bmp_new, bmp_ret, x,y,sx,sy, blend, 0,1 };
		n_game_transition_fade_thread_main( &tmp );

	}


	return;
}

n_posix_bool
n_game_transition( n_bmp *bmp, n_bmp *bmp_old, n_bmp *bmp_new, u32 msec, n_type_real *percent, int type )
{

	// [Mechanism]
	//
	//	bmp     : canvas
	//	bmp_old : this will disappear
	//	bmp_new : this will appear

	// [!] : Return Value
	//
	//	n_posix_false : running
	//	n_posix_true  : stop or error


	if ( n_bmp_error( bmp     ) ) { return n_posix_true; }
	if ( n_bmp_error( bmp_old ) ) { return n_posix_true; }
	if ( n_bmp_error( bmp_new ) ) { return n_posix_true; }

	if ( N_BMP_SX( bmp_old ) != N_BMP_SX( bmp_new ) ) { return n_posix_true; }
	if ( N_BMP_SY( bmp_old ) != N_BMP_SY( bmp_new ) ) { return n_posix_true; }

	if ( percent == NULL ) { return n_posix_true; }


	// [!] : nothing to do

	if ( N_BMP_PTR( bmp_old ) == N_BMP_PTR( bmp_new ) ) { return n_posix_true; }
	if ( N_BMP_PTR( bmp     ) == N_BMP_PTR( bmp_new ) ) { return n_posix_true; }

	if ( msec == 0 ) { return n_posix_true; }

	if ( ( type < 0 )||( type > N_GAME_TRANSITION_LAST ) ) { return n_posix_true; }


	const n_type_real ox = n_game_transition_offset_x;
	const n_type_real oy = n_game_transition_offset_y;

	const n_type_gfx bmpsx = N_BMP_SX( bmp_new );
	const n_type_gfx bmpsy = N_BMP_SY( bmp_new );


	static n_type_real unit = 0;
	static n_type_real x,y,sx,sy;


	if ( type == N_GAME_TRANSITION_NOTHING )
	{

		// Performance : fastest

		if ( (*percent) ==   0 )
		{
			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );
		} else
		if ( (*percent) >= 100 )
		{
			n_bmp_fastcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );
		}

	} else

	if ( type == N_GAME_TRANSITION_WIPE_X )
	{

		// Performance : WIPE_X:WIPE_X = 1:1


		if ( (*percent) == 0 )
		{

			unit = ceil( (n_type_real) bmpsx * 0.01 );

			x  = ( bmpsx / 2 );
			y  =     0;
			sx =     0;
			sy = bmpsy;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );

		}


		sx = n_posix_min_n_type_real( (n_type_real) bmpsx, unit * (*percent) );
		x  = ( bmpsx - sx ) / 2;

		n_type_gfx tx  = (n_type_gfx) x;
		n_type_gfx ty  = (n_type_gfx) y;
		n_type_gfx tsx = (n_type_gfx) sx;
		n_type_gfx tsy = (n_type_gfx) sy;

		n_bmp_fastcopy( bmp_new, bmp, tx,ty,tsx,tsy, (n_type_gfx) ox + tx, (n_type_gfx) oy + ty );

	} else

	if ( type == N_GAME_TRANSITION_WIPE_Y )
	{

		// Performance : WIPE_X:WIPE_Y = 1:1


		if ( (*percent) == 0 )
		{

			unit = ceil( (n_type_real) bmpsy * 0.01 );

			x  =     0;
			y  = ( bmpsy / 2 );
			sx = bmpsx;
			sy =     0;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );

		}


		sy = n_posix_min_n_type_real( (n_type_real) bmpsy, unit * (*percent) );
		y  = ( (n_type_real) bmpsy - sy ) / 2;

		n_type_gfx tx  = (n_type_gfx) x;
		n_type_gfx ty  = (n_type_gfx) y;
		n_type_gfx tsx = (n_type_gfx) sx;
		n_type_gfx tsy = (n_type_gfx) sy;

		n_bmp_fastcopy( bmp_new, bmp, tx,ty,tsx,tsy, (n_type_gfx) ox + tx, (n_type_gfx) oy + ty );

	} else

	if ( type == N_GAME_TRANSITION_SHUTTER )
	{

		// Performance : WIPE_X:SHUTTER = 1:1.5


		static n_type_gfx i, offset;


		if ( (*percent) == 0 )
		{

			unit = bmpsy;
			unit = ceil( (n_type_real) unit * 0.01 );

			x  =     0;
			y  =     0;
			sx = bmpsx;
			sy =     1;

			i = offset = 0;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );

		}


		n_posix_loop
		{//break;

			n_type_gfx tx  = (n_type_gfx) x;
			n_type_gfx ty  = (n_type_gfx) y;
			n_type_gfx tsx = (n_type_gfx) sx;
			n_type_gfx tsy = (n_type_gfx) sy;

			n_bmp_fastcopy( bmp_new, bmp, tx,ty, tsx,tsy, (n_type_gfx) ox + tx, (n_type_gfx) ox + ty );

			y += 10;
			if ( y >= bmpsy )
			{
				offset++;

				y = offset;
			}


			i++;
			if ( i >= ( unit * (*percent) ) ) { break; }
		}

	} else

	if ( type == N_GAME_TRANSITION_INFLATE )
	{

		// Performance : WIPE_X:INFLATE = 1:1.5


		if ( (*percent) == 0 )
		{

			unit = ceil( (n_type_real) n_posix_max_n_type_gfx( bmpsx, bmpsy ) * 0.01 );

			x  = bmpsx / 2;
			y  = bmpsy / 2;
			sx = unit;
			sy = unit;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );

		}


		n_type_gfx size = (n_type_gfx) ( unit * (*percent) );


		x  = ( bmpsx - size ) / 2;
		y  = ( bmpsy - size ) / 2;
		sx = size;
		sy = size;

		n_type_gfx tx  = (n_type_gfx) x;
		n_type_gfx ty  = (n_type_gfx) y;
		n_type_gfx tsx = (n_type_gfx) sx;
		n_type_gfx tsy = (n_type_gfx) sy;

		n_bmp_fastcopy( bmp_new, bmp, tx,ty, tsx,tsy, (n_type_gfx) ox + tx, (n_type_gfx) oy + ty );

	} else

	if ( type == N_GAME_TRANSITION_CIRCLE )
	{

		// Performance : WIPE_X:CIRCLE = 1:3

		static n_type_gfx p_size = -1;

		if ( (*percent) == 0 )
		{

			n_type_gfx half_sx   = bmpsx / 2;
			n_type_gfx half_sy   = bmpsy / 2;
			n_type_gfx radius_sx = half_sx + abs( half_sx - n_game_transition_circle_x );
			n_type_gfx radius_sy = half_sy + abs( half_sy - n_game_transition_circle_y );
			n_type_gfx radius    = n_posix_max_n_type_gfx( radius_sx, radius_sy );

			unit = ceil( (n_type_real) radius * sqrt( 2 ) );
			unit = ceil( (n_type_real) unit * 0.01 );

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );

			p_size = -1;

		}


		const n_type_gfx size = (n_type_gfx) ( unit * (*percent) );

		x = y = 0;
		n_posix_loop
		{

			n_type_gfx center_x = (n_type_gfx) x - n_game_transition_circle_x;
			n_type_gfx center_y = (n_type_gfx) y - n_game_transition_circle_y;

			n_posix_bool outer = n_bmp_hoop_detect( center_x,center_y,   size );
			n_posix_bool inner = n_posix_false;//n_bmp_hoop_detect( center_x,center_y, p_size );

			while( outer )
			{//break;

				inner = n_bmp_hoop_detect( center_x,center_y, p_size );
				if ( inner == n_posix_false ) { break; }

				center_x++; x++;
				if ( x >= bmpsx ) { break; }
			}


			if ( ( inner == n_posix_false )&&( outer ) )
			{

				u32 color;

				n_bmp_ptr_get_fast( bmp_new, (n_type_gfx) x, (n_type_gfx) y, &color );
/*
				if ( n_posix_false == n_bmp_hoop_detect( center_x,center_y, size - 2 ) )
				{
//color = 0x00ff0000;
					u32 c; n_bmp_ptr_get_fast( bmp, (n_type_gfx) ox+x, (n_type_gfx) oy+y, &c );
					color = n_bmp_blend_pixel( c, color, 0.5 );
				}
*/
				n_bmp_ptr_set_fast( bmp, (n_type_gfx) ox + (n_type_gfx) x, (n_type_gfx) oy + (n_type_gfx) y, color );

			} else
			if ( ( inner == n_posix_false )&&( outer == n_posix_false ) )
			{

				if ( center_x >= 0 ) { x = bmpsx; }

			}


			x++;
			if ( x >= bmpsx )
			{

				x = 0;

				y++;
				if ( y >= bmpsy ) { break; }
			}
		}

		p_size = size;

	} else

	if ( type == N_GAME_TRANSITION_FADE )
	{

		// WIPE_X:FADE = 1:12


		if ( (*percent) == 0 )
		{

			x  =     0;
			y  =     0;
			sx = bmpsx;
			sy = bmpsy;

		}


		// [!] : slow

		//n_bmp_fastcopy ( bmp_old, bmp, 0,0,bmpsx,bmpsy, ox,oy );
		//n_bmp_blendcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, ox,oy, (n_type_real) ( 100 - (*percent) ) * 0.01 );


		// [!] : fast

		n_game_transition_fade( bmp_old, bmp_new, bmp, (n_type_gfx) ox, (n_type_gfx) oy, (n_type_real) (*percent) * 0.01 );

	} else

	if ( type == N_GAME_TRANSITION_DIZZY )
	{

		// Performance : WIPE_X:DIZZY = 1:4


		if ( (*percent) == 0 )
		{

			unit = (n_type_real) ( bmpsx * bmpsy ) * 0.01 ;

			x  =     0;
			y  =     0;
			sx = bmpsx;
			sy = bmpsy;

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );

		}


		u32 color_old;
		u32 color_new;

		n_type_gfx i = 0;
		n_posix_loop
		{//break;

			n_type_gfx tx = n_random_range( bmpsx );
			n_type_gfx ty = n_random_range( bmpsy );

			n_bmp_ptr_get_fast( bmp    , tx,ty, &color_old );
			n_bmp_ptr_get_fast( bmp_new, tx,ty, &color_new );

			if ( color_old == color_new )
			{
				if ( ( ty - 1 ) >= 0 )
				{
					n_bmp_ptr_get_fast( bmp    , tx+0,ty-1, &color_old );
					n_bmp_ptr_get_fast( bmp_new, tx+0,ty-1, &color_new );
				}
			}

			if ( color_old == color_new )
			{
				if ( ( ty + 1 ) < bmpsy )
				{
					n_bmp_ptr_get_fast( bmp    , tx+0,ty+1, &color_old );
					n_bmp_ptr_get_fast( bmp_new, tx+0,ty+1, &color_new );
				}
			}

			if ( color_old == color_new )
			{
				if ( ( tx - 1 ) >= 0 )
				{
					n_bmp_ptr_get_fast( bmp    , tx-1,ty+0, &color_old );
					n_bmp_ptr_get_fast( bmp_new, tx-1,ty+0, &color_new );
				}
			}

			if ( color_old == color_new )
			{
				if ( ( tx + 1 ) < bmpsx )
				{
					n_bmp_ptr_get_fast( bmp    , tx+1,ty+0, &color_old );
					n_bmp_ptr_get_fast( bmp_new, tx+1,ty+0, &color_new );
				}
			}

			if ( color_old != color_new )
			{
				n_bmp_ptr_set_fast( bmp, (n_type_gfx) ox + tx, (n_type_gfx) oy + ty, color_new );
			}

			i++;
			if ( i >= unit ) { break; }

		}


		if ( (*percent) >= 100 )
		{
			n_bmp_fastcopy ( bmp_new, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );
		}

	} else

	if ( type == N_GAME_TRANSITION_MOSAIC )
	{

		// Performance : WIPE_X:MOSAIC = 1:4


		if ( (*percent) == 0 )
		{

			n_bmp_fastcopy( bmp_old, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );

		}


		n_bmp  *bmp_sample;
		n_type_real  half;

		if ( (*percent) <= 50 )
		{
			unit       = (*percent);
			bmp_sample = bmp_old;
		} else {
			unit       = 100 - (*percent);
			bmp_sample = bmp_new;
		}

		unit = n_posix_max_n_type_real( 1, unit );
		half = unit / 2;


		n_type_gfx fx,fy, fsx,fsy, startx;
		u32        color;

		x = -( fmod( bmpsx, unit ) / 2 ); startx = (n_type_gfx) x;
		y = -( fmod( bmpsy, unit ) / 2 );
		n_posix_loop
		{

			fx = (n_type_gfx) ( x + half );
			fy = (n_type_gfx) ( y + half );

			n_bmp_error_clipping( bmp_sample,NULL, &fx,&fy,NULL,NULL, NULL,NULL );

			n_bmp_ptr_get( bmp_sample, fx,fy, &color );


			fx  = (n_type_gfx) ( ox + x );
			fy  = (n_type_gfx) ( oy + y );
			fsx = (n_type_gfx) unit;
			fsy = (n_type_gfx) unit;

			if ( fx < ox ) { fx = (n_type_gfx) ox; }
			if ( fy < oy ) { fy = (n_type_gfx) oy; }
			if ( ( fx + fsx ) >= ( ox + bmpsx ) ) { fsx = ( (n_type_gfx) ox + bmpsx ) - fx; }
			if ( ( fy + fsy ) >= ( oy + bmpsy ) ) { fsy = ( (n_type_gfx) oy + bmpsy ) - fy; }

			n_bmp_box( bmp, fx,fy,fsx,fsy, color );


			x += unit;
			if ( x >= bmpsx )
			{

				x = startx;

				y += unit;
				if ( y >= bmpsy ) { break; }
			}
		}


		if ( (*percent) >= 100 )
		{

			n_bmp_fastcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );

		}

	} else

	if ( type == N_GAME_TRANSITION_WHIRL )
	{

		// Performance : WIPE_X:WHIRL = 1:8


		static n_type_real     step;
		static n_type_gfx scale;


		if ( (*percent) == 0 )
		{

			n_type_real speed = 4.0;

			step  = (n_type_real) ( 360.0 * 10.0 ) / 100.0 / speed;
			scale = 5;

		}


		n_bmp_fastcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );


		n_bmp b;
		int   pc = (int) (*percent);

		u32 color_trans = n_bmp_black_invisible;

		n_bmp_carboncopy( bmp_old, &b );
		n_bmp_scaler_lil( &b, 2 + (n_type_gfx) ( pc / scale ) );
		n_bmp_matrix_rotate( &b, (n_type_gfx) ( (n_type_real) pc * step ), color_trans, n_posix_true );
		n_bmp_resizer( &b, bmpsx,bmpsy, color_trans, N_BMP_RESIZER_CENTER );

		n_bmp_transcopy
		(
			&b, bmp,
			0,0,bmpsx,bmpsy,
			(n_type_gfx) ox + n_game_centering( bmpsx, N_BMP_SX( &b ) ),
			(n_type_gfx) oy + n_game_centering( bmpsy, N_BMP_SY( &b ) )
		);

		n_bmp_free( &b );


		if ( (*percent) >= 100 )
		{

			n_bmp_fastcopy( bmp_new, bmp, 0,0,bmpsx,bmpsy, (n_type_gfx) ox, (n_type_gfx) oy );

		}

	} else

	if ( ( type >= N_GAME_TRANSITION_SCROLL_U )&&( type <= N_GAME_TRANSITION_SCROLL_R ) )
	{

		// Performance : WIPE_X:SCROLL = 1:1


		if ( (*percent) == 0 )
		{
			sx = ceil( (n_type_real) bmpsx * 0.01 );
			sy = ceil( (n_type_real) bmpsy * 0.01 );
		}


		x = n_posix_min_n_type_real( (n_type_real) bmpsx, sx * (*percent) );
		y = n_posix_min_n_type_real( (n_type_real) bmpsy, sy * (*percent) );

//n_bmp_flush( bmp, 0 );

		n_type_gfx ix  = (n_type_gfx) x;
		n_type_gfx iy  = (n_type_gfx) y;
		n_type_gfx iox = (n_type_gfx) ox;
		n_type_gfx ioy = (n_type_gfx) oy;

		if ( type == N_GAME_TRANSITION_SCROLL_U )
		{

			n_type_gfx fy  = (n_type_gfx) y;
			n_type_gfx fsy = (n_type_gfx) ( (n_type_real) bmpsy - y );
			n_type_gfx ty  = (n_type_gfx) 0;
			n_type_gfx tsy = (n_type_gfx) y;

			n_bmp_fastcopy( bmp_old, bmp, 0,fy,bmpsx,fsy, iox,  0 + ioy );
			n_bmp_fastcopy( bmp_new, bmp, 0,ty,bmpsx,tsy, iox,fsy + ioy );

		} else
		if ( type == N_GAME_TRANSITION_SCROLL_D )
		{

			n_type_gfx fy  = (n_type_gfx) 0;
			n_type_gfx fsy = (n_type_gfx) ( (n_type_real) bmpsy - y );
			n_type_gfx ty  = (n_type_gfx) ( (n_type_real) bmpsy - y );
			n_type_gfx tsy = (n_type_gfx) y;

			n_bmp_fastcopy( bmp_old, bmp, 0,fy,bmpsx,fsy, iox,iy + ioy );
			n_bmp_fastcopy( bmp_new, bmp, 0,ty,bmpsx,tsy, iox, 0 + ioy );

		} else
		if ( type == N_GAME_TRANSITION_SCROLL_L )
		{

			n_type_gfx fx  = (n_type_gfx) x;
			n_type_gfx fsx = (n_type_gfx) ( (n_type_real) bmpsx - x );
			n_type_gfx tx  = (n_type_gfx) 0;
			n_type_gfx tsx = (n_type_gfx) x;

			n_bmp_fastcopy( bmp_old, bmp, fx,0,fsx,bmpsy,   0 + iox,ioy );
			n_bmp_fastcopy( bmp_new, bmp, tx,0,tsx,bmpsy, fsx + iox,ioy );

		} else
		if ( type == N_GAME_TRANSITION_SCROLL_R )
		{

			n_type_gfx fx  = (n_type_gfx) 0;
			n_type_gfx fsx = (n_type_gfx) ( (n_type_real) bmpsx - x );
			n_type_gfx tx  = (n_type_gfx) ( (n_type_real) bmpsx - x );
			n_type_gfx tsx = (n_type_gfx) x;

			n_bmp_fastcopy( bmp_old, bmp, fx,0,fsx,bmpsy, ix + iox,ioy );
			n_bmp_fastcopy( bmp_new, bmp, tx,0,tsx,bmpsy,  0 + iox,ioy );

		}

	}// else


	if ( (*percent) >= 100 )
	{

		(*percent) = 0;

		return n_posix_true;

	} else {

		// Auto-adjuster

		static n_type_real frame_msec = 0;
		static n_type_real tick_count = 0;

		if ( (*percent) == 0 )
		{
			frame_msec = (n_type_real) msec / 100;
			tick_count = n_posix_tickcount();
		}

		n_type_real tick_count_cur   = n_posix_tickcount();
		n_type_real tick_count_delta = tick_count_cur - tick_count;

		if ( frame_msec < tick_count_delta )
		{

			(*percent) += ceil( tick_count_delta / frame_msec );

			n_posix_sleep( (u32) ( frame_msec - fmod( tick_count_delta, frame_msec ) ) );

		} else
		if ( frame_msec > tick_count_delta )
		{

			n_posix_sleep( (u32) ( frame_msec - tick_count_delta ) );

			(*percent)++;

		} else {

			(*percent)++;

		}

		tick_count = tick_count_cur;

		(*percent) = n_posix_minmax_n_type_real( 0, 100, (*percent) );

	}


	return n_posix_false;
}


#endif // _H_NONNON_WIN32_GAME_TRANSITION

