// Marie Registry Applet
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_REGISTRY
#define _H_NONNON_WIN32_REGISTRY




#include "../neutral/string.c"

#include "./sysinfo/version.c"





#define N_REGISTRY_ASSOCIATION_CCH_MAX ( 256 )




#define n_registry_read_valuebyte_literal( a, b, c ) \
        n_registry_read_valuebyte( a, n_posix_literal( b ), n_posix_literal( c ) )

DWORD
n_registry_read_valuebyte
(
	      HKEY          hive,
	const n_posix_char *path,
	const n_posix_char *lval
)
{

	// [!] : REG_SZ : returned value includes size for NUL('\0')


	// [ MSDN ] : size limit
	//
	//	path :   255 characters
	//	lval : 16383 characters
	//	rval : available memory


	HKEY  hkey;
	DWORD ret = RegOpenKeyEx
	(
		hive,
		path,
		0,
		KEY_READ,
		&hkey
	);

	if ( ret != ERROR_SUCCESS ) { return 0; }


	ret = 0;
	RegQueryValueEx( hkey, lval, NULL, NULL, (LPBYTE) NULL, &ret );


	RegCloseKey( hkey );


	return ret;
}

#define n_registry_is_exist_literal( a, b, c ) \
        n_registry_is_exist( a, n_posix_literal( b ), n_posix_literal( c ) )

DWORD
n_registry_is_exist
(
	      HKEY          hive,
	const n_posix_char *path,
	const n_posix_char *lval
)
{

	HKEY  hkey;
	DWORD ret = RegOpenKeyEx
	(
		hive,
		path,
		0,
		KEY_READ,
		&hkey
	);

	if ( ret == ERROR_SUCCESS )
	{

		// [!] : ERROR_SUCCESS will be returned when "lval" is NULL

		if ( lval == NULL )
		{
			ret = ERROR_FILE_NOT_FOUND;
		} else {
			ret = RegQueryValueEx( hkey, lval, NULL, NULL, NULL, NULL );
		}

	}

	RegCloseKey( hkey );


	return ( ret == ERROR_SUCCESS );
}

#define n_registry_read_literal( a, b, c, d, e ) \
        n_registry_read( a, n_posix_literal( b ), n_posix_literal( c ), d, e )

DWORD
n_registry_read
(
	      HKEY          hive,
	const n_posix_char *path,
	const n_posix_char *lval,
	      void         *rval,
	      DWORD         byte
)
{

	// [!] : REG_SZ : "byte" includes size for NUL('\0')


	HKEY  hkey;
	DWORD ret = RegOpenKeyEx
	(
		hive,
		path,
		0,
		KEY_READ,
		&hkey
	);

	if ( ret == ERROR_SUCCESS )
	{

		// [!] : ERROR_SUCCESS will be returned when "lval" is NULL

		if ( lval == NULL )
		{
			ret = ERROR_FILE_NOT_FOUND;
		} else {
			ret = RegQueryValueEx( hkey, lval, NULL, NULL, (void*) rval, &byte );
		}

	}

	RegCloseKey( hkey );


	return ret;
}

#define n_registry_write_literal( a,b,c,d,e,f ) \
        n_registry_write( a, n_posix_literal( b ), n_posix_literal( c ), d, e, f )

DWORD
n_registry_write
(
	      HKEY          hive,
	const n_posix_char *path,
	const n_posix_char *lval,
	      DWORD         type,
	const void         *rval,
	      DWORD         byte
)
{

	HKEY  hkey;
	DWORD dw;
	DWORD ret = RegCreateKeyEx
	(
		hive,
		path,
		0, NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_WRITE,
		NULL,
		&hkey,
		&dw
	);

	if ( ret == ERROR_SUCCESS )
	{

		// [!] : ERROR_SUCCESS will be returned when "lval" is NULL

		if ( lval == NULL )
		{

			ret = ERROR_FILE_NOT_FOUND;

		} else {

			if ( type == REG_SZ    )
			{
				if ( rval == NULL )
				{
					byte = 0;
				} else {
					byte = (DWORD) n_posix_strlen( rval ) * sizeof( n_posix_char );
				}
			} else
			if ( type == REG_DWORD )
			{
				byte = sizeof( DWORD );
			}


			// [Needed] : in Win95

			RegDeleteValue( hkey, lval );


			// [!] : Win95 : error when "rval" is NULL

			ret = RegSetValueEx( hkey, lval, 0, type, rval, byte );

		}

	}

	RegCloseKey( hkey );


	return ret;
}

DWORD
n_registry_delete_value
(
	      HKEY          hkey,
	const n_posix_char *path,
	const n_posix_char *lval
)
{

	HKEY  hkey_child;
	DWORD ret = RegOpenKeyEx
	(
		hkey,
		path,
		0,
		KEY_WRITE,
		&hkey_child
	);

	if ( ret != ERROR_SUCCESS ) { return ERROR_BADKEY; }

	ret = RegDeleteValue( hkey_child, lval );
//n_posix_debug_literal( " %d ", (int)ret );

	RegCloseKey( hkey_child );


	return ret;
}

#define n_registry_delete_literal( a, b ) \
        n_registry_delete( a, n_posix_literal( b ) )

DWORD
n_registry_delete
(
	      HKEY          hkey,
	const n_posix_char *path
)
{

	HKEY  hkey_child;
	DWORD ret = RegOpenKeyEx
	(
		hkey,
		path,
		0,
		KEY_ENUMERATE_SUB_KEYS | DELETE,
		&hkey_child
	);

	if ( ret != ERROR_SUCCESS ) { return ERROR_BADKEY; }


	DWORD index = 0;
	n_posix_loop
	{

		n_posix_char path_child[ N_REGISTRY_ASSOCIATION_CCH_MAX ];

		DWORD byte = N_REGISTRY_ASSOCIATION_CCH_MAX * sizeof( n_posix_char );
		ret  = RegEnumKeyEx
		(
			hkey_child,
			index,
			path_child,
			&byte,
			NULL,
			NULL,
			NULL,
			NULL
		);


		if ( ret == ERROR_NO_MORE_ITEMS )
		{

			ret = RegDeleteKey( hkey, path );

			break;

		} else
		if( ret == ERROR_SUCCESS )
		{
//n_posix_debug( path );

			ret = n_registry_delete( hkey_child, path_child );

		}


		// comment-out for debug recursive enumeration

		//index++;

	}


	RegCloseKey( hkey_child );


	return ret;
}

void
n_registry_filetype_reg
(
	const n_posix_char *filetype,
	const n_posix_char *caption,
	const n_posix_char *icon,
	const n_posix_char *exe
)
{

	const n_posix_char *verb = n_posix_literal( "Open" );
	const n_posix_char *name = n_posix_literal( "" );


	HKEY          hive;
	n_posix_char *path;

	if ( ( n_sysinfo_version_9x() )||( n_posix_false == n_sysinfo_version_2000_or_later() ) )
	{
		hive = HKEY_CLASSES_ROOT;
		path = n_posix_literal( "" );
	} else {
		hive = HKEY_CURRENT_USER;
		path = n_posix_literal( "Software\\Classes\\" );
	}


	n_type_int len = n_posix_strlen( path ) + n_posix_strlen( filetype ) + n_posix_strlen_literal( "\\Shell\\Open\\Command" );
	if ( len >= N_REGISTRY_ASSOCIATION_CCH_MAX ) { return; }

	n_posix_char *p = n_string_new_fast( len );
	n_posix_sprintf_literal( p, "%s%s", path, filetype );


	n_posix_char str0[ N_REGISTRY_ASSOCIATION_CCH_MAX ];
	n_posix_char str1[ N_REGISTRY_ASSOCIATION_CCH_MAX ];
	n_posix_char str2[ N_REGISTRY_ASSOCIATION_CCH_MAX ];
	n_posix_char str3[ N_REGISTRY_ASSOCIATION_CCH_MAX ];

	n_posix_sprintf_literal( str0, "%s\\DefaultIcon", p    );
	n_posix_sprintf_literal( str1, "%s\\Shell",       p    );
	n_posix_sprintf_literal( str2, "%s\\Open",        str1 );
	n_posix_sprintf_literal( str3, "%s\\Command",     str2 );

	n_registry_write( hive,    p, N_STRING_EMPTY, REG_SZ, caption, 0 );
	n_registry_write( hive, str0, N_STRING_EMPTY, REG_SZ,    icon, 0 );
	n_registry_write( hive, str1, N_STRING_EMPTY, REG_SZ,    verb, 0 );
	n_registry_write( hive, str2, N_STRING_EMPTY, REG_SZ,    name, 0 );
	n_registry_write( hive, str3, N_STRING_EMPTY, REG_SZ,     exe, 0 );


	n_memory_free( p );


	return;
}

void
n_registry_filetype_unreg( const n_posix_char *filetype )
{

	HKEY          hive;
	n_posix_char *path;

	if ( ( n_sysinfo_version_9x() )||( n_posix_false == n_sysinfo_version_2000_or_later() ) )
	{
		hive = HKEY_CLASSES_ROOT;
		path = n_posix_literal( "" );
	} else {
		hive = HKEY_CURRENT_USER;
		path = n_posix_literal( "Software\\Classes\\" );
	}


	n_type_int len = n_posix_strlen( path ) + n_posix_strlen( filetype );
	if ( len >= N_REGISTRY_ASSOCIATION_CCH_MAX ) { return; }

	n_posix_char *p = n_string_new_fast( len );
	n_posix_sprintf_literal( p, "%s%s", path, filetype );


	HKEY  hkey;
	DWORD ret = RegOpenKeyEx( hive, p, 0, KEY_WRITE, &hkey );

	if ( ret == ERROR_SUCCESS )
	{
		RegDeleteKey( hive, n_posix_literal( "Shell\\Open\\Command" ) );
		RegDeleteKey( hive, n_posix_literal( "Shell\\Open"          ) );
		RegDeleteKey( hive, n_posix_literal( "Shell"                ) );
		RegDeleteKey( hive, n_posix_literal( "DefaultIcon"          ) );
		RegDeleteKey( hive, n_posix_literal( ""                     ) );
	}

	RegCloseKey( hkey );


	n_memory_free( p );


	return;
}

DWORD
n_registry_fileexts_clean( const n_posix_char *ext )
{

	// [Mechanism]
	//
	//	Explorer has own extension list
	//	this causes a problem that incorrect icons could be drawn


	if ( n_string_is_empty( ext ) ) { return n_posix_true; }


	const n_posix_char *fileexts = n_posix_literal
	(
		"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\"
	);


	n_posix_char *s = n_string_new( n_posix_strlen( fileexts ) + n_posix_strlen( ext ) );


	n_string_copy( fileexts, s );
	n_posix_strcat( s, ext );

	DWORD ret = n_registry_delete( HKEY_CURRENT_USER, s );


	n_memory_free( s );


	return ret;
}

#define n_registry_association_add_literal( ext, filetype ) n_registry_association_add( n_posix_literal( ext ), n_posix_literal( filetype ) )

DWORD
n_registry_association_add( const n_posix_char *ext, const n_posix_char *filetype )
{

	if ( n_string_is_empty( ext ) ) { return n_posix_true; }


	HKEY         hive;
	n_posix_char path[ N_REGISTRY_ASSOCIATION_CCH_MAX ];

	if ( ( n_sysinfo_version_9x() )||( n_posix_false == n_sysinfo_version_2000_or_later() ) )
	{
		hive = HKEY_CLASSES_ROOT;
		n_posix_sprintf_literal( path, "%s", ext );
	} else {
		hive = HKEY_CURRENT_USER;
		n_posix_sprintf_literal( path, "Software\\Classes\\%s", ext );
	}

	DWORD ret = n_registry_write( hive, path, N_STRING_EMPTY, REG_SZ, filetype, 0 );


	n_registry_fileexts_clean( ext );


	return ret;
}

DWORD
n_registry_association_del( const n_posix_char *name )
{

	// [!] : extension and filetype are written in the same registry location


	if ( n_string_is_empty( name ) ) { return n_posix_true; }


	HKEY         hive;
	n_posix_char path[ N_REGISTRY_ASSOCIATION_CCH_MAX ];

	if ( ( n_sysinfo_version_9x() )||( n_posix_false == n_sysinfo_version_2000_or_later() ) )
	{
		hive = HKEY_CLASSES_ROOT;
		n_string_copy( name, path );
	} else {
		hive = HKEY_CURRENT_USER;
		n_posix_sprintf_literal( path, "Software\\Classes\\%s", name );
	}

	DWORD ret = n_registry_delete( hive, path );


	return ret;
}


#endif // _H_NONNON_WIN32_REGISTRY

