// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_win_txtbox_draw_singleline
(
	n_win_txtbox *p,
	         HDC  hdc,
	  n_type_int  text_y,
	  n_type_gfx  x,
	  n_type_gfx  y,
	  n_type_gfx  sx,
	  n_type_gfx  sy
)
{
//return;

	if ( p == NULL ) { return; }


	if ( p->combo_popup_slide_onoff )
	{
		//
	} else {
		n_type_int f = p->scroll_pxl_tabbed_y;
		n_type_int t = p->scroll_pxl_tabbed_y + p->page_pxl_tabbed_sy;

		f /= p->cell_pxl_sy;
		t /= p->cell_pxl_sy;

		if ( text_y < f ) { return; }
		if ( text_y > t ) { return; }
	}


	n_posix_bool editbox = ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX );


	if ( editbox )
	{
		if ( ( x + sx ) > p->canvas_pxl_sx )
		{
			sx = p->canvas_pxl_sx + ( p->border_pxl_sx * 2 ) + ( p->pad_pxl_sx * 2 );
			 x = p->border_pxl_sx;
		}
	}


//if ( p->debug_onoff ) { return; }


	int p_bkmode = GetBkMode( hdc );
	SetBkMode( hdc, TRANSPARENT );


	// [!] : Background

	COLORREF bg = 0;

	if ( 0 )
	{
		//
	} else
	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		//
	} else {
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", sx, p->canvas_pxl_sx );

		n_type_gfx tx  =  x;
		n_type_gfx ty  =  y;
		n_type_gfx tsx = sx;
		n_type_gfx tsy = sy;

		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_NONE )
		{
			//
		} else
		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL )
		{
			//
		} else
		if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART )
		{
			tx  = p->caret_redraw_x;
			tsx = p->caret_redraw_sx;
		}

		// [Needed] : ONELINE patch : "sy" needs to have more size

		n_type_gfx bg_x  = tx;
		n_type_gfx bg_y  = ty;
		n_type_gfx bg_sx = tsx;
		n_type_gfx bg_sy = tsy;

		if ( p->scroll_pxl_tabbed_x != 0 ) { bg_x = 0; bg_sx = sx; }

		if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP ) { bg_sx += p->scrollbar_pxl_sx; }

		n_win_txtbox_draw_background( p, hdc, text_y, bg_x, bg_y, bg_sx, bg_sy, &bg, n_posix_false, n_posix_true );

	}


	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) { sx -= p->smallbutton_margin; }


	n_posix_bool tab_onoff = ( n_posix_false == n_string_is_empty( p->tab_mark ) );
	n_posix_bool eol_onoff = ( n_posix_false == n_string_is_empty( p->eol_mark ) );


	n_posix_bool tab_auto = n_posix_false;

	if ( tab_onoff )
	{
		tab_auto = n_string_is_same_literal( "auto", p->tab_mark );
	}


	n_posix_char *eol_str = n_win_txtbox_eol_string_get( p );


	n_posix_char *text = n_txt_get( &p->txt, text_y );
//n_win_txtbox_hwndprintf_literal( p, " %s ", text ); return;

	n_posix_bool effect_onoff      = n_posix_false;
	HFONT        effect_hfont_main = NULL;
	HFONT        effect_hfont_noln = NULL;

	n_posix_bool is_bold      = n_posix_false;
	n_posix_bool is_italic    = n_posix_false;
	n_posix_bool is_underline = n_posix_false;
	n_posix_bool is_strikeout = n_posix_false;

	if (
		( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS )
		&&
		( text[ 0 ] != N_STRING_CHAR_NUL )
	)
	{

		if (
			( text[ 1 ] == n_posix_literal( 'B' ) )
			||
			( text[ 1 ] == n_posix_literal( 'I' ) )
			||
			( text[ 1 ] == n_posix_literal( 'U' ) )
			||
			( text[ 1 ] == n_posix_literal( 'S' ) )
		)
		{
			effect_onoff = is_bold = n_posix_true;
		}


		if (
			( text[ 1 ] == n_posix_literal( 'i' ) )
			||
			( text[ 1 ] == n_posix_literal( 'I' ) )
		)
		{
			effect_onoff = is_italic = n_posix_true;
		} else
		if (
			( text[ 1 ] == n_posix_literal( 'u' ) )
			||
			( text[ 1 ] == n_posix_literal( 'U' ) )
		)
		{
			effect_onoff = is_underline = n_posix_true;
		} else
		if (
			( text[ 1 ] == n_posix_literal( 's' ) )
			||
			( text[ 1 ] == n_posix_literal( 'S' ) )
		)
		{
			effect_onoff = is_strikeout = n_posix_true;
		}


		if ( effect_onoff )
		{
			HFONT  hf_base    = n_win_font_get( p->hwnd );
			HFONT  hf_effect  = n_win_txtbox_font_effect( hf_base, is_bold, is_italic,  is_underline, is_strikeout );
			effect_hfont_noln = n_win_txtbox_font_effect( hf_base, is_bold, is_italic, n_posix_false, is_strikeout );
			effect_hfont_main = SelectObject( hdc, hf_effect );
		}

		if ( 3 <= n_posix_strlen( text ) ) { text = &text[ 3 ]; }

	}


	// Fast Mode

	n_type_int   text_cch           = 0;
	n_type_int   text_cch_ret       = 0;
	n_posix_bool text_tab_is_exist  = n_posix_false;
	n_posix_bool text_fullwidth     = n_posix_false;
	n_posix_bool text_surrogatepair = n_posix_false;
	n_posix_bool text_accent_mark   = n_posix_false;

	n_win_txtbox_tab2space
	(
		 p, text,
		 p->tabstop,
		&text_cch,
		&text_cch_ret,
		&text_tab_is_exist,
		&text_fullwidth,
		&text_surrogatepair,
		&text_accent_mark,
		 n_posix_false
	);


	extern n_posix_bool n_win_txtbox_is_selected( n_win_txtbox *p );

/*
if ( n_win_txtbox_is_selected( p ) )
{
	n_win_txtbox_hwndprintf_literal
	(
		p,
		" %d %d %d %d %d : %d %d %d ",
		text_fullwidth,
		text_surrogatepair,
		text_accent_mark,
		tab_auto,
		eol_onoff,
		p->select_cch_sx, p->select_cch_y, text_y
	);
}
*/
/*
if ( text_y == 1 )
{
	n_win_txtbox_hwndprintf_literal
	(
		p,
		" %d %d ",
		p->select_cch_sx,
		text_cch_ret
	);
}
*/
	if (
//(0)&&
		( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ) )
		&&
		( text_fullwidth     == n_posix_false )
		&&
		( text_surrogatepair == n_posix_false )
		&&
		( text_accent_mark   == n_posix_false )
		&&
		(
			( tab_auto          == n_posix_false )
			||
			( text_tab_is_exist == n_posix_false )
		)
		&&
		//( eol_onoff == n_posix_false )
		//&&
		( editbox == n_posix_false )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " Fast Mode " );


		// Line Number

		HFONT hf_tmp;
		if ( ( effect_onoff )&&( is_bold ) )
		{
			hf_tmp = effect_hfont_main;
		} else {
			hf_tmp = SelectObject( hdc, n_win_font_get( p->hwnd ) );
		}

		n_win_txtbox_draw_linenumber( p, hdc, text_y, x,y,sx,sy, is_underline, effect_hfont_noln );

		n_type_gfx linenum_osx = 0;
		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
		{
			linenum_osx = -p->border_pxl_sx + p->number_pxl_sx + p->number_pad_pxl_sx;
		}
		x = n_posix_max_n_type_gfx( p->pad_pxl_sx + linenum_osx, x );

		if ( ( effect_onoff )&&( is_bold ) )
		{
			//
		} else {
			SelectObject( hdc, hf_tmp );
		}


		// Text

		//n_posix_char *s = n_win_txtbox_tab2space( p, text, p->tabstop, &text_cch, &text_cch_ret, NULL,NULL,NULL,NULL, n_posix_true );
		n_posix_char *s = n_win_txtbox_tab2space_fast( p, text, p->tabstop, text_cch, n_posix_true );


		n_type_gfx pxl_x  = p->border_pxl_sx + p->virtual_padding_pxl_sx + p->pad_pxl_sx + linenum_osx;
		n_type_gfx pxl_sx = p->client_pxl_sx;
		RECT       rect   = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );

		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{

			// [!] : hard to implement : undefined stat is zero

			if ( ( p->listbox_is_selected )&&( text_y == p->select_cch_y ) )
			{
				SetTextColor( hdc, n_win_color_blend( p->color_text_selected, p->color_back_selected, p->text_fade_ratio ) );
			} else {
				SetTextColor( hdc, n_win_color_blend( p->color_text_noselect, p->color_back_noselect, p->text_fade_ratio ) );
			}

		} else {

			if ( ( text_y > p->select_cch_y )&&( text_y <  ( p->select_cch_y + p->select_cch_sy ) ) )
			{
				RECT r; n_win_rect_set( &r, (int) pxl_x, (int) y, (int) ( text_cch_ret * p->font_pxl_sx ), (int) sy );
				n_win_txtbox_draw_box( p, hdc, &r, p->color_back_selected );

				SetTextColor( hdc, n_win_color_blend( p->color_text_selected, p->color_back_selected, p->text_fade_ratio ) );
			} else
			if ( ( text_y == p->select_cch_y )&&( p->select_cch_sy == 1 )&&( p->select_cch_sx == text_cch_ret ) )
			{
				// [!] : currently not reached because of caret fader

				RECT r; n_win_rect_set( &r, (int) pxl_x, (int) y, (int) ( text_cch_ret * p->font_pxl_sx ), (int) sy );
				n_win_txtbox_draw_box( p, hdc, &r, p->color_back_selected );

				SetTextColor( hdc, n_win_color_blend( p->color_text_selected, p->color_back_selected, p->text_fade_ratio ) );
			} else {
				SetTextColor( hdc, n_win_color_blend( p->color_text_noselect, p->color_back_noselect, p->text_fade_ratio ) );
			}

		}

		n_win_txtbox_draw_text( p, hdc, s,-1, &rect, p->drawtext_modes );


		n_memory_free( s );


		// End-Of-Line Marker

		if ( ( eol_onoff )&&( text_y < p->txt.sy ) )
		{
			n_win_txtbox_draw_eol( p, hdc, pxl_x + ( text_cch_ret * p->font_pxl_sx ), y, bg, eol_str );
		}


		// Round Corner

		n_win_txtbox_round_corner( p, text_y, pxl_x, y, bg );


		if ( effect_onoff )
		{
			n_win_font_exit( SelectObject( hdc, effect_hfont_main ) );
			n_win_font_exit(                    effect_hfont_noln   );
		}


		SetBkMode( hdc, p_bkmode );

		return;

	} else
	if (
//(0)&&
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( p->oneline_placeholder_onoff )
		&&
		( n_posix_false == n_string_is_empty( p->placeholder ) )
		&&
		( n_string_is_empty( text ) )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " ONELINE : Place Holder " );

		n_type_gfx pxl_x  = x;
		n_type_gfx pxl_sx = sx;

		SIZE size = n_win_txtbox_size_text( p, p->placeholder );
		if ( p->canvas_real_pxl_sx > size.cx )
		{
			pxl_x = ( p->canvas_real_pxl_sx - size.cx ) / 2;
		}

		SetTextColor( hdc, p->color___placeholder );

		RECT rect = n_win_rect_set( NULL, pxl_x, y, pxl_sx, sy );

		n_win_txtbox_draw_text( p, hdc, p->placeholder,-1, &rect, p->drawtext_modes );

		SetBkMode( hdc, p_bkmode );

		return;

	}


	// Slow Mode
	//
	//	+ tabstop support
	//	+ CJK fixed pitch patch

//n_win_txtbox_hwndprintf_literal( p, " Slow Mode " );

	SIZE       size = { 0,0 };
	n_type_int  cch = 0;
	n_type_int  tab = 0;

	n_posix_bool caret_fx_onoff = n_posix_false;
	n_posix_bool caret_tx_onoff = n_posix_false;

	n_type_int caret_fx = 0;
	n_type_int caret_tx = 0;
	n_type_int text_x   = 0;
	n_type_int tail_x   = 0;
	n_type_gfx horz_x   = n_win_txtbox_horizontal_centering( p );

	if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
	{
		tail_x = p->pad_pxl_sx + p->number_pxl_sx + p->number_pad_pxl_sx;
	} else {
		tail_x = p->border_pxl_sx + p->pad_pxl_sx + p->maclike_offset;

		// [Patch] : for usability : see is_hovered() edit_on_typing()
		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			if ( p->scroll_pxl_tabbed_x != 0 ) { tail_x -= p->pad_pxl_sx; }
		}
	}

	tail_x += p->virtual_padding_pxl_sx;

	tail_x -= p->scroll_pxl_tabbed_x;
	tail_x += horz_x;
//n_win_txtbox_hwndprintf_literal( p, " %d ", tail_x );


	p->selection_onoff = n_posix_false;
	n_win_rect_set( &p->selection_rect, 0,0,0,0 );


	tail_x += p->shadow_l;


	p->corner_pxl_ox  = -1;
	p->corner_pxl_osx =  0;


	n_posix_loop
	{//break;

//n_win_txtbox_hwndprintf_literal( p, " %d ", tail_x );
//n_posix_sleep( 10 );

		n_posix_char *character = n_win_txtbox_character( p, hdc, text, text_x, &size, &cch, &tab );

		if ( n_string_is_empty( character ) )
		{

			if ( caret_fx_onoff == n_posix_false ) { caret_fx_onoff = n_posix_true; caret_fx = tail_x; }
			if ( caret_tx_onoff == n_posix_false ) { caret_tx_onoff = n_posix_true; caret_tx = tail_x; }

			break;

		}


		// [!] : DrawText() will be slowdown without manual clipping

		n_posix_bool is_highlighted = n_win_txtbox_is_highlighted( p, text_x, text_y );
//n_win_txtbox_hwndprintf_literal( p, " %d ", is_highlighted );

		if ( is_highlighted )
		{
			SetTextColor( hdc, n_win_color_blend( p->color_text_selected, p->color_back_noselect, p->text_fade_ratio ) );
		} else {
			SetTextColor( hdc, n_win_color_blend( p->color_text_noselect, p->color_back_noselect, p->text_fade_ratio ) );
		}
//if ( color_bg ) {}
//size.cx *= 2;

		{

			n_posix_bool draw_text_onoff = n_posix_false;

			if ( p->optimization_onoff )
			{

				if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL )
				{

					draw_text_onoff = n_posix_true;

				} else
				if ( p->optimization_sync == N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART )
				{

					if ( ( tail_x >= ( p->caret_redraw_x - p->size_fullwidth.cx ) )&&( tail_x <= ( p->caret_redraw_x + p->caret_redraw_sx ) ) )
					{
						draw_text_onoff = n_posix_true;
					}

				} else {

					draw_text_onoff = n_posix_true;

				}

			} else {

				draw_text_onoff = n_posix_true;

			}

			if ( tail_x < ( 0 - p->size_fullwidth.cx ) )
			{
				draw_text_onoff = n_posix_false;
			} else
			if ( tail_x > ( p->client_pxl_sx - p->smallbutton_margin ) )
			{
				draw_text_onoff = n_posix_false;
			}

			if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
			{
				//
			} else {
				if ( tail_x >= ( p->client_pxl_sx - p->border_pxl_sx - p->pad_pxl_sx - p->scrollbar_pxl_sx ) )
				{
					draw_text_onoff = n_posix_false;
				}
			}

//draw_text_onoff = n_posix_true;

			if ( draw_text_onoff )
			{

				if ( is_highlighted )
				{

					// [x] : ExcludeClipRect() is not working when you use n_bmp_*() functions

					n_type_gfx tx,ty,tsx,tsy;
					if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
					{
						 tx = (n_type_gfx) tail_x;
						 ty = p->caret_pxl_y;
						tsx = size.cx;
						tsy = p->cell_pxl_sy;

						if ( p->corner_pxl_ox == -1 ) { p->corner_pxl_ox = tx; }
						p->corner_pxl_osx += tsx;
					} else {
						 tx = (n_type_gfx) tail_x;
						 ty = y;
						tsx = size.cx;
						tsy = p->cell_pxl_sy;
					}

					if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
					{
						// [!] : delayed : see n_win_txtbox_draw_bitblt()

						if ( p->selection_onoff == n_posix_false )
						{
							p->selection_onoff = n_posix_true;
						}
					} else {
						RECT rect = n_win_rect_set( NULL, (int) tx, (int) ty, (int) tsx, (int) tsy );
						COLORREF bg = n_win_color_blend( p->color_back_selected, p->color_back_noselect, p->text_fade_ratio );
						n_win_txtbox_draw_box( p, hdc, &rect, bg );
					}

				}


				if ( tab_onoff )
				{
					if ( text[ text_x ] == N_STRING_CHAR_TAB )
					{
						if ( tab_auto )
						{
							RECT rect = n_win_rect_set( NULL, (int) tail_x, (int) y, 1, size.cy );
							n_win_txtbox_draw_box( p, hdc, &rect, p->color_text_tab_mark );
						} else {
							SetTextColor( hdc, p->color_text_tab_mark );
							character[ 0 ] = p->tab_mark[ 0 ];
						}
					}
				}


				RECT rect = n_win_rect_set( NULL, (int) tail_x, (int) y, (int) size.cx, (int) p->cell_pxl_sy );

				if ( p->debug_draw_onoff )
				{
					n_win_txtbox_draw_box( p, hdc, &rect, RGB( 0,n_random_range( 255 ),n_random_range( 255 ) ) );
				}

				if (
//(0)&&
					( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX ) )
					&&
					( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
					&&
					( cch == 1 )
					&&
					( character[ 0 ] < p->cache_limit )
				)
				{
					int               index = character[ 0 ];
					n_posix_bool is_striped = ( bg == p->color_back_striping );
					n_bmp            *cache = n_win_txtbox_glyph_cache( p, index, is_striped, is_highlighted );

					n_type_gfx clip_fx = 0;
					n_type_gfx clip_tx = (n_type_gfx) tail_x;
					if ( tail_x < p->border_pxl_sx )
					{
						n_type_gfx abs_x = (n_type_gfx) tail_x;
						if ( abs_x < 0 ) { abs_x *= -1; }

						clip_fx = abs_x + p->border_pxl_sx;
						clip_tx = clip_tx + clip_fx;
					}

					n_type_gfx clip_sx = size.cx;
					if ( ( tail_x + size.cx ) > sx )
					{
						clip_sx = (n_type_gfx) ( sx - ( tail_x + size.cx ) );
					}

					n_bmp_fastcopy( cache, &p->bmp, clip_fx,0,clip_sx,p->cell_pxl_sy, clip_tx,y );
				} else {
					n_win_txtbox_draw_text( p, hdc, character, cch, &rect, p->drawtext_modes | DT_CENTER );
				}

			}

		}


		if ( is_highlighted )
		{

			if ( caret_fx_onoff == n_posix_false ) { caret_fx_onoff = n_posix_true; caret_fx = tail_x          ; }
			                                         caret_tx_onoff = n_posix_true; caret_tx = tail_x + size.cx;

		} else {

			if (
				( ( p->partial_selection_from_onoff )&&( text_x == p->partial_selection_to___cch_x ) )
				||
				( ( p->partial_selection_to___onoff )&&( text_x == p->partial_selection_from_cch_x ) )
				||
				( text_x == p->select_cch_x )
			)
			{
				if ( p->select_cch_sx == 0 ) { caret_fx_onoff = n_posix_true; caret_fx = tail_x; }
				                               caret_tx_onoff = n_posix_true; caret_tx = tail_x;
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", caret_fx, caret_tx );
			}

		}

		n_type_int inc = n_string_doublebyte_increment( text[ text_x ] );
		if (
			( n_unicode_surrogatepair_is_hi( character[ 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( character[ 1 ] ) )
		)
		{
			inc = 2;
		}

		text_x += inc;
		tail_x += size.cx;

	}


	// [!] : Padding Patch

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		if ( p->scroll_pxl_tabbed_x != 0 )
		{
			u32 color = n_bmp_colorref2argb( p->color_back_noselect );

			n_type_gfx m = p->border_pxl_sx + p->pad_pxl_sx + p->maclike_offset;

			n_bmp_box( &p->bmp, 0,                 0,m,p->client_pxl_sy, color );
			n_bmp_box( &p->bmp, 0,p->client_pxl_sx-m,m,p->client_pxl_sy, color );
		}
	}


	// [!] : delayed : see n_win_txtbox_draw_bitblt()

	if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
	{
		n_win_rect_set( &p->selection_rect, (int) caret_fx, (int) y, (int) ( caret_tx - caret_fx ), (int) sy );
	}


	n_win_txtbox_round_corner( p, text_y, (n_type_gfx) caret_fx, (n_type_gfx) y, bg );


	if ( editbox )
	{

		// End-Of-Line Marker

		if ( ( eol_onoff )&&( text_y < p->txt.sy ) )
		{
			n_win_txtbox_draw_eol( p, hdc, tail_x,y, bg, eol_str );
		}


		// Caret

		// [!] : don't use p->hover_cch_y : value will be changed when scrolled

		n_type_int line_fy = n_posix_minmax_n_type_int( 0, p->txt.sy - 1, p->drag_cch_y - ( p->select_cch_sy - 1 ) );
		n_type_int line_ty = p->select_cch_y + p->select_cch_sy - 1;

		if ( p->partial_selection_from_onoff )
		{
			line_fy = p->select_cch_y + p->select_cch_sy - 1;
		} else
		if ( p->partial_selection_to___onoff )
		{
			line_fy = p->select_cch_y;
		}


		// [ Mechanism ]
		//
		//	#define VK_LEFT  37
		//	#define VK_UP    38
		//	#define VK_RIGHT 39
		//	#define VK_DOWN  40

		n_type_int line    = line_ty;
		n_type_int caret_x = caret_tx;
		n_type_int caret_y = y;
		if ( p->partial_selection_from_onoff )
		{

			//

		} else
		if ( p->partial_selection_to___onoff )
		{

			line    = line_fy;
			caret_x = caret_fx;

		} else {

			if ( ( p->shift_dragging == VK_LEFT )||( p->shift_dragging == VK_RIGHT ) )
			{
				if ( p->is_caret_tail )
				{
					caret_x = caret_tx;
				} else {
					caret_x = caret_fx;
				}
			} else
			if ( p->shift_dragging == VK_UP )
			{
				line    = line_fy;
				caret_x = caret_fx;
			}

		}
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", caret_fx, caret_tx );

		if ( line == text_y )
		{
//static int i = 0; n_win_txtbox_hwndprintf_literal( p, " %d %d ", i, caret_x ); i++;

			p->caret_pxl_x = (n_type_gfx) caret_x;
			p->caret_pxl_y = (n_type_gfx) caret_y;

			// [!] : delayed : see n_win_txtbox_draw_bitblt()

			if ( p->style & N_WIN_TXTBOX_STYLE_TRANSBG )
			{
				//
			} else {
				n_win_txtbox_draw_caret( p, hdc, &p->bmp );
			}
//n_win_txtbox_hwndprintf_literal( p, " %d ", p->ime.x );

			n_win_txtbox_draw_caret_position_set( p );

		}

	}


	// Line Number

	n_win_txtbox_draw_linenumber( p, hdc, text_y, x,y,sx,sy, is_underline, effect_hfont_noln );


	if ( effect_onoff )
	{
		n_win_font_exit( SelectObject( hdc, effect_hfont_main ) );
		n_win_font_exit(                    effect_hfont_noln   );
	}


	SetBkMode( hdc, p_bkmode );


	return;
}


