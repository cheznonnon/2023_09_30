// Nonnon HTML : Favorites(.URL) to HTML converter
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../nonnon/neutral/dir.c"
#include "../../nonnon/neutral/html.c"
#include "../../nonnon/neutral/ini.c"

#include "../../nonnon/mac/n_txtbox.c"




#define N_FAVORITES2HTML_EXT_URL    n_posix_literal( ".url\0\0" )
#define N_FAVORITES2HTML_EXT_HTM    n_posix_literal( ".htm\0\0" )
#define N_FAVORITES2HTML_EXT_HTML   n_posix_literal( ".html\0\0" )
#define N_FAVORITES2HTML_EXT_WEBLOC n_posix_literal( ".webloc\0\0" )




// internal
void
n_favorites2html_encode_file_write( const n_posix_char *fname, n_html *html, n_type_int *start, const n_posix_char *s )
{

	if ( n_string_is_empty( s ) ) { return; }


	n_posix_char *name = n_string_path_name_new( fname ); n_string_path_ext_del( name );


	n_posix_char *tag = n_string_new_fast
	(
		n_posix_strlen( s ) +
		n_posix_strlen( name ) +
		n_posix_strlen_literal( "<a href=\"\"></a><br>" )
	);

	n_posix_sprintf_literal( tag, "<a href=\"%s\">%s</a><br>", s, name );
//NSLog( @"%@", n_mac_str2nsstring( tag ) );

	n_html_add( html, (*start)++, tag );

	n_string_free( tag );


	n_string_path_free( name );


	return;
}

// internal
void
n_favorites2html_encode_file( const n_posix_char *fname, n_html *html, n_type_int *start )
{

	if ( n_html_error( html ) ) { return; }
	if ( start == NULL ) { return; }


	if ( n_string_path_ext_is_same( N_FAVORITES2HTML_EXT_URL, fname ) )
	{

		n_ini ini; n_ini_zero( &ini );
		if ( n_ini_load( &ini, fname ) ) { return; }

 
		const n_posix_char *section = n_posix_literal( "[InternetShortcut]" );
		const n_posix_char *keyname = n_posix_literal( "URL" );

		n_posix_char *s = n_ini_value_str_new( &ini, section, keyname, N_STRING_EMPTY );
//NSLog( @"%@", n_mac_str2nsstring( s ) );

		n_favorites2html_encode_file_write( fname, html, start, s );

		n_memory_free( s );


		n_ini_free( &ini );

	} else
	if ( n_string_path_ext_is_same( N_FAVORITES2HTML_EXT_WEBLOC, fname ) )
	{

		NSString *pth = n_mac_str2nsstring( (void*) fname );
		NSString *ret = n_mac_webloc_resolve( pth );


		n_posix_char *s = n_mac_nsstring2str( ret );

		n_favorites2html_encode_file_write( fname, html, start, s );

		n_memory_free( s );

	}


	return;
}

// internal
n_posix_bool
n_favorites2html_encode_directory( const n_posix_char *path, n_html *html, n_type_int *start )
{

	if ( n_html_error( html ) ) { return n_posix_true; }
	if ( start == NULL ) { return n_posix_true; }


	n_dir d; n_dir_zero( &d );
	if ( n_dir_load( &d, path ) ) { return n_posix_true; }

	if ( 0 == n_dir_all( &d ) ) { n_dir_free( &d ); return n_posix_false; }

	n_dir_sort( &d );


	{

		n_posix_char *str = n_string_path_name_new( path );

		n_html_add_literal( html, (*start)++, "" );
		n_html_add_literal( html, (*start)++, "<br>" );
		n_html_add_literal( html, (*start)++, "" );
		n_html_add_literal( html, (*start)++, "<p class=\"header\">" );
		n_html_add        ( html, (*start)++, str );
		n_html_add_literal( html, (*start)++, "</p>" );
		n_html_add_literal( html, (*start)++, "" );

		n_string_path_free( str );

	}


	n_type_int i = d.dir;
	n_posix_loop
	{

		if ( i >= n_dir_all( &d ) ) { break; }


		n_posix_char *str = n_string_path_make_new( path, n_dir_name( &d, i ) );
//n_posix_debug( str );

		if ( n_posix_stat_is_file( str ) )
		{
			n_favorites2html_encode_file( str, html, start );
		}

		n_string_path_free( str );


		i++;

	}


	static n_type_int nest = 0;

	i = 0;
	n_posix_loop
	{

		if ( i >= d.dir ) { break; }


		n_posix_char *str = n_string_path_make_new( path, n_dir_name( &d, i ) );
//NSLog( @"%@", n_mac_str2nsstring( str ) );

		if ( n_posix_stat_is_dir( str ) )
		{

			// [!] : ignore subsubfolders

			nest++;

			if ( nest == 1 )
			{
				n_favorites2html_encode_directory( str, html, start );
			}

			nest--;


		}

		n_string_path_free( str );


		i++;

	}


	// [!] : footer

	if ( nest == 0 )
	{
		n_html_add_literal( html, (*start)++, "" );
		n_html_add_literal( html, (*start)++, "<br>" );
		n_html_add_literal( html, (*start)++, "" );
	}


	n_dir_free( &d );


	return n_posix_false;
}

n_posix_bool
n_favorites2html_encode( n_posix_char *path )
{

	if ( n_posix_false == n_posix_stat_is_dir( path ) ) { return n_posix_true; }


	// [Mechanism]
	//
	//	1 : loading a template file from resouorce
	//	2 : add entries into it
	//	3 : save as "favorites.html"


	n_posix_char *curdir = n_string_path_folder_current_new();

	n_posix_char *upper = n_string_path_upperfolder_new( path );
	n_string_path_folder_change( upper );
	n_string_path_free( upper );


	n_posix_char *favorites = n_string_path_cat( path, N_FAVORITES2HTML_EXT_HTML, NULL );


#ifdef N_POSIX_PLATFORM_WINDOWS

	{
		const n_posix_char *rc_lite = n_posix_literal( "FAVORITES_LITE" );
		const n_posix_char *rc_dark = n_posix_literal( "FAVORITES_DARK" );
		const n_posix_char *section = n_posix_literal( "DATA" );

		n_project_darkmode();

		if ( n_win_darkmode_onoff )
		{
			n_resource_save( rc_dark, section, favorites );
		} else {
			n_resource_save( rc_lite, section, favorites );
		}
	}

#else  // #ifdef N_POSIX_PLATFORM_WINDOWS

	{
		NSString     *path = [[NSBundle mainBundle] pathForResource:@"favorites" ofType:@"html"];
		n_posix_char *from = n_mac_nsstring2str( path );

		n_filer_copy_single( from, favorites, n_posix_true );
//return 0;
	}

#endif // #ifdef N_POSIX_PLATFORM_WINDOWS


	// [!] : use n_txt_load() for reserve html's layout

	n_html html; n_html_zero( &html );

	if ( n_txt_load_utf8( &html, favorites ) )
	{
//NSLog( @"n_txt_load()" );

		n_string_path_free( favorites );

		n_string_path_folder_change( curdir );
		n_string_path_free( curdir );

		return n_posix_true;
	}


	n_type_int i = 0;
	n_posix_loop
	{
//NSLog( @"%s", (char*) html.line[ i ] );

		if ( n_string_is_same_literal( "<!--Start-->", html.line[ i ] ) )
		{
			n_html_del( &html, i );
			break;
		}


		i++;
		if ( i >= html.sy ) { break; }
	}


	n_favorites2html_encode_directory( path, &html, &i );


	n_txt_save_utf8( &html, favorites );
	n_html_free( &html );


	n_string_path_free( favorites );


	n_string_path_folder_change( curdir );
	n_string_path_free( curdir );


	return n_posix_false;
}

// internal
void
n_favorites2html_decode_file( const n_posix_char *path, const n_posix_char *url )
{

	if ( n_string_is_empty( path ) ) { return; }

/*
	n_ini ini; n_ini_zero( &ini ); n_ini_new( &ini );

	n_ini_section_add_literal( &ini, "[InternetShortcut]" );
	n_ini_key_add_literal    ( &ini, "[InternetShortcut]", "URL", url );

	n_ini_save( &ini, path );
	n_ini_free( &ini );
*/

	n_mac_webloc_save( path, url );


	return;
}

n_posix_bool
n_favorites2html_decode( const n_posix_char *fname )
{

	if (
		( n_posix_false == n_string_path_ext_is_same( N_FAVORITES2HTML_EXT_HTML, fname ) )
		&&
		( n_posix_false == n_string_path_ext_is_same( N_FAVORITES2HTML_EXT_HTM,  fname ) )
	)
	{
		return n_posix_true;
	}


	n_html html; n_html_zero( &html );
	n_html lval; n_html_zero( &lval );
	n_html rval; n_html_zero( &rval );

	if ( n_html_load( &html, fname ) ) { return n_posix_true; }


	n_posix_char *curdir = n_string_path_folder_current_new();

	n_string_path_folder_change( fname );


	n_posix_char *favorites = n_string_path_upperfolder_new( fname );
	n_posix_char *folder    = NULL;


	n_posix_bool is_first = n_posix_true;

	n_type_int i = 0;
	n_posix_loop
	{

		if ( n_html_element_match_literal( html.line[ i ], "p" ) )
		{

			// [!] : the next line has data

			i++;


			n_string_path_free( folder );
			folder = n_string_path_make_new( favorites, html.line[ i ] );

			// [!] : this will be a top-level folder

			if ( is_first )
			{
				is_first = n_posix_false;

				n_string_path_free( favorites );
				favorites = n_string_path_carboncopy( folder );
			}

			n_posix_mkdir( folder, 0777 );

		} else
		if ( n_html_element_match_literal( html.line[ i ], "a" ) )
		{
//n_posix_debug( html.line[ i ] );

			n_html_attribute( html.line[ i ], '=', &lval, &rval );

			n_posix_bool found = n_posix_false;

			n_type_int ii = 0;
			n_posix_loop
			{

				if ( n_string_is_same_literal( "href", lval.line[ ii ] ) )
				{
					found = n_posix_true;
					break;
				}

				ii++;
				if ( ii >= lval.sy ) { break; }
			}


			// [!] : the next line has data

			i++;


			if ( found )
			{

				// [Needed] : sanitize first

				n_posix_char *name = n_string_path_cat( html.line[ i ], N_FAVORITES2HTML_EXT_WEBLOC, NULL );
				n_string_safename( name, name );

				n_posix_char *path = n_string_path_make_new( folder, name );

				n_favorites2html_decode_file( path, rval.line[ ii ] );

				n_string_path_free( name );
				n_string_path_free( path );

			}

			n_html_free( &lval );
			n_html_free( &rval );

		}


		i++;
		if ( i >= html.sy ) { break; }
	}


	n_string_path_folder_change( curdir );
	n_string_path_free( curdir );


	n_string_path_free( favorites );


	n_html_free( &html );


	return n_posix_false;
}

n_posix_bool
n_favorites2html_main( n_posix_char *cmdline )
{

	n_posix_bool ret = n_posix_false;


	if ( n_posix_stat_is_dir( cmdline ) )
	{
//NSLog( @"Enc" );
		ret = n_favorites2html_encode( cmdline );
	} else {
//NSLog( @"Dec" );
		ret = n_favorites2html_decode( cmdline );
	}
//NSLog( @"%d", ret );


	return ret;
}

